#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug 19 15:25:43 2020

@author: jayanthikishore
"""

# https://www.math.ubc.ca/~pwalls/math-python/linear-algebra/linear-algebra-scipy/
import numpy as np

# Matrix shape and size
M = np.array([[1,2],[3,7],[-1,5]])
print(M)
print(M.ndim)
print(M.shape)
print(M.size)

# picking the column from matrix
col = M[:,1]
print(col)
print(col.shape)

# Picking the row from Matrix 
row = M[2,:]
print(row)
print(row.shape)

# Reshaping the column/or row
column = col.reshape(1,3)
print(column)

# Matrix element multiplication
a = np.array([[3,4],[-1,5]])
print(a)
b = a* a
print(b)

# Matrix multiplication
a= np.array([[3,4],[-1,5]])
print(a)
c = a @ a
print(c)
print(c.shape)

# ***compute 2I+3A-AB
A = np.array([[1,3],[-1,7]])
B = np.array([[5,2],[1,2]])
I = np.eye(2)
print(I)
res = 2*I + 3*A - A @ B
print(res)

# Matrix powers (mpow(a,2)= a @ a)
from numpy.linalg import matrix_power as mpow
c = np.array([[3,4],[-1,5]])
print(c)
cc =mpow(c,2)
print(cc)
cc1 = c @ c
print(cc1)

bc = mpow(c,3)
print(bc)
bc1 = c @ c @c
print(bc1)

# ****Transpose of a Matrix (A.T)
A = np.array([[3,4],[-1,5]])
print(A)
print(A.T)
bb = A @ A.T
print(bb)

# ****Inverse of a Matrix (inv(A))
from numpy.linalg import inv
A = np.array([[3,4],[-1,5]])
print(A)
print(inv(A))
bc = A @ (inv(A))
print(bc)

# **************Determinant (det(A))
from numpy.linalg import det
A = np.array([[3,4],[-1,5]])
print(det(A))

# ****create a random matrix
N = np.random.randint(0,10,[3,3])
print(N)

# *****projections (v.w)/(w.w) *w
def proj(v,w):
    v = np.array(v)
    w = np.array(w)
    # return (v *w)/(w * w) *w
    return np.sum(v * w)/np.sum(w *w) *w

print(proj([1,2,3],[1,1,1]))
# ****************************************
def dotp(i,j):
    i = np.array(i)
    j = np.array(j)
    return i * j

print(dotp([1,2],[2,3]))

# *************************************************
A=np.array([[3,4],[-1,2]])
B=np.array([[5,2],[8,-3]])
I=np.eye(2)
print(A.shape)
print(B.shape)
res = A @ B + 2*(mpow(B,2))-I
print(res)
# ***************************************************
print(A)
n = A.shape[0]
print(n)

def add_row(A,k,i,j):
    # add k times row j to row i in matrix A
    n = A.shape[0]
    E = np.eye(n)
    if i == j:
        E[i,i]=k+1
        print("new:",i,j)
    else:
        E[i,j] = k
        print("ith:",i,j,k,E[i,j])
    return



M = np.array([[1,1],[3,2]])
print(M)
print()
print(add_row(M,2,0,1))
    
# ***********************************hstack
M = np.array([[5,4,2],[-1,2,1],[1,1,1]])
print(M.shape)
AS = np.hstack([M,np.eye(3)])
print(AS)

# **********************Inverse****************
from numpy.linalg import inv
Minv = inv(M)
print(Minv)

mcheck = M @ Minv
print(mcheck)

# ********************solve Ax=b
A = np.array([[6,15,1],[8,7,12],[2,7,8]])
print(A.shape)
b = np.array([[2],[14],[10]])
print(b.shape)
x = inv(A) @ b
print(x)
    
# **********************solve*******************
A = np.array([[2,1],[1,1]])
B = np.array([[1],[1]])
# or
# B= np.array([1,-1]).reshape(2,1)

print(B)

x = inv(A) @ B
print(x)

# ************Eigenvalues and Eigenvectors************
import scipy.linalg as la
A= np.array([[1,0],[0,-2]])
print(A)

res = la.eig(A)    #tuple:immutable

# Eigenvalues of A are
print(res[0])
# The corresponding Eigenvectors
print(res[1])

# We can upack the tuple
eigvals, eigvecs = la.eig(A)
print(eigvals)
print(eigvecs)

# ******************************************************
# Eigenvalues of symmetric matrix********************
n = 4
P = np.random.randint(0,10,(n,n))
print(P)
# create a symmetric matrix S = PP'
S = P @ P.T
print(S)
# let's unpack the eigenvalues and eigenvectors
evals, evecs = la.eig(S)
print(evals)
# The eigenvalues all have zero imaginary and so they are indeed real
evals = evals.real
print(evals)

# The corresponding Eigenvectors are 
print(evecs)
# Lets check the eigenvectors are orthogonal to each other
V1 = evecs[:,0] # first column is the 1st eigen vector
print(V1)

V2 = evecs[:,1] #second column if the 2nd eigenvector
print(V2)
print(V1 @ V2)
***********************************************************
