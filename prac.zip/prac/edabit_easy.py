#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 23 08:35:45 2020

@author: jayanthikishore
"""
# ********rotate 90deg and interview question
# A =[[1,2,3],[4,5,6],[7,8,9]]
# # B = [[7,4,1], [8,5,2], [9,6,3]]
# def rot_matrix(A):
#     A.reverse()
#     B=[]
#     for num in range(0,len(A)):
#         B.append([0] * len(A))
#     # print(B)
    
#     for i in range(0,len(A)):
#         for j in range(0,len(A)):
#             B[j][i] = A[i][j]
#     # print(B)
#     # return B
#     # A.reverse()
    
# B=rot_matrix(A)
# # print(B)
# if rot_matrix(A) == B:
#     print("pass!")
# else:
#     print("Fail")
    
# # *****Convert hours to seconds*******
# def how_many_seconds1(hr):
#     return hr * 60 * 66

# print(how_many_seconds1(10))
# # *********************************
# def how_many_seconds(hr):
#     hr=hr * 60 * 60
#     return hr
# print(how_many_seconds(10))

# # *****nextnumber integer passed*****
# def addition(n):
#     n+=1
#     return n
# print(addition(9))

# # ***maximum edges of a traingle(side1+side2-1)****
# def max_edges(s1,s2):
#     return s1+s2-1
# print(max_edges(8,10))

# ****remainder from two numbers********
def remnder(n1,n2):
    if n1 > n2 :
        remainder=n1 % n2
        # print(remainder)
    else:
        remainder=n1
        # print(remainder)
    return remainder
print(remnder(12,8))

# *****string to integer*********
def str_int(val):
    return int(val)

print(str_int("25"))

# ****perimeter of reactangle 2(l+b)*******
def perimeter(l,b):
    return 2*(l+b)
print(perimeter(20,10))

# *****caluclate exponent******(3^3=27)*******
def expo(n1,pow):
    return n1**pow 
print(expo(5,5))

# ***Return first element in a list******
def fele(list):
    return list[0]
print(fele([2,4,5,12,14]))

# ****string to Integer and Vice Versa*******
def strint(val):
    if isinstance(val,str)==True:
        res = int(val)
    
    else:
        res= str(val)
    return res
print(strint('99'))


