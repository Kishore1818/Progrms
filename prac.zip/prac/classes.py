#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 19:07:50 2020

@author: jayanthikishore
"""

# **********************CLASSES************************************
class dog():
    """A simple attempt to model a dog"""
    def __init__(self,name,age):
        """initialize the name and age attributes"""
        self.name=name
        self.age=age
        
    def sit(self):
        print(self.name.title() + " is now sitting")
        
    def roll_over(self):
        print(self.name.title() + " rolled over")
        
    
my_dog = dog('willie',6)
              
print("My dog's name is " + my_dog.name.title() + ".")
print("My dog is " + str(my_dog.age) + " years old.")

my_dog.name
my_dog.sit()
my_dog.roll_over()
# ****************************GOOD one************************************

class User():
    """represent a simple user profile"""
    def __init__(self,first_name,last_name,username,email,location):
        """initialize the user"""
        self.first_name=first_name.title()
        self.last_name = last_name.title()
        self.username = username
        self.email = email
        self.location = location.title()
        self.login_attempts=0
        
    def describe_user(self):
        """Display summary of the user's information"""
        print("\n"+self.first_name+""+self.last_name)
        print("  Username: ", self.username)
        print("   email: ",self.email)
        print("   Location: ",self.location)
        
    def greet_user(self):
        """Display a personalized greeting to the user"""
        print("\nWelcome back "+self.username)
    
    def increment_login_attempts(self):
        """Increment the value of loging attempts"""
        self.login_attempts += 1
    
    def reset_login_attempts(self):
        """Reset login attempts to 0"""
        self.login_attempts = 0
        
eric = User('eric', 'matthes', 'e_matthes', 'e_matthes@example.com', 'alaska')

eric.describe_user()
eric.greet_user()

# ********************************************************************
# Dice: 1 and 6                    
from random import randint
x = randint(1,6)

class Die():
    """Represent a die, which can be rolled."""

    def __init__(self, sides=6):
        """Initialize the die."""
        self.sides = sides

    def roll_die(self):
        """Return a number between 1 and the number of sides."""
        return randint(1, self.sides)

# Make a 6-sided die, and show the results of 10 rolls.
d6 = Die()
results = []
for roll_num in range(10):
    result = d6.roll_die()
    results.append(result)
print("10 rolls of a 6-sided die:")
print(results)
# **********************************************************************

s='1234.12'
a,b = map(int,s.split(".",1))
print(a,b)  

# **********************create a empty call in python*****************
class a:
    pass
obj=a()
obj.name="xyz"
print("Name=",obj.name)

      