
list: is a collection which os ordered and changeable. Allows duplicate memebers
list1 = ["apple", "banana", "cherry"]
list2 = [1, 5, 7, 9, 3]
list3 = [True, False, False]
list4 = ["abc", 34, True, 40, "male"]
print(list4)
Res: ['abc', 34, True, 40, 'male']

Tuple: is a collection which is unordered and unchangeable. Allows duplicate members 
tuple1 = ("apple", "banana", "cherry")
tuple2 = (1, 5, 7, 9, 3)
tuple3 = (True, False, False)
tuple4 = ("abc", 34, True, 40, "male")

thistuple = tuple(("apple", "banana", "cherry"))
print(thistuple)
res: ('apple', 'banana', 'cherry') 

Set: is a collection which is unordered and unindexed. No duplicate memebers
set1 = {"apple", "banana", "cherry", "Cherry"} = {"apple", "banana", "cherry"}
set2 = {1, 5, 7, 7,1,9, 3} = {1,5,7,9,3}
set3 = {True, False, False} = {True, False}

thisset = set(("apple", "banana", "cherry"))
print(thisset)
{'apple', 'banana', 'cherry'} 

Dictionary: is a collection which is unordered and changeable. No duplicate memebers
thisdict =	{
  "brand": "Ford",
  "model": "Mustang",
  "year": 1964
}
print(thisdict)
{'brand': 'Ford', 'model': 'Mustang', 'year': 1964} 

print(thisdict["brand"])
Ford


string
for testing: type()

# https://www.w3resource.com/python-exercises/basic/
def adjacentElementsProduct(inputArray):
    array = []
    for i in range(len(inputArray)-1):
        array.append(inputArray[i] * inputArray[i+1])
    return max(array)

inputArray = [3, 6, -2, -5, 7, 3]

print(adjacentElementsProduct(inputArray))
res: [18, -12, 10, -35, 21]
#(or) *******************************************
def adj(nums):
    n=len(nums)
    maxx =-1000
    for i in range(n-1):
        prdd = nums[i] * nums[i+1]
        # print(prdd)
        if prdd > maxx:
            maxx = prdd
    return maxx
              
nums= [3, 6, -2, -5, 7, 3]   
print(adj(nums)) 

# **********shape area**************
# n=1,2,3,4,5
# shape area=1,5,13,25,41
def shparea(n):
    return n**2 + (n-1)**2

print(shparea(5))

# **********shape area different way********
def shapeArea(n):
    area=1
    for i in range(n):
        area += 4*i
    return area

print(shapeArea(5))

# # ********************************
# from math import pi
# def area(val):
#   return pi * val
  
# print(area(1.1))

# *********reverse the string
def revname(fname,lname):
  nname = fname + ' ' +lname
  print(nname)
  rname = nname[::-1]
  print(rname)
  return revname
  
revname('kiss','pan')

# *******split the filename and write filename extension only
def spll(nme):
    nname = nme.split('.')
    print(nname)
    extnme = nname[-1]
    return extnme
    
spll("abc.java")
solution = java

(or)
def spll(nme):
    nn=len(nme)
    extt = nme[-4:]
    
    return extt

spll("abc.java")
# *****print two dates difference
from datetime import date

fdate = date(2014,7,2)
ldate = date(2014,7,11)
print(ldate-fdate)
solution : 9 days, 0:00:00

# Write a Python program to test whether a number is within 100 of 1000 or 2000
def numm(n):
    return ((abs(1000-n)<=100) or (abs(2000-n)<=100))

print(numm(2200))
res= false

pnumm(900)
res: True

# Write a Python program to calculate the sum of three given numbers, 
# if the values are equal then return three times of their sum
def sum3(x,y,z):
    if(x == y ==z):
        sum = (x+y+z)*3
    else: sum= x+y+z
    return sum   
        
print(sum3(6,6,6))  
# ***************************************************************************************
# Write a Python program to get a new string 
# from a given string where "Is" has been added to the front. 
# If the given string already begins with "Is" then return 
# the string unchanged.    

def strin(strng):
    stt = strng[0:2]
    if(stt == "Is"):
        print(strng)
    else:
        strng1="Is"+strng 
        print(strng1)
        return strng1
    
strin("isboby")    

(or)
def strr(strng):
    pstr=strng[0:2]
    if(pstr == 'is'):
        return strng
    else:
        return 'is'+strng
    return strng

    
strr("isboby")       
# ****************************************************************
# Write a Python program to count the number 4 
# in a given list. 

def cntnums(vals):
    cnt=0
    for i in range(len(vals)):
        if(vals[i] == 4):
            cnt+=1
     
    return cnt
    
vals=[2,3,4,1,6,7,4,5,4,4]    
print(cntnums(vals))  

(or)
def cntnums(vals):
    cnt=0
    for i in vals:
        if (i == 4):
            cnt += 1
    return cnt
        
vals = [2,3,4,5,6,7,4,6,8,4]
print(cntnums(vals))

# ***********************************************************
# Write a Python program to test whether a passed 
# letter is a vowel or not.  

def let_vowel(char):
    all_vowels='aeiou'
    return char in all_vowels 

print(let_vowel("y"))

# ***************************************************************
# Write a Python program to concatenate all elements 
# in a list into a string and return it.

def concate(elemns):
    nstrng=''
    for i in elemns:
        nstrng += str(i)
    return nstrng
        
print(concate([2,3,5,6]))

# ****************************************************************
# Python code to get difference of two lists 
def difflist(list1,list2):
    ldiff = [i for i in (list1+list2) if i not in list1 or i not in list2]
    
    return ldiff 

list1=[10,20,12,35,40]
list2 =[10,20,35]
print(difflist(list1, list2))

list1=(["White", "Black", "Red"]) 
list2 =(["Red", "Green"])
print(difflist(list1, list2))

# GCD*******************************************************************
import math 
def gcdd(a,b):
    return math.gcd(a,b)

print(gcdd(60,48))
# LCM nice method*************************************************************************
python (% = modulus (just remainder)    //=floor division)
def gcdd(a,b):
    while (b>0):
        a,b = b, a % b
    return a

def lcmm(a,b):
    return abs(a* b) // gcdd(a,b)
    # return abs(a*b) // math.gcd(a,b)

print(lcmm(40,16))

# *****************************************************************
# Write a Python program to sum of two given integers. 
# However, if the sum is between 15 to 20 it will return 20.

def twd(x,y):
    summ = x+y
    if(summ >=15 and summ <=20):
        summ=20
    else:
        summ=summ
    return summ

print(twd(5,12))
# **********************************************************
# Write a Python program to add two objects 
# if both objects are an integer type.:

def chkint(a,b):
    if(isinstance(a, int) and isinstance(b, int)):
        summ = a+b
    else:
        summ = "Number is not integer"
    return summ 

print(chkint(2, 8))
print(chkint(2,"ws")
# *************************************************************
# For 32 bit it will return 32 and for 64 bit 
# it will return 64
import struct
print(struct.calcsize("P") * 8)
# **************************************************************
# Write a python program to call an external command in Python.
from subprocess import call
call(["ls", "-l"])

# ***************************************************************
# Write a Python program to parse a string to Float or Integer. 
    
n = "246.2458"
print(float(n))
print(int(float(n)))
# ****************************************************************
# Write a Python program to sort three integers 
# without using conditional statements and loops.

def order3(x,y,z):
    fnum = min(x,y,z)
    lnum = max(x,y,z)
    mnum = (x+y+z) - fnum-lnum
    # print(fnum,mnum,lnum)
    return fnum,mnum,lnum

print(order3(12,9,15)) 

a = [10,4,5]
a.sort()
for i in range(len(a)):
    print(a[i],end =' ')  

(or)
b = sorted(a)
# *********************************************************************
# Imports the math module
import math            
#Sets everything to a list of math module
math_ls = dir(math) # 
print(math_ls)    
# **************************************************************************
def concatestr(strr):
    nstrng = '-'.join(strr)
    # print(nstrng)
    return nstrng
strr=["blue","red","green"]
print(concatestr(strr))
# ****************************************************************************
# finding the 'e' indexes
s1 ="asaewewqgwfewerevd"

newst=[]
for i,st in enumerate(s1):
    if(st == 'e'):
        newst.append(i)
        print(i,st)
        
print(newst)
*****************************
s1 ="asaewewqgwfewerevd"

new1 =[]
for i in range(len(s1)):
    if(s1[i] == 'e'):
        new1.append(i)
        print(i,s1[i])

for j in range(len(new1)-1):
    diff= new1[j+1] - new1[j]
    print(diff)
************************************************
# Find the minimum number of moves needed to make a new string where no single
# character is repeated more than twice.
# Moves can be additions or deletions.

s1 = "aabcdddddddeeefggg"
s2 = "eeeelllltsscvvvvv"
s3 = "hello"

print( sum([max([s1.count(char)-2,0]) for char in set(s1)]))
or
s1 = "aaaabcbadbaeewaseaaeee"
s2 = set(s1)
print(s2)
s22 = ''.join(s2)

ecnt=[]
for st1 in s22:
    cnt=0
    for i,st2 in enumerate(s1):
    #for st2 in s1:
        if(st1 == st2):
            cnt+=1
            #print(i,st1,st2,cnt)
    ecnt.append(cnt)        
print("counts:",max(ecnt))

or
# s1 = "aabcdddddddeeefggg"
s1 = "aaaabcbadbaeewaseaaeee"
s11 = set(s1)
s12 = ''.join(s11) (or) s12 = list(s11)  (tuple to string)
# print(s12)

fcnt=[]
for i in range(len(s12)):
    print(i,s12[i])
    
    cnt=0
    for j in range(len(s1)):
        if(s1[j] == s12[i]):
            cnt+=1
#             print(i,j,s12[i],s1[j],cnt)
    fcnt.append(cnt)
        
print('max count:',max(fcnt))

*****************************************************************
# finding the position of "e"
s1 ="asaewewqgwfewerevd"

newst=[]
for i,st in enumerate(s1):
    if(st == 'e'):
        newst.append(i+1)
        print(i,st)
        
print(newst)

;*************************************************************
# each character counting
# s1 ="asaewewqgwfewerevd"
s1 = "aabcdddddddeeefggg"
s11 = set(s1)
s2 = list(s11)

ecnt=[]
for st1 in s2:
    cnt = 0
    for st2 in s1:
        if(st1 == st2):
            cnt+=1
    ecnt.append(cnt)

for i in range(len(s2)):
    print(s2[i],ecnt[i])
result:
b 1
f 1
c 1
a 2
e 3
d 7
g 3
print(ecnt)
result:
[1, 1, 1, 2, 3, 7, 3]

