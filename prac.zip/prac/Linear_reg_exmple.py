#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 22 15:27:02 2020

@author: jayanthikishore
"""
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as la
# ****Linear regression example
years = np.array([2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016])
games = [80,77,82,82,73,82,58,78,6,35,66]
points = np.array([35.4,31.6,28.3,26.8,27,25.3,27.9,27.3,13.8,22.3,17.6])

# ***plotting
fig = plt.figure(figsize=(12,10))
axs = fig.subplots(2,1,sharex=True)
axs[0].plot(years,points,'b.',ms=25)
axs[0].set_title('Kobe Bryant, Points per Game')
axs[0].set_ylim([0,40])
axs[0].grid(True)

axs[1].bar(years,games)
axs[1].set_title("Kobe Bryant, Games played")
axs[1].set_ylim([0,100])
axs[1].grid(True)
plt.show()

# ***let compute the average
avg_games_per_year = np.mean(games)
print(avg_games_per_year)

# ***Compute the linear model(see: liear_regression.py)
X = np.column_stack([np.ones(len(years)),years])
a = la.solve(X.T @ X, X.T @ points)
print(a)
model = a[0] + a[1]*years

plt.plot(years,model,years,points,'b.',ms=25)
plt.title("Kobe Bryant, Points per Game")
plt.ylim([0,40])
plt.grid(True)
plt.show()