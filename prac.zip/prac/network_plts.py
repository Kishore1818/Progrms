#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 22 15:55:01 2020

@author: jayanthikishore
"""

# *********************NetworkX
# ************Adjacency Matrix*****************
import networkx as nx

# G = nx.complete_graph(5)
# nx.draw(G,with_labels=True)

# A = nx.adjacency_matrix(G).todense()
# print(A)

# # *******dodecahedral graph and Length of the shortest path***********
# G = nx.dodecahedral_graph()
# nx.draw(G,with_labels=True)

# A = nx.adjacency_matrix(G).todense()
# print(A)

# # ***with this labelling, lets find the length of the shortest path
# i = 0
# j = 15
# k = 1
# Ak = A
# while Ak[i,j] == 0:
#     Ak = Ak @ A
#     k = k+1
# print('Length of the shortest path is: ', k)

# # ******Triangle in a Graph(3 vertices)*****************
# # T(G) = 1/6(lamda1^3 + lamda2^3 + ...+lamdan^3)
# c3 = nx.complete_graph(3)
# nx.draw(c3,with_labels=True)

# # ***Lets compute the number of triangles in the complete graph 7 vertices
C7 = nx.complete_graph(7)
nx.draw(C7,with_labels=True)

import numpy as np
import scipy.linalg as la
A7 = nx.adjacency_matrix(C7).todense()
eigvals, eigvecs = la.eig(A7)
bb=int(np.round(np.sum(eigvals.real**3)/6,0))
print(bb)