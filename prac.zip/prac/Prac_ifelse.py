#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 10:17:54 2020

@author: jayanthikishore
"""


a_top = ['mushrooms', 'olives', 'green peppers',
                      'pepperoni', 'pineapple', 'extra cheese']

r_top = ['mushrooms', 'french fries', 'extra cheese']

for i in range(0,len(r_top)):
    if r_top[i] in a_top:
        print("Adding"+r_top[i]+'.')
    else:
        print("sorry, we don't have"+r_top[i])
        
print("\n Finished")

# *****************Ordinal Numbers******************
numbs = list(range(1,10))
print(numbs)

for nums in numbs:
    if nums ==1:
        print("1st")
    elif nums ==2:
        print("2nd")
    elif nums==3:
        print("3rd")
    else:
        print(str(nums)+'th')