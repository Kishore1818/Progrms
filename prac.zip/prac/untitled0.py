#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep  2 06:35:10 2020

@author: preethamvignesh
"""
A = [[1,2],
     [3,4]] 
print(A)

B = [[1,2,3,4,5],
     [5,6,7,8,9]]
print(B)

# Multiplication
res = [[0,0,0,0,0],
       [0,0,0,0,0]]

# iteration with rows of A
for i in range(len(A)):
    # print(A[i])
    # iteration with column of B
    for j in range(len(B[0])):
        
        # iteration with row a B
        for k in range(len(B)):
            # print(A[i][k],B[k][j])
            res[i][j] += A[i][k] * B[k][k]
            
for r in res:
    print(r)