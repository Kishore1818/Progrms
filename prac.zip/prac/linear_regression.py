#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 22 14:42:11 2020

@author: jayanthikishore
"""
# Least Squeares Linear Regression
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as la

a0=2
a1=3
N=100
x = np.random.rand(100)
noise = 0.1*np.random.randn(100)
y = a0 + a1*x + noise
plt.scatter(x,y)
plt.show()

# Let's linear regression to retrieve the coefficient a0, a1
X = np.column_stack([np.ones(N),x])
print(X.shape)
# print first 5rows of X
print(X[:5,:])

# (X'X)a = (X')y for a 
a = la.solve(X.T @ X, X.T @y)
print(a)

# *****plotting
xs = np.linspace(0,1,10)
ys = a[0] + a[1]*xs
plt.plot(xs,ys,'r',linewidth=4)
plt.scatter(x,y)
plt.show()