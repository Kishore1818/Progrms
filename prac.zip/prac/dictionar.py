#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 15:14:55 2020

@author: jayanthikishore
"""

alien_0 = {'color': 'green', 'points': 5}
print(alien_0['color'],alien_0['points'])

# **************************
alen_0={}

alen_0['color'] = 'green'
alen_0['points']=5
print(alen_0)

alen_0['color']='yellow'
print(alen_0)

fav_lang = {
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python'}

print(fav_lang)
print(fav_lang['jen'])

# *****looping through key value pairs************************
user_0 = {
    'username':'efermi',
    'first':'enrico',
    'last':'fermi'
    }
print(user_0)

for key, value in user_0.items():
    print("\nKey: "+key)
    print("Value: "+value)

# (or)
for k,v in user_0.items():
    print("\nKey: "+k)
    print("Value: "+v)
    
fav_lang = {
    'jen':'python',
    'sarah':'c',
    'edward':'ruby',
    'phil':'python'}

# for k,v in fav_lang.items():
#     print("\nKey: "+k)
#     print("Value: "+v)
    
for k,v in fav_lang.items():
    print(v)
 
# ******************************
pizza = {
'crust': 'thick',
'toppings': ['mushrooms', 'extra cheese'],
}
print(pizza)
for top in pizza['toppings']:
    print(top)
    
# ******************************
favorite_languages = {
    'jen': ['python', 'ruby'],
    'sarah': ['c'],
    'edward': ['ruby', 'go'],
    'phil': ['python', 'haskell'],
    }
print(favorite_languages)

for name,fav in favorite_languages.items():
    print("\n Name:",name)
    for nlang in fav:
        print("\t"+nlang)