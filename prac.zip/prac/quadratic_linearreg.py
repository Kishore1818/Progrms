#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 22 15:43:16 2020

@author: jayanthikishore
"""
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as la

# ****Quadratic fit: using linear regression***************
# Fake quadratics datasets
a0 = 3
a1 = 5
a2 = 8
N = 1000
x = 2*np.random.rand(N)-1 #random numbers in the interval(-1,1)
noise = np.random.randn(N)
y = a0 + a1*x + a2*x**2 + noise
plt.scatter(x,y, alpha=0.5,lw=0)
plt.show()

# for solving a0,a1, and a2 using Linear regression
X = np.column_stack([np.ones(N),x,x**2])
print(X.shape)
# solving coefficents (X'X)a = (X')y (Liner_regression.py)
a = la.solve(X.T @ X, X.T @ y)
print(a)

xs =np.linspace(-1,1,20)
model = a[0] + a[1]*xs + a[2]*xs**2
plt.plot(xs,model,'r',linewidth=4)
plt.scatter(x,y,alpha=0.5,lw=0)
plt.show()