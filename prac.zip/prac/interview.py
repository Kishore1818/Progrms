#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 14 07:55:39 2020

@author: jayanthikishore
"""

# ******To check the number is PRIME or not ***********************
num =423

if num > 1:
    for i in range(2,num):
        if(num %i == 0):
            print(num,"is not prime number")
            print(i,"times",num//i, "is",num)
            break
    else:
        print(num,"is prime number")


# ****prime numbers******
bnum=600
lnum=800

for num in range(bnum,lnum+1):
    if num >0:
        for i in range(2,num):
            if num % i ==0:
                break
        else:
            print("%d prime number" %num)
            
# *******************************************************************************
# *****************PALINDROME******************************************************
strng = "malayalam"
if(strng == strng[::-1]):
    print("The string is a palindrome")
else:
    print("The string is not palindrome")

# ******number 
num=int(3663)
print(type(num))

reverse = 0
temp =num

while(temp >0):
    reminder = temp%10
    reverse = (reverse*10)+reminder
    temp = temp//10                     #floor division
print("reverse of a given number is = %d" %reverse)

if(num == reverse):
    print("%d is Palindrome number" %num)
else:
    print("%d is not a Palindrome number" %num)

or
num=int(3663)
stt = str(num)
stt1 = stt[::-1]
print(int(stt1))    
# *****************************Palindrom function    
def paln(numm):
    temp=numm
    reverse=0
    while(temp >0):
        remainder= temp % 10
        reverse = reverse*10+remainder
        temp =temp//10
    print(reverse)
    return 

paln(3663)
   
# ********************************************************************************
# ********Fibonacii number =Fn = F(n-2)+F(n-1)
# nterms = int(input("print how many terms for Fibonacci: ")) 

# # first two terms
# n1, n2 = 0,1
# count =0

# if nterms <=0:
#     print("pl. enter a positive integer")
# elif nterms==1:
#     print("Fibonacci number uptp",nterms)
#     print(n1)
# else:
#     while(count < nterms):
#         print(n1)
#         nth=n1+n2
#         # update values
#         n1=n2
#         n2=nth 
#         count += 1

# # ******************Fibonacii function*************************
# def fibonacii(n):
#     if n<=0:
#         print('Pl. enter integer')
#         # first fibonacii number
#     elif n==1:
#         return 0
#         # second fibonacii number
#     elif n==2:
#         return 1
#     else:
#         return fibonacii(n-1)+fibonacii(n-2)
 
# print(fibonacii(9))

# ****************************************************************************
# How to get indices of N maximum values in a NumPy array

import numpy as np
arr = np.array([9, 4, 4, 3, 3, 9, 0, 4, 6, 0])
ind = np.argpartition(arr,-5)[-5:]
print(ind)
print(arr[ind])
# (or)
idx = (-arr).argsort()[:5]    #(-array).argsort()[:n]
print(idx)
print(arr[idx])

# ***********************percentile**************************************
import numpy as np
arr = np.array([1,3,4,6,7])
per = np.percentile(arr,50)
print(per)


list=[1,3,45,6,78]
print(list[-1])
# ******************************BUBBLE sort algorithm*************************
def bsort(a):
    b = len(a)-1
    
    for i in range(b):
        for j in range(b-i):
            if a[j] > a[j+1]:
                a[j],a[j+1] = a[j+1],a[j]
    return a

a=[13,24,77,2,109]
print(bsort(a))

# ****************STAR Triangle*************************************
n=7
for i in range(n):
    print(' '*(n-i-1)+'*'*(2*i+1))


def startr(r):
    for x in range(r):
        print(' '*(r-x-1)+'*'*(2*x+1))
        # print('*'*(1*x+1)+' '*(r-x-1))

startr(9)
# **************************************counting Caps in a file
with open('/home/jayanthikishore/Downloads/Python/prac/text.txt') as ftext:
    text = ftext.read()
    print(text)
    
count =0
for char in text:
    if char.isupper():
        count += 1
print(count)
