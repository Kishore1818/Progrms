#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 16:32:26 2020

@author: jayanthikishore
"""

def greet_user():
    """Dispaly a simple greetings"""
    print("Hello")
    
greet_user()

# ****passing information to a function***********
def greet_user(username):
    print("hello",username.title())
    
greet_user('jessie')
# ************************************
def favorite_book(bname):
    print("Favorite book name: ",bname.title())
    
favorite_book('my book')
# ***********************************************
def describe_pet(pet_name, animal_type='dog'):
    """Display information about a pet."""
    print("\nI have a " + animal_type + ".")
    print("My " + animal_type + "'s name is " + pet_name.title() + ".")
    
describe_pet(pet_name='Ruby')
# ***************************************************************
def get_formatted_name(first_name, last_name, middle_name=''):
    if middle_name:
        full_name = first_name + ' ' + middle_name + ' ' + last_name
    else:
        full_name = first_name + ' '  + last_name
    return full_name.title()

musician = get_formatted_name('jimi', 'hendrix')
print(musician)

musician = get_formatted_name('john', 'hooker', 'lee')
print(musician)
# ***********************************************************************
def greet_users(names):
    for name in names:
        msg = "Hello :"+name.title()
        print(msg)
        
usernames = ['john','bradpit','margot']
greet_users(usernames)
# ***************************************************
def make_pizza(*toppings):
    print(toppings)

make_pizza('pepporoni')
make_pizza('mushrooms', 'green peppers', 'extra cheese')

# ******************using for loop
def make_pizza(*toppings):
    for top in toppings:
        print(top)

make_pizza('pepporoni')        
make_pizza('mushrooms', 'green peppers', 'extra cheese')  

# ****************************************
def make_pizza(size, *toppings):
    print("size of the pizza: ",size,' toppings: ')
    for topps in toppings:
        print(topps.title())
    
make_pizza(16,'pepporoni')    
make_pizza(18,'mushrooms', 'green peppers', 'extra cheese')

# ***************dictionary to function**************GOOD ONE***********
def build_profile(first,last, **user_info):
    profile={}
    profile['first_name'] = first
    profile['last_name'] = last 
    for key,value in user_info.items():
        profile[key]=value
    return profile 

user_profile = build_profile('albert', 'einstein',
                             location='princeton',field='physics')
print(user_profile)

# **************************************************************
def magic(*args, **kwargs):
    print('unnamed args: ',args)
    print('keyword args: ',kwargs)
    
magic(1, 2, key="word", key2="word2")