#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 14 17:00:48 2020

@author: jayanthikishore
"""

numbers = [45, 22, 14, 65, 97, 72]

for i, num in enumerate(numbers):
    if num % 3 ==0 and num %5 ==0:
        numbers[i] = "fizzbuzz"
    if num %3 ==0:
        numbers[i] = 'fizz'
    if num %5 ==0:
        numbers[i] = "buzz"
        
print(numbers)
sol: ['buzz', 22, 14, 'buzz', 97, 'fizz']
# ************************************************
numbers = [45, 22, 14, 65, 97, 72]
for j, num in enumerate(numbers):
    print(j,num)

# ***************square of a numbers different ways*************************
numbers =[4,2,1,6,8,7]

def sqres(x):
    return x*x

# first way
res =[sqres(x) for x in numbers]
print(res)  

# Second way
res1 = list(map(sqres,numbers)) 
print(res1)   

# *************************odd numbers********************
def is_odd(x):
    return (x % 2)

reso = [x for x in numbers if is_odd(x)]
print(reso)

reso1 = list(filter(is_odd,numbers))
print(reso1)

# *********************sorting numeric and characters*************
num = [6,5,3,7,2,4,1]
sor = sorted(num)
print(sor)
solution= ['bear', 'cat', 'cheetah', 'dog', 'rhino']

nmes= ['cat', 'dog', 'cheetah', 'rhino', 'bear']
sor1 = sorted(nmes)
print(sor1)
sor2 = sorted(nmes,reverse=True)
print(sor2)
solution = ['rhino', 'dog', 'cheetah', 'cat', 'bear']
# ********************************************************************