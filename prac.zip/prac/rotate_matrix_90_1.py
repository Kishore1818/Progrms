#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 09:16:15 2020

@author: jayanthikishore
"""

# import numpy as np
# A =np.array([[1,2,3],[4,5,6],[7,8,9]])
A =[[1,2,3],[4,5,6],[7,8,9]]
B = [[7,4,1], [8,5,2], [9,6,3]]
# print(A.shape)
def rotate_matrix(A):
    A.reverse()
    B=[]
    for num in range(0,len(A)):
        B.append([0] * len(A))
        
    for i in range(0,len(A)):
        for j in range(len(A)):
            # B[j]=print(A[i][j])
            B[j][i] = A[i][j]
    return B  
    A.reverse()
    

if rotate_matrix(A) == B:
    print("pass!")
else:
    print("Fail")
print(B)
