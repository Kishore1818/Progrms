#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 14 09:47:57 2020

@author: jayanthikishore
"""

# # *******Palindrome practice******

# number = int(6557)

# temp=number
# reverse=0

# while(temp >0):
#     remainder = (temp % 10)
#     reverse=reverse*10 + remainder
#     temp = temp//10

# print("reverse number is: %d" %reverse)

# if(number == reverse):
#     print("%d number is polydrom" %number)
# else:
#     print("%d number is polydrom" %number)    

# # *****string plydrome*****

# strr = "malayalamm"

# reverse = strr[::-1]
# if(strr == reverse):
#     print("%s string is Polydrome" %strr)
# else:
#     print("%s string is not a Polydrome" %strr)

# # ****************************************Fibonacii
# num=int(9)

# n1,n2=0,1
# count =0

# while(count < num):
#     print(n1)
#     nth=n1+n2
#     n1=n2
#     n2=nth 
#     count += 1

# # ***********function: fibonacii 
# def fibo(n):
#     if(n <=0):
#         print('Enter positive integer')
#     elif n==1:
#         return 0
#     elif n==2:
#         return 1
#     else:
#         return fibo(n-1)+fibo(n-2)
    
# print("function fibo:",fibo(9))

# ***********************************************************************
def startrn(n):
    for i in range(n):
        print(' '*(n-i-1)+'*'*(2*i+1))
        
startrn(8)



