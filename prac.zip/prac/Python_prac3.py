
# https://www.w3resource.com/python-exercises/basic/
# Write a Python function that takes a sequence of numbers 
# and determines whether all the numbers are different from 
# each other.
def dfrntnum(x,y,z):
    print(x,y,z)
    if((x != y) and (y != z) and (x != z)):
        print('The numbers are different')
    else:
        print("numbers are same")
    return x

print(dfrntnum(5,5,7))
# ***************************************************
# Write a Python program to remove and print every third 
# number from a list of numbers until the list becomes empty.
def thrdnum(num):
    stt = str(num)
    nt = len(stt)
    for i in range(1,nt):
        if((i+1) % 3 == 0):
            print(stt[i])

    return stt

thrdnum(123456789)    
result: 3,6,9
# *****************************************************
# Write a Python program to find unique triplets 
# whose three elements gives the sum of zero from an 
# array of n integers.

def triplets(arr):
	nn=len(arr)
	found=True

	for i in range(0,nn-2):
		for j in range(i,nn-1):
			for k in range(j,nn):
				if(arr[i]+arr[j]+arr[k] == 0):
					found=True
	if(found == True):
		print("Triplet is exists")
	else:
		print("Triplet is not exist")


arr = [0, -1, 2, -3, 1] 
triplets(arr)     
# **********************************************************
# *****Threee digits combinations
from itertools import permutations 
  
# Get all permutations of [1, 2, 3] 
perm = permutations([1, 2, 3]) 
  
# Print the obtained permutations 
for i in list(perm): 
    print(i)

 (or)
 
 # Three digit all combinations
def digit3comb(a,b,c):
    d = []
    d.append(a)
    d.append(b)
    d.append(c)
    
    for i in range(0,3):
        for j in range(0,3):
            for k in range(0,3):
                if(i != j & j != k & k!=i):
                    print(d[i],d[j],d[k])
    return d

digit3comb(3, 4, 5)
3 4 5
3 5 4
4 3 5
4 5 3
5 3 4
5 4 3
(or)
# ***********General permutations / combinations excellent
# Write a Python program to create all possible 
# permutations from a given collection of distinct numbers.
#This id for any numbers
def npermutations(nums):
    r_perms =  [[]]
    for n in nums:
        n_perms = []
        for perm in r_perms:
            for i in range(len(perm)+1):
                n_perms.append(perm[:i] + [n]+perm[i:])
                r_perms = n_perms
    return r_perms

        
arr = [5,6,9]       
npermutations(arr)  
[[5, 4, 3], [4, 5, 3], [4, 3, 5], [5, 3, 4], [3, 5, 4], [3, 4, 5]]
# ********************************************************
# Write a Python program to check the sum of three 
# elements (each from an array) from three arrays is 
# equal to a target value. Print all those three-element 
# combinations.

for ii in range(0,3):
    if(ii == 0): 
        X = [10, 50, 10, 20]
    if(ii == 1):
        X = [10, 20, 30, 40]
    if(ii == 2):
        X = [5, 15, 45, 20]
    n = len(X)
    for i in range(0,n-2):
        for j in range(i+1,n-1):
            for k in range(j+1,n):
                if(X[i]+X[j]+X[k] == 70):
                    print(ii,X[i],X[j],X[k])
# *************************************************************
# Write a Python program to add two positive 
# integers without using the '+' operator. 

def bitwiseplus(a,b):
    while(b != 0):
        data = a & b
        a = a ^ b
        b = data << 1
    return a

print(bitwiseplus(-20, 10))
# ****************************************************************
# Write a Python program to find the number of zeros 
# at the end of a factorial of a given positive number.

def factendzeros(n):
     x = n // 5
     y = x
     while x > 0:
         x /= 5
         y += int(x)
     return y

print(factendzeros(15))        
# ******************************************************************
# Write a Python program to find the number of divisors 
# of a given integer is even or odd.  
def divisrs(n):
    for i in range(n):
        x = len([i for i in range(1,n+1) if not n % i])
    return x

print(divisrs(20))

(or)

# Write a Python program to find the number of divisors 
# of a given integer is even or odd.  
def divisrs1(n):
    i = 1
    while i <= n:
        if(n % i ==0):
            print(i),
        i=i+1
    return n
divisrs1(15)
res: 1,3,5,15
divisrs1(12)
res:1,2,3,4,6,12
# ***********************************************************************
# Write a Python program to find the digits 
# which are absent in a given mobile number.

def phnum(nums):
    cnum = set([0,1,2,3,4,5,6,7,8,9])
    
    nums = set([i for i in nums])
    nums = nums.symmetric_difference(cnum)
    nums = sorted(nums)
    return nums
    
nums = [9,8,3,2,2,0,9,7,6,3]    
print(phnum(nums))  

(or)

def dph(nums):
    digts=[0,1,2,3,4,5,6,7,8,9]
    dnum = [i for i in (nums+digts) if i not in nums or i not in digts]
    return dnum

nums = [9,4,9,2,3,1,7,9,0,5]

dph(nums)
res =[6,8]
********************************************  
# ***************************************************************************
# ******AP progression********************
def aps(vals):
    diff = []
    for i in range(len(vals)-1):
        diff.append(vals[i+1] - vals[i])
    print(diff)
    ser =[]
    if(diff[0] == diff[1]):
        nn = range(0,8)
        for i in nn:
            ser.append(int(vals[0]) + i*diff[0])
    return ser

vals = [3,5,7,9,11]
print(aps(vals))    
res : [3, 5, 7, 9, 11, 13, 15, 17, 19]
if(diff[0] == diff[1]): or u can use print(set(diff)) then one number {2}
# *************************************************************************
# Write a Python program to reverse the digits of a 
# given number and add it to the original, If the sum 
# is not a palindrome repeat this procedure.

def contpalidrme(n):
    
    while True:
        stt = str(n)
        if(stt == stt[::-1]):
            print("number is palindrome even reverse also")
            break 
        else:
            vals1 = int(stt[::-1])
            n += vals1 
        
    return n,stt

print(contpalidrme(1473))
The number is palindrome even reverse : (9339,4125)

print(contpalidrme(1234))
res: 4321, 5555
# *******************************************************************************
# Write a python program to find heights of the 
# top three building in descending order from eight 
# given buildings.
vals=[34,12,10,15,46,56,66,11]
vals = sorted(vals)
print(vals[:])
print(vals[:4:-1])

vals1 = vals[::-1]
print(vals1[:3])

print(vals[:4]) 
res: [10,11,12,15]

print(vals[:4:-1])
res:[66,56,46]
vals1= vals[:4:-1]
vprint(sorted(vals1))


vals=[34,12,10,15,46,56,66,11]
vals = sorted(vals)
print(vals)
vals1 = vals[:-4:-1]
print(sorted(vals1))

# ****************************************************************************
# Write a Python program to compute the digit number of 
# sum of two given integers.

def cntdigits(x,y):
    return len(str(x+y))

print(cntdigits(5, 9))
# *************************************************
# Write a Python program to check whether three given 
# lengths (integers) of three sides form a right triangle. 
def rghttriangle(vals):
    x,y,z = sorted(vals)
    if(x**2+y**2 == z**2):
        print("right angle triangle")
    else: print("not right angle triangle")
    
# vals =[4,5,6]    
vals=[12,13,5]
print(rghttriangle(vals)) 

(or)
def rghttriangle(vals):
    z = max(vals)
    x = min(vals)
    y = sum(vals)-x-z

    if(x**2+y**2 == z**2):
        print("right angle triangle")
    else: print("not right angle triangle")

(or)
def trngle(vals):
    vals = sorted(vals)
    if(vals[0]**2 + vals[1]**2 == vals[2]**2):
        print("Right angle triangle")

    return
    
# ****************************************************
# Write a Python program which solve the equation
# ax+by=c
# dx+ey=f
# Print the values of x, y where a, b, c, d, e and f are given

# print("Input the value of a, b, c, d, e, f:")
# a, b, c, d, e, f = map(float, input().split())

def slveqn(vals):
    a,b,c,d,e,f = vals
    print(a,b,c,d,e,f)
    
    den = (a*e - d*b)
    x = (e*c -b*f)/den 
    y = (a*f -c*d)/den
    
    return x,y
        
vals =[5,8,6,7,9,4]
print(slveqn(vals))    
# **************************************************************
 # Write a Python program to print the number of prime 
# numbers which are less than or equal to a given integer.

def prme(num):
    if(num > 1):
        for i in range(2,num):
            if(num % i ==0):
                print("not a prime number")
                print(i,"times", num//i, "is",num)
            else: 
                    print("prime number")
                    break
            
        return num
    
print(prme(423))       
# ***************************************************
# Write a Python program to print the number of prime 
# numbers which are less than or equal to a given integer.

def prme_range(bnum,lnum):
    for num in range(bnum,lnum+1):
        if(num > 1):
            for i in range(2,num):
                if(num % i == 0):
                    break 
            else:
                print("%d prime number" %num)
    return num 

print(prme_range(600, 800))
# ******************************BUBBLE sort algorithm*************************
def bsort(a):
    n = len(a)-1
    for i in range(n):
        for j in range(n-i):
            if a[j] > a[j+1]:
                a[j],a[j+1] = a[j+1],a[j]
        
    return a
    
a=[13,24,77,2,109]
print(bsort(a))
res = [2,13,24,72,109]
# ***************************************************************
# Write a Python program to compute the sum of first 
# n given prime numbers

def prmetot(bnum,lnum):
    cnt=0
    tot=0
    for num in range(bnum,lnum+1):
        if(num > 1):
            for i in range(2,num):
                if(num % i ==0):
                    break
            else:
                cnt += 1
                if(cnt <26):
                    tot += num
                print(num,cnt,tot)
    return num,cnt,tot

print(prmetot(10, 200))
# *****************************************************************
# columns swap 
import pandas as pd    
employee = {'EmployeeID' : [0,1,2],
     'FirstName' : ['a','b','c'],
     'LastName' : ['a','b','c'],
     'MiddleName' : ['a','b', None],
     'Contact' : ['(M) 133-245-3123', '(F)a123@gmail.com', '(F)312-533-2442 jimmy234@gmail.com']}

df = pd.DataFrame(employee)

cols = list(df.columns)
a, b = cols.index('LastName'), cols.index('MiddleName')
cols[b], cols[a] = cols[a], cols[b]

cols[1],col[2] = col[2],col[1]

df = df[cols]

# *****************************************************************************
# Mtrix multiplication with out numpy
# multiply matrices without suing numpy
# take a 3x3 matrix 
A = [[12, 7, 3], 
    [4, 5, 6], 
    [7, 8, 9]] 
print(A)

# take a 3x4 matrix     
B = [[5, 8, 1, 2], 
    [6, 7, 3, 0], 
    [4, 5, 9, 1]] 
print(B)
# Matrix multiplication
res = [[0,0,0,0],
      [0,0,0,0],
      [0,0,0,0]]

# iterating by row of A
for i in range(len(A)):
    # print(A[i])
    
    # iterating by column of B
    for j in range(len(B[0])):
        
        # iterating by row of B
        for k in range(len(B)):
            print(A[i][k],B[k][j])
            res[i][j] += A[i][k] * B[k][j]
            
for r in res:
    print(r)

 res: [[114, 160, 60, 27]
	[74, 97, 73, 14]
	[119, 157, 112, 23]]
# ******************************************************************************
# min this matrix add columnwise, if zero come omit the column and go to the next
# column and add values and the total is 9
A = [[0,1,1,2], 
    [0,5,0,0], 
    [2,0,3,3]] 
print(A)
cnt =0
for i in range(len(A[0])):
    for j in range(len(A)):
        if (A[j][i] == 0):
            break
        else:
            cnt += A[j][i]
print(cnt)
# *******************************************************************************
https://www.w3resource.com/python-exercises/basic/  : 65 problems finished                


def commonCharacterCount(s1,s2):
    return sum(min(s1.count(x), s2.count(x)) for x in set(s1))

ss1="abc"
ss2 ="accd"
commonCharacterCount(ss1,ss2)
res: 2

# ***************************************************************************
def isLucky(n):
    n_str = str(n)
    mid = int(len(n_str)/2)

    first =n_str[:mid]
    second = n_str[mid:]

    return (sum([int(i) for i in list(first)])==sum([int(i) for i in list(second)]))

isLucky(12344321)
res: True
# ****************************************************************************
