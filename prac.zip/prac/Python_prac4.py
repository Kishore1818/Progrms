# Given a year, return the century it is in. The first century spans from the 
# year 1 up to and including the year 100, the second - from the year 101 up to and 
# including the year 200, etc.
# For year = 1905, the output should be
# centuryFromYear(year) = 20;
# For year = 1700, the output should be
# centuryFromYear(year) = 17

def centuryFromYear(year):
    return ((year-1) // 100)+1


# Given the string, check if it is a palindrome.
# For inputString = "aabaa", the output should be
# checkPalindrome(inputString) = true;

def checkPalindrome(inputString):
    return inputString == inputString[::-1]
    
print(checkPalindrome('aabaa'))
(or)
def checkPalindrome(inputString):
	str1 = str[::-1]

	return str1==str
	
# Given an array of integers, find the 
# pair of adjacent elements that has the largest product and return that product.
def adjacentElementsProduct(inputArray):
    array = []
    for i in range(len(inputArray)-1):
        array.append(inputArray[i] * inputArray[i+1])
    return max(array)
 
ar = [2,3,4,8,10]
adjacentElementsProduct(ar) 
res=[6,12,32,80]  

# Below we will define an n-interesting polygon. Your task is to find the area of a 
# polygon for a given n.

# A 1-interesting polygon is just a square with a side of length 1. 
# An n-interesting polygon is obtained by taking the n - 1-interesting polygon and 
# appending 1-interesting polygons to its rim, side by side. You can see the 
# 1-, 2-, 3- and 4-interesting polygons in the picture below.
def shapeArea(n):
    area=1
    for i in range(n):
        extra = 4*i
        area += extra
    return area

shapeArea(2)
res; 5
# Ratiorg got statues of different sizes as a present from CodeMaster 
# for his birthday, each statue having an non-negative integer size. 
# Since he likes to make things perfect, he wants to arrange them from smallest to 
# largest so that each statue will be bigger than the previous one exactly by 1. 
# He may need some additional statues to be able to accomplish that. Help him 
# figure out the minimum number of additional statues needed.

# For statues = [6, 2, 3, 8], the output should be
# makeArrayConsecutive2(statues) = 3.

# Ratiorg needs statues of sizes 4, 5 and 7.

def makeArrayConsecutive2(statues):
    n = len(statues)
    fnum = min(statues)
    lnum = max(statues)
    # numbers = arange(fnum,lnum)
    diff = (lnum-fnum)+1 - n
    
    return diff


# Given a sequence of integers as an array, determine whether it is possible to 
# obtain a strictly increasing sequence by removing no more than one element from 
# the array.

# Note: sequence a0, a1, ..., an is considered to be a strictly increasing 
# if a0 < a1 < ... < an. Sequence containing only one element is also considered 
# to be strictly increasing.

# For sequence = [1, 3, 2, 1], the output should be
# almostIncreasingSequence(sequence) = false.

def almostIncreasingSequence(sequence):
    numberErrors =0
    for i in range(0,len(sequence)-1):
        if sequence[i] > sequence[i+1]:
            print(i,sequence[i],nerrors)
            numberErrors+=1
        
    return numberErrors < 2

seq=[12,11,14,15]
almostIncreasingSequence(seq)
0 12 0

True

# After becoming famous, the CodeBots decided to move into a new building together. 
# Each of the rooms has a different cost, and some of them are free, but there's a 
# rumour that all the free rooms are haunted! Since the CodeBots are quite 
# superstitious, they refuse to stay in any of the free rooms, or any of the rooms 
# below any of the free rooms.

# Given matrix, a rectangular matrix of integers, where each value represents the 
# cost of the room, your task is to return the total sum of all rooms that are suitable 
# for the CodeBots (ie: add up all the values that don't appear below a 0).

# matrix = [[0, 1, 1, 2], 
#           [0, 5, 0, 0], 
#           [2, 0, 3, 3]]

# the output should be
# matrixElementsSum(matrix) = 9


def matrixElementsSum(matrix):
    cnt = 0
    for i in range(len(matrix[0])):
        for j in range(len(matrix)):
            if(matrix[j][i] == 0):
                break
            else:
                cnt += matrix[j][i]
    return cnt


# Given an array of strings, return another array containing all of its longest strings.

# For inputArray = ["aba", "aa", "ad", "vcd", "aba"], the output should be
# allLongestStrings(inputArray) = ["aba", "vcd", "aba"].

def allLongestStrings(inputArray):
    longest_len = 0
    longest_string = []
    for i in inputArray:
        if len(i) > longest_len:
            longest_len = len(i)
            longest_string = [i]
        elif len(i) == longest_len: 
            longest_string.append(i)
            
    return longest_string

(or)
def lngeststr(inpt):
    len_strr =0
    new_strr=[]
    for i in inpt:
        if(len(i) >= len_strr):
            len_strr = len(i)
            new_strr.append(i)
#         elif len(i) == len_strr:
#             new_strr.append(i)
        
    return new_strr
    
inpt = ["aba", "aa", "ad", "vcd", "aba"]
lngeststr(inpt)
res = ['aba', 'vcd', 'aba']

(or)
inptt = ["abaf", "aa", "ad", "vcdd", "aba"]

len_st = 0
new_strr =[]
for i in inptt:
    if(len(i) >= len_st):
        len_st = len(i)
        new_strr.append(i)
print(new_strr)
res : ['abaf', 'vcdd']

# Given two strings, find the number of common characters between them.
# For s1 = "aabcc" and s2 = "adcaa", the output should be
# commonCharacterCount(s1, s2) = 3.

# Strings have 3 common characters - 2 "a"s and 1 "c".

def commonCharacterCount(s1, s2):
    # commons = ''.join(set(s1).intersection(s2))
    commons = set.intersection(set(s1),set(s2))
    commons = list(commons)
    # commons = set.intersection(set(s1) and set(s2))
    
    counter =0
    for common in commons:
        count1=0
        count2=0
        for letter1 in s1:
            if letter1 == common:
                count1 +=1
        for letter2 in s2:
            if letter2 == common:
                count2+=1
        counter = min(count1,count2)+counter
    return counter


# Ticket numbers usually consist of an even number of digits. A ticket number 
# is considered lucky if the sum of the first half of the digits is equal to the 
# sum of the second half.


    # For n = 1230, the output should be
    # isLucky(n) = true;
    # For n = 239017, the output should be
    # isLucky(n) = false.

def isLucky(n):
    nstr = str(n)
    nn = (int(len(nstr)/2))
    p1 = nstr[:nn]
    p2 = nstr[nn:]
    sum1=0
    sum2=0
    for i in range(nn):
        sum1 += int(p1[i])
        sum2 += int(p2[i])
    return(sum1 == sum2)

# Some people are standing in a row in a park. There are trees between them which 
# cannot be moved. Your task is to rearrange the people by their heights in a 
# non-descending order without moving the trees. People can be very tall!    

# Given a ticket number n, determine if it's lucky or not.

# For a = [-1, 150, 190, 170, -1, -1, 160, 180], the output should be
# sortByHeight(a) = [-1, 150, 160, 170, -1, -1, 180, 190].

def sortByHeight(a):
    n = len(a)
    
    gnum = []
    for i in a:
        if i > 0:
            gnum.append(i)
    
    
    gnum.sort()
    n=0
    for j in range(len(a)):
        if(a[j] > 0):
            a[j] = gnum[n]
            n+=1
            
    return a


# Write a function that reverses characters in (possibly nested) parentheses 
# in the input string.

# For inputString = "(bar)", the output should be
# reverseInParentheses(inputString) = "rab";
# For inputString = "foo(bar)baz", the output should be
# reverseInParentheses(inputString) = "foorabbaz";

def reverseInParentheses(inputString):
    s = inputString
    for i in range(len(s)):
        if s[i] == '(':
            start = i 
            print(s[:start])
        if s[i] == ")":
            end = i 
            print(end)
            # return reverseInParentheses(s[:start]+s[start+1:end][::-1] + s[end+1:])
            newstr = (s[:start]+s[start+1:end][::-1]+s[end+1:])

    return newstr


#  Several people are standing in a row and need to be divided into two teams. 
#  The first person goes into team 1, the second goes into team 2, the third goes i
#  nto team 1 again, the fourth into team 2, and so on.

# You are given an array of positive integers - the weights of the people. 
# Return an array of two integers, where the first element is the total weight of team 1, and the second element is the total weight of team 2 after the division is complete.

# Input strings will always be well-formed with matching ()s.

For a = [50, 60, 60, 45, 70], the output should be
alternatingSums(a) = [180, 105].

def alternatingSums(a):
    
    n = len(a)
    team_a =0
    team_b = 0
    
    for i in range(n):
        if(i % 2 ==0):
            team_b += a[i]
        else:
            team_a += a[i]
    return [team_b, team_a]

# Given a rectangular matrix of characters, add a border of asterisks(*) to it.
picture = ["abc",
           "ded"]

the output should be

addBorder(picture) = ["*****",
                      "*abc*",
                      "*ded*",
                      "*****"]

def addBorder(picture):
    cnt = len(picture[0])
    get = "*"*(cnt+2)
    ast = []
    ast.append(get)
    for i in range(len(picture)):
        ast.append("*" + picture[i] + "*")
    ast.append(get)

    return ast

# Two arrays are called similar if one can be obtained from another by swapping 
# at most one pair of elements in one of the arrays.

# Given two arrays a and b, check whether they are similar.



For a = [1, 2, 3] and b = [1, 2, 3], the output should be
areSimilar(a, b) = true.

The arrays are equal, no need to swap any elements.


def areSimilar(a, b):
    # b.sort()
    # if(sorted(a) == sorted(b)):
    #     return True
    # else:
    #     return False
    if a == b:
        return True 
    elif sorted(a) != sorted(b):
        return False 
    else:
        count =0
        for i in range(len(a)):
            if a[i] != b[i]:
                count += 1
            if count == 3:
                return False 
        return True
        
# You are given an array of integers. On each move you are allowed to 
# increase exactly one of its element by one.
# Find the minimal number of moves required to obtain a strictly increasing 
# sequence from the input.
For inputArray = [1, 1, 1], the output should be
arrayChange(inputArray) = 3.

def arrayChange(inputArray):
    k = 0
    
    for i in range(1,len(inputArray)):
        diff = inputArray[i]-inputArray[i-1]
        if diff <= 0:
            inputArray[i] = inputArray[i]-diff+1
            k =k-diff+1
    return k
            

# Given a string, find out if its characters can be rearranged to form a palindrome(good one)
For inputString = "aabb", the output should be
palindromeRearranging(inputString) = true.

We can rearrange "aabb" to make "abba", which is a palindrome.

def palindromeRearranging(inputString):
    char = set(inputString)
    cnt = 0
    
    for y in char:
    	print(y,inputString.count(y),inputString.count(y)%2,cnt)
        if inputString.count(y)%2 ==1:
            cnt+=1
    return cnt <=1
            

# Call two arms equally strong if the heaviest weights they each are able to lift are equal.

# Call two people equally strong if their strongest arms are equally strong 
# (the strongest arm can be both the right and the left), and so are their weakest arms.

# Given your and your friend's arms' lifting capabilities find out if you two 
# are equally strong.

    For yourLeft = 10, yourRight = 15, friendsLeft = 15, and friendsRight = 10, the output should be
    areEquallyStrong(yourLeft, yourRight, friendsLeft, friendsRight) = true;
    For yourLeft = 15, yourRight = 10, friendsLeft = 15, and friendsRight = 10, the output should be
    areEquallyStrong(yourLeft, yourRight, friendsLeft, friendsRight) = true;
    For yourLeft = 15, yourRight = 10, friendsLeft = 15, and friendsRight = 9, the output should be
    areEquallyStrong(yourLeft, yourRight, friendsLeft, friendsRight) = false.

def areEquallyStrong(yourLeft, yourRight, friendsLeft, friendsRight):
    
    myarm = (yourLeft,yourRight)
    friend = (friendsLeft,friendsRight)
    
    return max(myarm) == max(friend) and min(myarm) == min(friend)
    

# Given an array of integers, find the maximal absolute difference between 
# any two of its adjacent elements.
For inputArray = [2, 4, 1, 0], the output should be
arrayMaximalAdjacentDifference(inputArray) = 3.

def arrayMaximalAdjacentDifference(inputArray):
    max_diff=0
    for i in range(1,len(inputArray)):
        max_diff = max(abs(inputArray[i]-inputArray[i-1]), max_diff)
    return max_diff
    
(or)
def adjdiff(inputArray):
    diff=[]
    for i in range(1,len(inputArray)):
        diff.append(abs (inputArray[i]-inputArray[i-1]))
        
    return max(diff)

inputArray = [2, 4, 1, 0]
adjdiff(inputArray)
res =3
# *************************************************************************
LeetCode (kisskishore LeetCodeKiss9$)

def ldif(target,arr):
    target = sorted(target)
    arr = sorted(arr)
         
    cnt =0
    for i in range(len(target)):
        diff = target[i]-arr[i]
        if(diff == 0):
            cnt+=1
    
    if(cnt == len(target)):
        return True
    else:
        return False

target =[2,3,7,6]
arr=[3,2,6,7]
ldiff(target,arr)
res: True
# ****make as a function
arr = [17,18,5,4,6,1]
s =[]
for i in range(len(arr)):
    if i == len(arr)-1:
        arr(i)=-1
    else:
        arr[i] = max(arr[i+1:])
# *************************************************    

# Given triangle, find the minimum path sum from top to bottom
# and summ it

# T = [ [2],
#           [3,4],
#           [6,5,7],
#           [4,1,8,3]]
# T =[[-1],[2,3],[1,-1,3]]
# T =[[1],[2,3],[1,2,-5000]]
# T = [[1],[3,2],[-500,1,1],[4,5,6,1]]

T = [[1],[2,1],[-500,2,1],[4,3,2,1],[5,4,3,2,1]]
n = len(T)
S = [0] *(n+1)
while (n>0):
    for i in range(0,n):
        S[i] = T[n-1][i] + min(S[i],S[i+1])
    
        print(S[i])
    n-=1
print(S[0])  

****************************************************
test_str1 = 'GeeksforGeeks'
test_str2 = 'Codefreaks'

# get string intersection 
res = set(test_str1).intersection(set(test_str2))
print(res)
res1 = " ".join(res)
print(res1)

res2 = " ".join(map(str,res1))
print(res2)  



# surface area of a cube
The surface area of a rectangular prism of height h sitting on a 1x1 square = 2 + 4 * h.

The overlap (double counting) of surface area between a prism and a neighboring prism is 2 * min(h(curr), h(nei)). This is because each of the two prisms is double counting the face that touches, e.g. the face that represents the minimum of the two heights.

We only want to look at neighbors that are behind the current prism in either direction (e.g. left or above) to subtract the double counted faces. Alteratively, you could also subtract neighbors ahead of the current prism (right or below) and change the if statement logic to i < len(grid) - 1, j < len(grid[0]) - 1.

class Solution:
  def surfaceArea(self, grid: List[List[int]]) -> int:
    sa = 0
    
    for i in range(len(grid)):
      for j in range(len(grid[0])):
        curr = grid[i][j]
        if curr:
          sa += 2 + 4 * curr
          if i > 0:
            sa -= 2 * min(grid[i-1][j], curr)
          if j > 0:
            sa -= 2 * min(grid[i][j-1], curr)
    
    return sa
Ex:
input = [[2]]
output = 10

input = [[1,2],[3,4]]
output = 34

input =[[1,0],[0,2]]
output = 16


*************************************
# path cross: it should come to (0,0) that is correct after that it can turn

def dirpat(paths):
    x = y =0
    newpath = {(0,0):True}
    for i in path:
        if(i == 'N'):
            y =+1
        elif i == 'E':
            x += 1
        elif i == 'S':
            y -= 1
        else:
            if(i == 'W'):
                x -= 1
#             print(x,y)
        if newpath.get((x,y)):
           return True
        newpath[(x,y)] = True

    return False

path="NES"
dirpat(path)
res: False

path="NESWW"
drpat(path)
res: True

path='NESS'
dirpat(path)
res: False





***************************************************

def lperimeter(A):
    
    perm=0
    if(len(A) <=3):
        if( A[0] + A[2] > A[1]):
            perm = A[0]+A[1]+A[2]
    
    if(len(A) > 3):
        for i in range(len(A)):
            bases = A[i:i+3]
            if(bases[0]+bases[2]>bases[2]):
                perm=(bases[0]+bases[1]+bases[2])
            
            print(bases,perm)
        
    return perm
        
        
A=[2,1,2] =5
A=[1,2,1]=0
A=[3,2,3,4] = 10
lperimeter(A)

Leetcode (976)

Given an array A of positive lengths, return the largest perimeter of a triangle with non-zero area, formed from 3 of these lengths.

If it is impossible to form any triangle of non-zero area, return 0.

 

Example 1:

Input: [2,1,2]
Output: 5

Example 2:

Input: [1,2,1]
Output: 0
Example 3:

Input: [3,2,3,4]
Output: 10

Example 4:

Input: [3,6,2,3]
Output: 8


# *************************************************************
list of dicitionaries handling
import numpy as np

# input
lst = [{'Eva': [4, 8, 2]}, {'Ana': [57, 45, 57]}, {'Ada': [12]}]
print(lst)


res = []
for item in lst:
    print(item)
    for k,v in item.items():
        print(v)
        avg = np.average(v)
        res.append({l:avg})

print(res)

******************another type of dictionaries lst
import numpy as np
input1 = [
    {
        'key':'list1',
        'values':[1,2,3,55]
    },
    {
        'key':'list2',
        'values':[1,5,6,7,8,9]
    }
]

def listStd(inp):
    myDict = {}
    for dic in inp:
        myDict[dic['key']] = np.std(dic["values"])
    return myDict 

listStd(input1)
*******************************************************************