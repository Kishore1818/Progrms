#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 15:55:53 2020

@author: jayanthikishore
"""

# *****userinput while loops
# name = input("pl. enter your name: ")
# print("Hello",name)

# name1 = input("print family name :")
# print("Family name: ",name1)

# ********Modulo operator
# print(5 % 2)

# *******printing even or odd number
# number = input("print any number :")
# number = int(number)
# if number %2 == 0:
#     print("even number")
# else:
#     print("odd number")

# *****************The while loop in action
# num =1
# while num <10:
#     print(num)
#     num+=1
    
# prompt = "\nTell me something, and I will repeat it back to you:"
# prompt += "\nEnter 'quit' to end the program. "
# print(prompt)

# message=""
# while message != 'quit':
#     message = input(prompt)
#     print(message)
    
# (or)
# prompt="quit"
# active = True 
# while active:
#     message = input(prompt)
    
#     if message == 'quit':
#         active = False
#     else:
#         print(message)
        
x=1
while x<=5:
    print(x)
    x+=1
    
# **********************************remove using while loop
pets = ['dog', 'cat', 'dog', 'goldfish', 'cat', 'rabbit', 'cat']
print(pets)

while 'cat' in pets:
    pets.remove('cat')

print(pets)

nms = list(range(1,5))
print(nms)

ben =['good','normal','bad','good','bad']
print(ben)
while 'bad' in ben:
    ben.remove('bad')
print(ben)