
if external hard disk not shown then pl. do this things
diskutil list
diskutil info disk2


copy dir and sub directories from one place to another place

rsync -av * /Volumes/Kishore_mlw/Preetham_100gb/

http://localhost:8888/notebooks/Desktop/Work/ML_EIT/NLP_group/Untitled3.ipynb

Write a Python function that takes a sequence of numbers and determines 
whether all the numbers are different from each other

def dfrnt(num):
    if(len(num) == len(set(num))):
        return True
    else:
        return False
dfrnt(num)
num=[1,2,3,5,6,1]
Res: False
*********************************************************************
Write a Python program to count the number of characters (character frequency) in a string.
strr = "google.com"
sett = (set(strr))
# strr1= ''.join(sett)
strr1 = list(sett)
print(strr1)
chcnt=[]
for st in strr1:
    cnt =0
    for st1 in strr:
        if(st == st1):
            cnt+=1
            print(st,st1,cnt)
    chcnt.append(cnt)
print(chcnt)
res: [1, 1, 1, 3, 2, 1, 1]

(or)
def char_freq(str1):
    dict = {}
    for n in str1:
        keys = dict.keys()
        if n in keys:
            dict[n] +=1
        else:
            dict[n] = 1
    return dict
print(char_freq('google.com'))
{'g': 2, 'o': 3, 'l': 1, 'e': 1, '.': 1, 'c': 1, 'm': 1}

(or)
def chrcnt(str):
    str1 = str.replace('.','')
    count=dict()
    
    for st in str1:
        if st in count:
            count[st]+=1
            
        else:
            count[st]=1
            
    return count
    stm="google.com"
    chrcnt(stm)
 res:
 {'g': 2, 'o': 3, 'l': 1, 'e': 1, 'c': 1, 'm': 1}
**********************************************************************
Write a Python program to get a string made of the first 
2 and the last 2 chars from a given a string. If the string 
length is less than 2, return instead of the empty string.

strr = "w3resource"
def chkstr(strr):
    return strr[:2]+strr[-2:]

chkstr(strr)   
res: 'w3ce'
**************************
Write a Python program to get a string from a given string where all occurrences of its 
first char have been changed to '$', except the first char itself.
strr = 'restart'
char = strr[0]
strr= strr.replace(char,"$")
strr = char + strr[1:]
print(strr)
res:resta$t
************************************************************
Write a Python program to find the first appearance of the substring 'not' and 'poor' 
from a given string, if 'not' follows the 'poor', replace the whole 'not'...'poor' 
substring with 'good'. Return the resulting string.
Sample String : 'The lyrics is not that poor!'
Expected Result : 'The lyrics is good!'

stt ='The lyrics is not that poor!'

snot = stt.find('not')
spoor = stt.find('poor')

stt = stt.replace(stt[snot:(4+spoor)],'good')
print(stt)

(or)
stt ='The lyrics is not that poor!'
def repl(strr):
    snot = strr.find('not')
    spoor = strr.find('poor')
    
    if(spoor > snot):
        strr = strr.replace(strr[snot:(4+spoor)],'good')
    else:
        strr = strr
    return strr

repl(stt)

or
stt ='The lyrics is not that poor!'

snot = stt.find('not')
print(snot)
nstrr = stt[:14]+'Good!'
print(nstrr)

********************************************************************************
# Write a Python program to count the occurrences of each word in a given sentence.

stm = 'the quick brown fox jumps over the lazy dog.'
words = stm.split()
count = dict()
for wrd in words:
    if wrd in count:
        count[wrd]+=1
    else:
        count[wrd] = 1
print(count)
res: {'the': 2, 'quick': 1, 'brown': 1, 'fox': 1, 'jumps': 1, 'over': 1, 'lazy': 1, 'dog.': 1}

(or)
def cnts(strr):
    words = strr.split()
    count = dict()
    
    for wrd in words:
        if wrd in count:
            count[wrd]+=1
        
        else:
            count[wrd] = 1
    
    return count

stm = 'the quick brown fox jumps over the lazy dog.'
cnts(stm)
res: {'the': 2, 'quick': 1, 'brown': 1, 'fox': 1, 'jumps': 1, 'over': 1, 'lazy': 1, 'dog.': 1}
************************************************************************************************
Write a Python program that accepts a comma separated sequence of 
words as input and prints the unique words in sorted form 

stt = input("comma seperated words:")

words = [wrd for wrd in stt.split(',')]

newrd1 = sorted(list(set(words)))
newrd = ",".join(newrd1)

print(newrd)

input: red,green,blue,yellow,red
res: blue,green,red,yellow


(or)
strr = "red,green,yellow,blue,red"
print(strr)

words = strr.split(",")
print(words)

newrd = sorted(list(set(words)))
print(newrd)

newrd1 = ','.join(newrd)
print(newrd1)
res:
red,green,yellow,blue,red
['red', 'green', 'yellow', 'blue', 'red']
['blue', 'green', 'red', 'yellow']
blue,green,red,yellow
***************************************************************
def add_tags(tag,word):
    return "<%s>%s<%s>" %(tag,word,tag)

 add_tags('b', 'Python module') 
 res: '<b>Python module<b>'

 ***************************************************************
 def insert_sting_middle(symb,word):
    print(symb[:2]+word +symb[2:])
    
    return

insert_sting_middle('{{}}', 'Python')

res:{{Python}}
***************************************************************
def insert_end(strr):
    str1= (strr[-2:])
    str1 = str1*4
    
    return str1

insert_end('python')
res:'ononon'
****************************************************************
stt = 'https://www.w3resource.com/python-exercises/string'

newstr = stt.rsplit("/",1)[0]
print(newstr)
newstr = stt.rsplit("-",1)[0]
print(newstr)

res:
https://www.w3resource.com/python-exercises
https://www.w3resource.com/python

newstr = stt.rsplit("/",2)[0]
res: https://www.w3resource.com
*******************************************************************
remove new line 

st ="python exercises\n"

stt = st.rsplit("\n",1)[0]
print(stt)
print(st.rstrip())

res:
python exercises
python exercises
******************************************************************
write a python program check weather a string starts with specified character

st="w3resource"

print(st.startswith("w3r"))
res: True
************************************************************************
print upto two decomal digitis
ress = 26.23345

print("%.2f" %ress)
26.23

*************************************************************************
# Write a Python program to reverse words in a string.
str1 = 'The quick brown fox jumps over the lazy dog.'
words = str1.split()
print(words[::-1])
*************************************************************************
stt = "The quick brown fox jumps over the lazy dog."
def strip_chars(strr,chars):
    #chars = "aeiou"
    newstr = ''.join(chr for chr in strr if chr not in chars)
    
    return newstr

strip_chars(stt,"aeiou")
*************************************************************************
Write a Python program to count repeated characters in a string.
stm = 'thequickbrownfoxjumpsoverthelazydog'

print(len(stm))
unq1 = set(stm)
unq = list(unq1)
print(unq,len(unq1))

unq2 = ''.join(unq1)
# print(unq2)

# for st in unq2:
for st in unq:
    cnt=0
    for ch in stm:
        if(st == ch):
            cnt+=1
    if(cnt > 1):       
        print(st,cnt)

res: 
h 2
t 2
u 2
o 4
r 2
e 3

(or)
stm = 'thequickbrownfoxjumpsoverthelazydog'

def rept(str):
    
    newstr = list(set(stm))
    
    count = dict()
    for ch in stm:
        if(ch in count):
            count[ch]+=1
            
        else:
            count[ch]=1

    return count

rept(stm)
*************************************************************************
area =1245.22
volume = 2356.45
print("%7.2f cm\u00b2" %area)
print("%7.2f cm\u00b3" %volume)

res:
1245.22 cm²
2356.45 cm³
**************************************************************************
Write a Python program to print the index of the character in a string

stt ="w3resource"

for i, ch in enumerate(stt):
    print("current character",ch,"position",i)

res:
current character w position 0
current character 3 position 1
.... ..... ....
current character c position 8
current character e position 9

****************************************************************************
Write a Python program to lowercase first n characters in a string
stt ="W3SOURCE.COM"

newstr = stt[:4].lower()+stt[4:]
print(newstr)
res: w3soURCE.COM
******************************************************************************
Write a Python program to swap comma and dot in a string.
amount = "32.054,23"
maketrans = amount.maketrans
amount = amount.translate(maketrans(',.', '.,'))
print(amount)
res: 32,054.23
*****************************************************************************
Write a Python program to count and display the vowels of a given text

def cntt(strr):
    vwls = 'aeiouAEIOU'
    
    newst = [char for char in strr if char in vwls]
    
    print(len(newst))
    return (newst, len(newst))

stm = "w3source.com"
cntt(stm)   

res:
(['o', 'u', 'e', 'o'], 4)
**********************************************************************
Write a Python program to find the first non-repeating character in given string

newst1 = list(set(stt))
cntt=[]

for st in stt:
    cnt=0
    for chrr in stt:
        if(st == chrr):
            cnt+=1
            #print(st,chrr,cnt)
    cntt.append(cnt)

for i in range(len(stt)):
    if(cntt[i] <2):
        #print(cntt[i],stt[i])
        res=stt[i]
        break
    else:
        res="none"
print(res)

stt = 'abcdef'
ans:a
stt='abcabcdef'
ans:d
stt = "aabbcc"
ans=None 
*****************************************************************
 Write a Python program to print all permutations with 
 given repetition number of characters of a given string.

 stt='xyz'

def perm(stt):
    stt = list(stt)
    
    for i in range(0,3):
        for j in range(0,3):
            for k in range(0,3):
                if(i!=j & j!=k & k!=i):
                    print(stt[i],stt[j],stt[k])
    return stt

perm(stt)
    
x y z
x z y
y x z
y z x
z x y
z y x

(or)
def digit3comb(a,b,c):
    d = []
    d.append(a)
    d.append(b)
    d.append(c)
    
    for i in range(0,3):
        for j in range(0,3):
            for k in range(0,3):
                if(i != j & j != k & k!=i):
                    print(d[i],d[j],d[k])
    return d

digit3comb(3, 4, 5)
3 4 5
3 5 4
4 3 5
4 5 3
5 3 4
5 4 3

(or) general:
def perm1(nums):
    r_perms = [[]]
    for n in nums:
        n_perms=[]
        for perm in r_perms:
            for i in range(len(perm)+1):
                n_perms.append(perm[:i]+[n]+perm[i:])
                r_perms = n_perms
                
    return r_perms
       

arr=[3,4,5]
perm1(arr)
res:
[[5, 4, 3], [4, 5, 3], [4, 3, 5], [5, 3, 4], [3, 5, 4], [3, 4, 5]]
arr=['x','y','z']
res:
[['z', 'y', 'x'],
 ['y', 'z', 'x'],
 ['y', 'x', 'z'],
 ['z', 'x', 'y'],
 ['x', 'z', 'y'],
 ['x', 'y', 'z']]
 *********************************************************************
 Write a Python program to find the first repeated character in a given string.

 # stm='bcdabcd'
stm='abcd'

def rpt(stm):
    stm = list(stm)
    
    mcnt=[]
    for st in stm:
        cnt=0
        for chrr in stm:
            if(st == chrr):
                cnt+=1
                #print(st,chrr,cnt)
        mcnt.append(cnt)
             
    for i in range(len(mcnt)):
        if(mcnt[i] >=2):
            ress=stm[i]
            break
        else:
            ress="none"
            
    return ress


stm='bcdabcd'
rpt(stm): b
stm='abcd'
rpt(stm):None 
****************************************************************
Write a Python program to find the second most repeated word in a given string

stb="Both of these issues are fixed by postponing the evaluation of annotations. Instead of compiling code which executes expressions in annotations at their definition time, the compiler stores the annotation in a string form equivalent to the AST of the expression in question. If needed, annotations can be resolved at runtime using typing.get_type_hints(). In the common case where this is not required, the annotations are cheaper to store (since short strings are interned by the interpreter) and make startup time faster."

def wrdcnt(str):

	words = str.split()
	counts = dict()

	for wrd in words:
		if wrd in counts:
			counts[wrd]+=1

		else:
			counts[wrd] = 1

	counts1 = sorted(counts.items(), key=lambda kv:kv[1])

	return counts1[-2]

wrdcnt(stb)
[('in', 3),
 ('annotations', 3),
 ('of', 4),
 ('the', 8)]

res: ('of',4) 

*********************************************************************************
remove spaces
stbb ="w 3 res ou r ce"

print(stbb.replace(' ',''))
res:
w3resource
*******************************************************************************
Write a Python program to find the maximum occurring character in a given string.

stm = " Welcome to w3resource"

def mxocc(str):
    nstr1 = str.replace(' ','')
    
    #newstr = [chr for chr in nstr1]
    counts = dict()
    for chr in nstr1:
        if chr in counts:
            counts[chr]+=1
            
        else:
            counts[chr]=1
            
    counts1 = sorted(counts.items(), key=lambda kv:kv[1])
    
    return counts1[-1] 

mxocc(stm)
[('W', 1),
 ('l', 1),
 ('m', 1),
 ('t', 1),
 ('w', 1),
 ('3', 1),
 ('s', 1),
 ('u', 1),
 ('c', 2),
 ('r', 2),
 ('o', 3),
 ('e', 4)]
res:('e',4)
*********************************************************************
Write a Python program to capitalize first and last letters of each word of a given string

wrdd ="python exercises practice solution"

def capwrd(wrd):
    wrd = wrd.title()
    words = wrd.split()
    
    nline = ""
    for wrd in words:
        nline += wrd[:-1] + wrd[-1].upper() + " "
        
    return nline

capwrd(wrdd)
res: 'PythoN ExerciseS PracticE SolutioN '
**************************************************************************
Write a Python program to remove duplicate characters of a given string. 

senn ="w3resource"

result = "".join(dict.fromkeys(senn))
print(result)
res: w3resouc
***************************************************************************
Write a Python program to compute sum of digits of a given string.

nums = "123abcd45"

def numcnt(str):
    
    summ=0
    for st in str:
        if(st.isdigit() == True):
            summ+=int(st)
        
    return summ
numcnt(nums)
res: 15
*****************************************************************************
Write a Python program to remove leading zeros from an IP address

dgt ="255.024.01.01"

ndgt = dgt.replace('0','')
print(ndgt)
res: 255.24.1.1
******************************************************************************
Write a Python program to remove leading zeros from an IP address

strr = '111000010000110'

def mxlen(str):
    str1 = max(map(len,str.split('1')))
    
    return str1

mxlen(strr)
res:4

(or)

strr = '1110000100000110'

def cntt(str):
    
    str1 = str.split('1')
    
    count=[]
    for st in str1:
        count.append(len(st))
    
    
    return max(count)

cntt(strr)
res:5
*****************************************************************************
Write a Python program to find all the common characters in lexicographical 
order from two given lower case strings. If there are no common letters print 
"No common characters"

str1='Python'
str2='PHNT'
def cmnstr(strn1,strn2):
    nstr1 = strn1.upper()
    nstr2 = list(set(strn2))

    res1 = [st for st in nstr1 if st in nstr2]
    if(len(nstr2)==len(res1)):
        print(strn2)
        
    else:
        print("no common")
    return 

cmnstr(str1,str2)
res: PHNT
************************************************************************
common totoal characters in both strings

gvn1 = "spearmk"
gvn2 = "pearsuv"

def rmve(str1,str2):
    
    common = [st for st in str1 if st in str2]
    print(common)
    
    cnt1=0
    for st1 in str1:
        if(st1 not in common):
            cnt1+=1
            
    cnt2=0
    for st2 in str2:
        if(st2 not in common):
            cnt2+=1
            
    return (cnt1+cnt2)

rmve(gvn1,gvn2)
res:4
****************************************************************************
picking the common characters from two strings

gvn1 = "spearmk"
gvn2 = "pearsuv"

def cmnt(str1,str2):
    
    commons = [st for st in str1 if st in str2]
    
    newstr1=[]
    for st1 in str1:
        if(st1 in commons):
            newstr1.append(st1)
     
    newstr2=[]
    for st2 in str2:
        if(st2 in commons):
            newstr2.append(st2)
    
    newst1 = ''.join(newstr1)
    newst2 = ''.join(newstr2)
    return newst1,newst2

cmnt(gvn1,gvn2)
res:
('spear', 'pears')
******************************************************************************
Write a Python program to remove all consecutive duplicates of a given string
stm ="aaaaebbb"

def rmve(str):
    st1= set(stm)
    st2 = ''.join(list(st1))
    
    return st2

rmve(stm)
res: aeb 


(or)
def rmve(str):
    return ''.join(list(set(str)))
****************************************************************************
Write a Python program to find the longest common sub-string from two given strings

onest = "abcdefgh"
twost = "xswerabcdwd"

def lngth(str1,str2):

    #first find common characters in both strings
    common= [st for st in str1 if st in str2]
    common1 = ''.join(common)
    print(common,common1)

    #finding the indexes common strings in bigger string(str2)
    indxs=[]
    for st1 in str2:
        indxs.append(common1.find(st1))

    #finding the sequential order
    ostr=[]
    for i in range(len(indxs)-1):
        diff = (indxs[i+1]) - (indxs[i])
        if(diff ==1):
            ostr.append(str2[i+1])
             
    return ''.join(ostr)

lngth(onest,twost)
res: 'abcd'

(or)


def lngest(str1,str2):
    cmmn1 = [st for st in str1 if st in str2]
    cmmn = ''.join(cmmn1)
    
    indx=[]
    for i,st in enumerate(str2):
        if(st in cmmn):
            indx.append(i)
     
    cntstr=[]
    cnt=0
    for j in range(len(indx)-1):
        if(indx[j+1]-indx[j])==1:
            cnt+=1
            if(cnt == 1): cntstr.append(str2[indx[j]])
            cntstr.append(str2[indx[j+1]]) 
    
    cntstr1 = ''.join(cntstr)
    
    return cntstr1

onest = "abcdefgh"
twost = "xswerabcdwd"
lngest(onest,twost)
res: 'abcd'
********************************************************************
Write a Python program to create a string from two given 
strings concatenating uncommon characters of the said strings.

string1 = "abcdpqr"
string2 = "xyzabcd"

def uncmn(str1,str2):
    ucmn1 = [st for st in str1 if st not in str2]
    ucmn2 = [st1 for st1 in str2 if st1 not in str1]
    
    uc1 = ''.join(ucmn1)
    uc2 = ''.join(ucmn2)
    uc3 = uc1+uc2
    return uc3

uncmn(string1,string2)

res:'pqrxyz'
**********************************************************************
Write a Python program to move all spaces to the 
front of a given string in single traversal.

stm = "Python Exercises"

def nospcs(str):
    
    str1 = str.replace(' ','')
    str2 =' '+str1
    
    return str2

nospcs(stm)

res: ' PythonExercises'
**********************************************************************
Write a Python program to remove all consecutive duplicates from a given string.

stb = "LLLRLRR"
seen  = stb[0]
ans = stb[0]

for i in stb[1:]:
    if i != seen:         #if(i not in seen):
        ans +=i
        seen = i
print(ans)
Res:LRLR 

(or)

stb = "aabcdaee"
def adj(str):
    seen = str[0]
    res = str[0]
    
    for st in str[1:]:
        if (st != seen):
            res +=st
            seen = st
            
    return res
adj(stb)
res:
'abcdae'
*************************************************************
Write a Python program to count Uppercase, Lowercase, 
special character and numeric values in a given string.

stg = "@W3Resource.Com"

def cntss(str):
    
    upcnt=0
    lowcnt=0
    splcnt=0
    dgtcnt=0
    for st in str:
        if(st.isupper()):
            upcnt+=1
            
        elif(st.islower()):
            lowcnt+=1
            
        elif(st.isdigit()):
            dgtcnt+=1
            
        else:
            splcnt+=1
        
    return upcnt,lowcnt,dgtcnt,splcnt

cntss(stg)
res: (3,9,1,2)
******************************************************************
stgg =" Wolf Fox Giraffe"

def dist(str):
    
    lowcnt=0
    for st in str:
        if(st.islower()):
            lowcnt+=1
    
    substr = len(str.split())
    return lowcnt,substr

dist(stgg)
res: (11, 3)
********************************************************************
Write a Python program to count characters at same position in a
given string (lower and uppercase characters) as in English alphabet.

xbg = "xbcefg"

def ordd(str):
    
    counts=0
    for i in range(len(str)):
        if((i == ord(str[i]) - ord('A')) or
           (i == ord(str[i]) - ord('a'))):
           counts+=1
    
    return counts
           
ordd(xbg)      

res:2
orer : bc 
**********************************************************************
Write a Python program to find smallest and largest word in a given string.

bstr ="Write a Java program to sort an array of given integers using Quick sort Algorithm."

def lrgst(line):
    
    words = line.split()
    count=[]
    for wrd in words:
        count.append(len(wrd))
            
    # index value counting
    vals = count.index(max(count))
    
    return count, print(words[vals],vals)

lrgst(bstr)
([5, 1, 4, 7, 2, 4, 2, 5, 2, 5, 8, 5, 5, 4, 10], 'Algorithm.', 14)
***********************************************************************************
MAP function
map(function, iterable [, iterable2, iterable3,...iterableN]) --> map object
change to list

map(function, iterable, ...)

    function - map() passes each item of the iterable to this function.
    iterable - iterable which is to be mapped

You can pass more than one iterable to the map() function.

bases=[10, 20, 30, 40, 50]
index=[1, 2, 3, 4, 5]

powers = list(map(pow,bases,index))
print(powers)
res:
[10, 400, 27000, 2560000, 312500000]
*********************************************
items = [1, 2, 3, 4, 5]

sqres = list(map(lambda x: x*x, items))
print(sqres)
res: 
[1,4,9,16,25]

**************************************************
strr = '1110000100000110'

def mapp(str):
    
    print(str.split('1'))
    newstr = list(map(len,str.split('1')))
    print(newstr)
    return max(newstr)

mapp(strr)
res:
['', '', '', '0000', '00000', '', '0']
[0, 0, 0, 4, 5, 0, 1]
5
***********************************************************

nnm = [2,7,11,15] =9
# nnm =[3,2,4] =6
# nnm = [2,5,5,11] =10
# nnm = [-1,-2,-3,-4,-5] =-8
def trn(num):
    nn = len(num)
    
    indx=[]
    cnt=0
    for i in range(nn):
        sno=num[i]
        for j in range(i+1,nn):
            if(sno+num[j] == 9):
                cnt+=1
                if(cnt ==1):
                    indx.append(i)
                    indx.append(j)
        

               
    return indx
trn(nnm)
res : [0,1]
***********************************************
def roman2int(strr):
    translate= {'I' : 1, 'V' : 5, 'X' : 10, 'L' : 50 , 'C' : 100, 'D' : 500, 'M' : 1000}
    
    sum =0
    previous = 'M'
    for numeral in strr:
        print(numeral)
        if (translate[numeral] <= translate[previous]):
            sum += translate[numeral]
            previous = numeral
        else:
            sum = sum +translate[numeral] - 2*translate[previous]
            previous = numeral
            
    return sum
roman2int('XX')
res:20

*******************************************************************
Given an integer array nums, find the contiguous subarray (containing at least one number) 
which has the largest sum and return its sum.
data = [-2,1,-3,4,-1,2,1,-5,4]

def maxsubar(nums):
    dp = [0]*len(nums)
    print(dp)
    dp[0] = nums[0]
    max_num = nums[0]
    
    for i in range(1,len(nums)):
        dp[i] = max(dp[i-1]+nums[i],nums[i])
        print(dp[i-1],dp[i],nums[i])
        if(dp[i]>max_num):
            max_num = dp[i]
            
    return max_num
    
maxsubar(data)
res: 6
**********************************************************************
data = [1,2,3,4,5,0,0,6,7]

i = len(data)
j = 0
while j<i:
    if(data[j] == 0):
        data.pop(j)
        data.append(0)
        i-=1
    else:
        j+=1
data


(or)
X = [1,2,3,4,5,0,0,6,7]
zeros = X.count(0)

zero_lst = [0] * zeros
X = [i for i in X if i != 0]
X.extend(zero_lst)
print(X)

(or)
X = [1,2,4,6,0,0,7,3]

for i in X:
    if i == 0:
        X.remove(i)
        X.append(0)
*********************************************************************















