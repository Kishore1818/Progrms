#!/usr/bin/env python

from __future__ import division
import random

'''
Leetcode: Single Number

Given an array of integers, every element appears twice except for one. Find that single one.
Note: Your algorithm should have a linear runtime complexity. Could you implement it without using extra memory?
'''
def func():
    pass


'''
Leetcode: Single Number II

Given an array of integers, every element appears three times except for one. Find that single one.
Note: Your algorithm should have a linear runtime complexity. Could you implement it without using extra memory?


'''
def func():
    pass


if __name__ == '__main__':
    func()


