#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 21:32:40 2020

@author: jayanthikishore
"""

# *******reading the txt files
# import numpy as np
# clddata = np.loadtxt('/home/jayanthikishore/Downloads/Python/prac/pi_digits.txt',skiprows=0)
# print(clddata.shape)
# print(clddata)


with open('/home/jayanthikishore/Downloads/Python/prac/pi_digits.txt') as file_object:
    contents = file_object.read()
    print(contents)
    # print(contents.rstrip())    

with open('/home/jayanthikishore/Downloads/Python/prac/pi_digits.txt') as file_object:
    for i in file_object:
        print(i)
        
# *****writing into a file************************
filename='/home/jayanthikishore/Downloads/Python/prac/test.txt'

with open(filename,'w') as file_object:
    file_object.write("I love Programming")