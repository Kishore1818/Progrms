# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 11:09:00 2023

@author: kpangalu
"""

import cv2
import os
import glob
import json 
import shutil
import operator
import argparse
import numpy as np
import argparse
import numpy as np
import matplotlib.pyplot as plt
#Import libraries
import torch
import torchvision
from torchvision.io import read_image
from torchvision.utils import draw_bounding_boxes


"""
  Convert the lines of a file to a list
"""
def file_lines_to_list(path):
    # open txt file lines to a list
    with open(path) as f:
        content = f.readlines()
    # remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]
    return content

# with open("/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/RYB_S100_T100_525_org_bbox.txt") as f:
#     contents = f.readlines()
#     print(contents)
 
#*******************reading ground truth bbox values
main_path= "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/"
txt_file = main_path + "TTB_S100_T75_72_org_bbox.txt"
lines_list = file_lines_to_list(txt_file)
print(lines_list)

bboxes = []
cnames = []
for lines in lines_list:
    # print(lines.split())
    class_name, left, top, right, bottom = lines.split()
    bbox1 = [left,top,right,bottom]
    bbox = [int(i) for i in bbox1]
    #print(class_name)
    #print(bbox)
    bboxes.append(bbox)
    cnames.append(class_name)
    
print(bboxes)
print(cnames)

#*********SNPE DLC predictions bbox values(using SNPE_DLC_YOLO_predictions.txt)
main_path1= "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/"
txt_file1 = main_path1 + "TTB_S100_T75_72_snpe_pred.txt"
lines_list1 = file_lines_to_list(txt_file1)
print(lines_list1)

bboxes1 = []
cnames1 = []
for lines1 in lines_list1:
    # print(lines.split())
    class_name, left, top, right, bottom = lines1.split()
    bbox2 = [left,top,right,bottom]
    bbox = [int(i) for i in bbox2]
    #print(class_name)
    #print(bbox)
    bboxes1.append(bbox)
    cnames1.append(class_name)
    
print(bboxes1)
print(cnames1)


# #****only one image multiple icons with bounding boxes
# # read input image
img = read_image(main_path + "reshape_raw/TTB_S100_T75_72.png")
    
bboxes = torch.tensor(bboxes, dtype=torch.int)
bboxes1 = torch.tensor(bboxes1, dtype=torch.int)
# draw bounding boxes on the input image
# img=draw_bounding_boxes(img, bboxes, width=3,labels=cnames,colors=[(255,0,0),(0,255,0)])
img=draw_bounding_boxes(img, bboxes, width=1,labels=cnames,colors=(255,255,0))
img=draw_bounding_boxes(img, bboxes1, width=1,labels=cnames,colors=(255,0,0))
img = torchvision.transforms.ToPILImage()(img)
img.show()
img.save("/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/TTB_S100_T75_72_grndtrht_prd_bbox.png")