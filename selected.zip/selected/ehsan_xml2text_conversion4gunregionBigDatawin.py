#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 22:02:17 2023

@author: eshahria
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 15 15:16:50 2022

@author: eshahria
"""

import xml.etree.ElementTree as ET
import glob
import os
import json
import cv2

def xml_to_yolo_bbox(bbox, w, h):
    # xmin, ymin, xmax, ymax
    x_center = ((bbox[2] + bbox[0]) / 2) / w
    y_center = ((bbox[3] + bbox[1]) / 2) / h
    width = (bbox[2] - bbox[0]) / w
    height = (bbox[3] - bbox[1]) / h
   
    #[x_center, y_center, width, height]
    return [ "{:.2f}".format(x_center), "{:.2f}".format(y_center), "{:.2f}".format(width), "{:.2f}".format(height)]


def yolo_to_xml_bbox(bbox, w, h):
    # x_center, y_center width heigth
    w_half_len = (bbox[2] * w) / 2
    h_half_len = (bbox[3] * h) / 2
    xmin = int((bbox[0] * w) - w_half_len)
    ymin = int((bbox[1] * h) - h_half_len)
    xmax = int((bbox[0] * w) + w_half_len)
    ymax = int((bbox[1] * h) + h_half_len)
    
    
    return [xmin, ymin, xmax, ymax]

# classes = ['explosion','footstep' ,'gunshot','muffledgunshot','vehicle','square']
# input_dir = "./data_custom/minimap/minimapLR1200_train_label/"
# output_dir = "./data_custom/minimap/minimapLR1200_train_label4yolo/"
# image_dir = "./data_custom/minimap/minimapLR1200_train_images/"

classes = ['gunroi_left','gunroi_right', 'bullet_left', 'bullet_right', 'knife_left','knife_right']
# image_dir= '/local/mnt2/qtlvas/users/eshahria/workspace/COD/GunRegion/data_auto/RYB/images/540x1200/GeneratedData4test/'
# output_dir ='/local/mnt2/qtlvas/users/eshahria/workspace/pytorch-workspace/objectdetection/yolov5-main/yolov5/data_custom/gunregionBigData_Tcut50Scut70/labels/val/'
# output_dir4images ='/local/mnt2/qtlvas/users/eshahria/workspace/pytorch-workspace/objectdetection/yolov5-main/yolov5/data_custom/gunregionBigData_Tcut50Scut70/images/val/'

# image_dir = "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/RYB_frames_labeled/data/GeneratedData4test/"
image_dir = "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/RYB_frames_labeled/trial/S100_T100/S100_T100/S100_T100_frames/GeneratedData4test/"
output_dir = "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/RYB_frames_labeled/RYBS100T100/labels/val/"
output_dir4images = '/Users/kpangalu/Downloads/scale_transparencies_battlemodes/RYB_frames_labeled/RYBS100T100/images/val/'

# output_dir = "/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/data_folder/Yolo5_COD_customdata/labels/val/"
# output_dir4images = '/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/data_folder/Yolo5_COD_customdata/images/val/'

input_dir = image_dir 
# create the labels folder (output directory)
# os.mkdir(output_dir)

# identify all the xml files in the annotations folder (input directory)
files = glob.glob(os.path.join(input_dir, '*.xml'))


# loop through each 
i=0
for fil in files:
    print( i,i/len(files))
    i+=1
    # basename = os.path.basename(fil)
    slashindex= [i for i, ltr in enumerate(fil) if ltr == '\\']
    basename= fil[max(slashindex)+1:]
    #filename = os.path.splitext(basename)[0]
    filename = basename[:-4]
    # check if the label contains the corresponding image file
    if not os.path.exists(os.path.join(image_dir, f"{filename}.jpg")):
        print(f"{filename} image does not exist!***********************************")
        break

    result = []
    img = cv2.imread(os.path.join(image_dir, f"{filename}.jpg"))
    cv2.imwrite(os.path.join(output_dir4images, f"{filename}.jpg"), img)
    # parse the content of the xml file
    tree = ET.parse(fil)
    root = tree.getroot()
    width = int(root.find("size").find("width").text)
    height = int(root.find("size").find("height").text)

    blanksignal= 1
    for obj in root.findall('object'):
        label = obj.find("name").text
        # check for new classes and append to list
        if label not in classes:
            classes.append(label)
        index = classes.index(label)
        pil_bbox = [int(x.text) for x in obj.find("bndbox")]
        yolo_bbox = xml_to_yolo_bbox(pil_bbox, width, height)
        # convert data to string
        bbox_string = " ".join([str(x) for x in yolo_bbox])
        result.append(f"{index} {bbox_string}")

    # if result:
        # generate a YOLO format text file for each xml file
        with open(os.path.join(output_dir, f"{filename}.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(result))
            blanksignal= 0
            
    if blanksignal==1:
        print('blanksignal ============================================')
        result=[]
        with open(os.path.join(output_dir, f"{filename}.txt"), "w", encoding="utf-8") as f:
            f.write("\n".join(result))
        

# generate the classes file as reference
with open('classes.txt', 'w', encoding='utf8') as f:
    f.write(json.dumps(classes) )                                               
            
          
            
# create train list : 
for fil in  files:
    with open('train.txt', 'w', encoding='utf8') as f:
        f.write(json.dumps(fil) )                                               
            
            
len(os.listdir(output_dir))
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            