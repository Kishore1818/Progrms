# -*- coding: utf-8 -*-
"""
Created on Fri Jan  6 13:28:01 2023

@author: kpangalu
"""
import os
import json

mpath = "C:/Users/kpangalu/Downloads/Audiodata_collection/Dec2022_audio/analysis/"

cnt = 0
for dir_pth, dir_nmes,f_names in os.walk(mpath):
    # if(len(dirnames) > 0):
    #     print(len(dirnames),dirnames,type(dirnames))
    
    for dir_nme in dir_nmes:
        if dir_nme == 'explosion':
           explosion_dir = dir_pth + '/'+dir_nme+'/'
           exp_ndirs = os.listdir(explosion_dir)
           print(exp_ndirs)
           for exp_dir in exp_ndirs:
               print(exp_dir)
               exp_files = os.listdir(os.path.join(explosion_dir,exp_dir))
               for file in exp_files:
                   fle1 = explosion_dir +exp_dir +'/'+file 
                   if(file == 'annotation.json'):
                       afile = open(fle1,'r')
                       data = json.load(afile)
                       num_explsions= data["Num_ROIs"] 
                       cnt += num_explsions
print("Count number of explosions: ",cnt)                                 
