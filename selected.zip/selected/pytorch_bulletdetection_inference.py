#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 00:02:06 2022

@author: eshahria
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import torchvision
import os
import cv2


  
# Define MNIST MODEL ----------------------------------------------------------
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv1.weight)
        self.conv2 = nn.Conv2d(16, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv2.weight)
        self.drop1 = nn.Dropout2d(0.3)
        self.drop2 = nn.Dropout(0.5)
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(800, 64)
        # nn.init.xavier_normal_(self.fc1.weight)
        self.fc2 = nn.Linear(64, 302)
        # nn.init.xavier_normal_(self.fc2.weight)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(F.relu(self.conv2(x)) , 2)
        x= self.drop1(x)
        x= self.flatten(x)
        x= self.fc1(x)
        x= self.drop2(x)
        x= self.fc2(x)
        # return F.log_softmax(x, dim=1)
        return x
        
        
        
network = Net() # model initialization 
# load saved model 
network.load_state_dict(torch.load('./chkpoint/acc_0.9988_iter_66_model.pth'))
network.eval() # use for evaluation to remove dropout layers , ....

# load Test data---------------------------------------------------------------
TestRoot = './data/Muhua_Test/'

Testfilelist= os.listdir(TestRoot)

for imgindex in range(len(Testfilelist)):         
    target = Testfilelist[imgindex][0:3]
    imgcrop  = cv2.imread(TestRoot+Testfilelist[imgindex],0)
    imgcrop = np.float32(imgcrop)
    imgcrop= imgcrop/ np.max(imgcrop)
    imgcrop= imgcrop.reshape([1,1,14,24])
     
    # inference ------
    input_torch = torch.from_numpy(imgcrop)
    test_pred = network(input_torch)
    test_pred_class_label= torch.argmax(test_pred, dim=1).item()

    print( f'target :   { target} , prediction {test_pred_class_label} ')


