# -*- coding: utf-8 -*-
"""
Created on Tue Jan  3 15:32:58 2023

@author: kpangalu
"""

import numpy as np
import librosa

audio_data = "/Users/kpangalu/Downloads/audio_features/recorded_vignesh.wav"
# audio_data = '/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/test_folder/testing_purpose.wav'
data , samplingrate = librosa.load(audio_data)
print(type(data), type(samplingrate))
print(data.shape, samplingrate)

#estimating the audio fle duration
audfile = (len(audio_data) / 1000.)
duration_mins = int(audfile // 60)
duration_in_secs = round((audfile % 60),3)
print("minutes: ", duration_mins, ";", "seconds: ",duration_in_secs)

#This returns an audio time series as a numpy array with a default sampling rate(sr) of 22KHZ mono. 
#We can change this behavior by resampling at 44.1KHz.

import IPython.display as ipd
ipd.Audio(audio_data)

#%matplotlib inline
import matplotlib.pyplot as plt
import librosa.display
plt.figure(figsize=(14, 5))
librosa.display.waveshow(data, sr=samplingrate)

X = librosa.stft(data)
Xdb = librosa.amplitude_to_db(abs(X))
plt.figure(figsize=(14, 5))
librosa.display.specshow(Xdb, sr=samplingrate, x_axis='time', y_axis='hz')
plt.colorbar()

librosa.display.specshow(Xdb, sr=samplingrate, x_axis='time', y_axis='log')
plt.colorbar()

import numpy as np
sr = 22050 # sample rate
T = 5.0    # seconds
t = np.linspace(0, T, int(T*samplingrate), endpoint=False) # time variable
x = 0.5*np.sin(2*np.pi*220*t)# pure sine wave at 220 Hz
#Playing the audio
ipd.Audio(data, rate=samplingrate) # load a NumPy array
#Saving the audio
# librosa.output.write_wav('/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/test_folder/tone_220.wav', x, sr)
import soundfile as sf
sf.write('/Users/kpangalu/Downloads/audio_features/tone_220.wav', x, sr)

import sklearn
spectral_centroids = librosa.feature.spectral_centroid(x, sr=sr)[0]
spectral_centroids.shape
(775,)
# Computing the time variable for visualization
plt.figure(figsize=(12, 4))
frames = range(len(spectral_centroids))
t = librosa.frames_to_time(frames)
# Normalising the spectral centroid for visualisation
def normalize(data, axis=0):
    return sklearn.preprocessing.minmax_scale(data, axis=axis)
#Plotting the Spectral Centroid along the waveform
librosa.display.waveshow(data, sr=samplingrate, alpha=0.4)
plt.plot(t, normalize(spectral_centroids), color='b')

spectral_rolloff = librosa.feature.spectral_rolloff(x+0.01, sr=samplingrate)[0]
plt.figure(figsize=(12, 4))
librosa.display.waveshow(x, sr=samplingrate, alpha=0.4)
plt.plot(t, normalize(spectral_rolloff), color='r')

spectral_bandwidth_2 = librosa.feature.spectral_bandwidth(data+0.01, sr=samplingrate)[0]
spectral_bandwidth_3 = librosa.feature.spectral_bandwidth(data+0.01, sr=samplingrate, p=3)[0]
spectral_bandwidth_4 = librosa.feature.spectral_bandwidth(data+0.01, sr=samplingrate, p=4)[0]
plt.figure(figsize=(15, 9))
librosa.display.waveshow(data, sr=samplingrate, alpha=0.4)
# plt.plot(t, normalize(spectral_bandwidth_2), color='r')
# plt.plot(t, normalize(spectral_bandwidth_3), color='g')
# plt.plot(t, normalize(spectral_bandwidth_4), color='y')
# plt.legend(('p = 2', 'p = 3', 'p = 4'))

x, sr = librosa.load('/Users/kpangalu/Downloads/audio_features/recorded_vignesh.wav')
#Plot the signal:
plt.figure(figsize=(14, 5))
librosa.display.waveshow(data, sr=sr)
# Zooming in
n0 = 9000
n1 = 9100
plt.figure(figsize=(14, 5))
plt.plot(data[n0:n1])
plt.grid()

fs =2
mfccs = librosa.feature.mfcc(data, sr=fs)
print(mfccs.shape)
(20, 97)
#Displaying  the MFCCs:
plt.figure(figsize=(15, 7))
librosa.display.specshow(mfccs, sr=samplingrate, x_axis='time')

window_length = int(samplingrate * 0.05)
hop_length = int(samplingrate*0.01)
chromagram = librosa.feature.chroma_stft(data, sr=samplingrate, hop_length=hop_length)
plt.figure(figsize=(15, 5))
librosa.display.specshow(chromagram, x_axis='time', y_axis='chroma', hop_length=hop_length, cmap='coolwarm')

#mel-spectrum analysis
# trim silent edges
whale_song, _ = librosa.effects.trim(data)

n_fft = 2048
D = np.abs(librosa.stft(whale_song[:n_fft], n_fft=n_fft, hop_length=n_fft+1))
plt.plot(D);

n_mels = 128
mel = librosa.filters.mel(sr=samplingrate, n_fft=n_fft, n_mels=n_mels)

plt.figure(figsize=(15, 4));

plt.subplot(1, 3, 1);
librosa.display.specshow(mel, sr=samplingrate, hop_length=hop_length, x_axis='linear');
plt.ylabel('Mel filter');
plt.colorbar();
plt.title('1. Our filter bank for converting from Hz to mels.');


plt.subplot(1, 3, 2);
mel_10 = librosa.filters.mel(sr=samplingrate, n_fft=n_fft, n_mels=10)
librosa.display.specshow(mel_10, sr=samplingrate, hop_length=hop_length, x_axis='linear');
plt.ylabel('Mel filter');
plt.colorbar();
plt.title('2. Easier to see what is happening with only 10 mels.');

plt.subplot(1, 3, 3);
idxs_to_plot = [0, 9, 49, 99, 127]
for i in idxs_to_plot:
    plt.plot(mel[i]);
plt.legend(labels=['{}'.format(i+1) for i in idxs_to_plot]);
plt.title('3. Plotting some triangular filters separately.');

plt.tight_layout();  