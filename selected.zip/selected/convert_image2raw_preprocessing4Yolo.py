#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 10 11:49:59 2023

@author: eshahria
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 11:23:25 2022

@author: kpangalu
"""

import os
import cv2
import numpy as np
import fnmatch
import matplotlib.pyplot as plt

#This one change all (dirs and subdirs) pngs to raw file and creating a .txt file
root = '/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/org_images/'
saveroot = '/Users/kpangalu/Downloads/scale_transparencies_battlemodes/snpe_val/reshape_raw1/'
folders= [''] 

input_size=640
cnt = 0
for i in folders:
    imgroot = os.path.join(root , i)
    filelist= os.listdir(imgroot)
    for fileind in  range(3):
        filename =filelist[fileind]
        fname = os.path.join(imgroot,filename)
        print(fname)        
        im = cv2.imread(os.path.join(imgroot,filename))
        
        # padding -------------------------------------------------------------                
        impad= np.zeros((input_size,input_size,3))
        imH , imW, chmod = im.shape
        scaleratio = input_size/max(imH,imW)
        dimNew = (int(imW*scaleratio),  int(imH*scaleratio))
        #this one for image is sitting in the middle and padding remaining top and bottom.
        #padsize = (int((input_size - dimNew [0] )/2), int((input_size - dimNew [1])/2))
        #this one is image is place on the top left corner and bottom is padding
        #padsize = (int((input_size - dimNew [0])), int((input_size - dimNew [1])))
        padsize = (int(0),int(0))
        
        imResized= cv2.resize(im, dimNew)       
        impad[padsize[1]:padsize[1]+ dimNew[1] ,padsize[0]:padsize[0]+ dimNew[0],:  ] = imResized
        
        cv2.imwrite(os.path.join(saveroot, i, filename), impad)
        # ---------------------------------------------------------------------
        # image normalization -------------------------------------------------
        
        impad=impad.astype(np.float32)
        impad=impad/255.0
        impad=impad.astype(np.float32)
        # save image to raw file ----------------------------------------------
        
        savefname= os.path.join(saveroot,i, filename[:-3] +  'raw')
        impad.tofile(savefname)
        savelist = saveroot + i+'_real_raw.txt'
        with open(savelist, "a") as l:
                l.write(str(savefname)+"\n")
        cnt = cnt + 1
        
        
