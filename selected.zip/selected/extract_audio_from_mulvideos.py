# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 14:52:50 2023

@author: kpangalu
"""

import os, glob
from moviepy.editor import *

def vidmp4toaudmp3(inpvideofle):
    vidfile = VideoFileClip(inpvideofle)
    splt1 = inpvideofle.split("/")[-1]
    outt = inpvideofle[0:-4]
    outaudiofile = outt+'_audio.mp3'
    audfile = vidfile.audio
    audfile.write_audiofile(outaudiofile)
    audfile.close()
    vidfile.close()
    
#Extracting audio from video file
path = "/Users/kpangalu/Downloads/Trainingcamp_videos/"
all_videos = glob.glob(os.path.join(path,"*.mp4"))
print(all_videos)

for echvideo in all_videos:
    print(echvideo)
    vidmp4toaudmp3(echvideo)
    