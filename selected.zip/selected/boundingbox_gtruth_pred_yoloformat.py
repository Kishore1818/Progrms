# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 15:03:55 2022

@author: kpangalu
"""
#change YOLO to VOC (Visual Object class) format

import cv2
import os
import glob
import numpy as np
import matplotlib.pyplot as plt

def drawPred(frame,classId, conf, left, top, right, bottom):
    # Draw a bounding box.
    frame_tmp = frame
    cv2.rectangle(frame_tmp, (left, top), (right, bottom), (255, 178, 50), 3)
    
    label = '%.2f' % conf
        
    # Get the label for the class name and its confidence
    #if classes:
    #   assert(classId < len(classes))
    label = '%s:%s' % (classId, label) #comment out if you have a class_lists.txt with class names in it 
    #label = '%s:%s' % (obj_list[classId], label) #uncomment if you have a class_lists.txt with class names in it 

    #Display the label at the top of the bounding box
    labelSize, baseLine = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    top = max(top, labelSize[1])
    frame_tmp = cv2.rectangle(frame_tmp, (left, int(top - round(1.5*labelSize[1]))), (left + int(round(1.5*labelSize[0])), top + baseLine), (255, 255, 255), cv2.FILLED)
    frame_tmp = cv2.putText(frame_tmp, label, (left, top), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 1)
    return frame_tmp

def convert_yolo_coordinates_to_voc(x_c_n, y_c_n, width_n, height_n, img_width, img_height):
    ## remove normalization given the size of the image
    x_c = float(x_c_n) * img_width
    y_c = float(y_c_n) * img_height
    width = float(width_n) * img_width
    height = float(height_n) * img_height
    ## compute half width and half height
    half_width = width / 2
    half_height = height / 2
    ## compute left, top, right, bottom
    ## in the official VOC challenge the top-left pixel in the image has coordinates (1;1)
    left = int(x_c - half_width) + 1
    top = int(y_c - half_height) + 1
    right = int(x_c + half_width) + 1
    bottom = int(y_c + half_height) + 1
    return left, top, right, bottom

def drawGT(frame, classId, left, top, right, bottom):
    # Draw a bounding box.
    frame_gt = frame
    cv2.rectangle(frame_gt, (left, top), (right, bottom), (255, 178, 50), 3)
    
    #label = '%.2f' % conf
        
    # Get the label for the class name and its confidence
    #if classes:
    #   assert(classId < len(classes))
    label = '%s' % (classId) #comment out if you have a class_lists.txt with class names in it 
    #label = '%s' % (obj_list[classId]) #uncomment if you have a class_lists.txt with class names in it

    #Display the label at the top of the bounding box
    labelSize, baseLine = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    top = max(top, labelSize[1])
    frame_gt = cv2.rectangle(frame_gt, (left, int(top - round(1.5*labelSize[1]))), (left + int(round(1.5*labelSize[0])), top + baseLine), (255, 255, 255), cv2.FILLED)
    frame_gt = cv2.putText(frame_gt, label, (left, top), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 1)
    return frame_gt
#*****Loading the image
imgs_dir = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/bounding_box/images/"

imgs = glob.glob(imgs_dir + "*.jpg") 
imgnames = []
sl = slice(0, -4)
for rimg in imgs:
    print("Image files: ", rimg[sl])
    fname = rimg[sl]
    splt1 = fname.split('\\')[1]
    imgnames.append(splt1)
    

grndtruth_dir = '/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/bounding_box/ground-truth-txt/'
predict_dir = '/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/bounding_box/detection-results-txt/'

count = 0
for name in imgnames:
    gtruth_file = grndtruth_dir + name + ".txt"
    ptruth_file = predict_dir + name + '.txt'
    print(gtruth_file, '\n', ptruth_file)
    
    #reading/loading the image
    img_path = imgs_dir + name + '.jpg'
    orig_img = cv2.imread(img_path)
    orig_img1 = orig_img.copy()
    imght, imgwid = orig_img.shape[:2]
    
    #reading the ground truth information (txt format file not YOLO format file)
    with open(gtruth_file, "r") as file_gtruth:
        gtruth_info = file_gtruth.readlines()
    #trimming the leading and tailing white spaces
    gtruth_info = [x.strip() for x in gtruth_info]
    
    for gline in gtruth_info:
        obj_id, x_c_n, y_c_n, width_n, height_n = gline.split()
        left, top, right, bottom = convert_yolo_coordinates_to_voc(x_c_n, y_c_n, width_n, height_n, imgwid, imght)
        #Comment out if co-ordinates not in YOLO format
        #obj_id, left, top, right, bottom = line.split() #Uncomment if absolute co-ordinates/VOC
        
        #plotting with bounding box
        image_gtruth = drawGT(orig_img, obj_id, left, top, right, bottom)
        gt_res_path ='/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/bounding_box/grnd_truth_bbox.jpg'
        cv2.imwrite(gt_res_path, image_gtruth)
        
    #reading the prediction information
    with open(ptruth_file, "r") as file_pred:
        pred_info = file_pred.readlines()
    pred_info = [x.strip() for x in pred_info]
    
    for pline in pred_info:
        obj_id, conf, x_c_n, y_c_n, width_n, height_n = pline.split() #Comment out if co-ordinates not in YOLO format
        #obj_id, conf, left, top, right, bottom = line.split() #Uncomment if absolute co-ordinates/VOC
        conf = float(conf)
        left, top, right, bottom = convert_yolo_coordinates_to_voc(x_c_n, y_c_n, width_n, height_n, imgwid, imght) #Comment out if co-ordinates not in YOLO format
        
        #plotting: bounding box and confidence level
        image_det = drawPred(orig_img1, obj_id, conf, left, top, right, bottom)
        pred_res_path ='/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/bounding_box/pred_bbox.jpg'
        cv2.imwrite(pred_res_path, image_det)