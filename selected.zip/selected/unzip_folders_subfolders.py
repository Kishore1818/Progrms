# -*- coding: utf-8 -*-
"""
Created on Wed Feb  1 16:28:28 2023

@author: kpangalu
"""

#at a time unzip all folders and subfolders 
import zipfile, fnmatch, os

parent_root = "/Users/kpangalu/Downloads/test_unzip/"
zipformat = "*.zip"

for givenpath, alldirs, files in os.walk(parent_root):
    for fname in fnmatch.filter(files, zipformat):
        print(os.path.join(givenpath, fname))
        zipfile.ZipFile(os.path.join(givenpath, fname)).extractall(os.path.join(givenpath, os.path.splitext(fname)[0]))
        
        
    