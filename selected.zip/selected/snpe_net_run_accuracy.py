#!/usr/bin/env python
# coding: utf-8

# In[1]:


#This program calc the number false predictions, true prediction, and accuracy using "snpe-net-run" output file


# In[2]:


import cv2
import re
import os, glob
import numpy as np
import matplotlib.pyplot as plt
import rawpy
import imageio
from termcolor import colored

import warnings
warnings.filterwarnings("ignore")


# In[3]:


#Reading the raw text file
# with open("/local/mnt3/workspace3/Kishore/DLC_conversion/snpe-1.61.0.3358/test_8030raw19May.txt", 'r') as fp:
with open("/Users/kpangalu/Downloads/combined_mnist/real_raw.txt", 'r') as fp:
    rwtxt = fp.readlines()
print('no. of lines in a file: ',len(rwtxt))

orig_num = np.zeros(len(rwtxt),dtype=np.int)
for ii in range(len(rwtxt)):
    #print(rwtxt[ii])
    txtsplt = rwtxt[ii].split("/")[-1]
    txtsplt1 = txtsplt.split("_")[0]
    orig_num[ii] = np.int(txtsplt1)


# In[4]:


from os.path import exists
path = "/Users/kpangalu/Downloads/combined_mnist/output/"
# all_files = os.listdir(path)
all_files = glob.glob(os.path.join(path, 'Res*'))
print('Total images: ',len(all_files))

#True and false prediction from rawoutput file
kk = 0
for j, val in enumerate(all_files):
    cdir = "Result_" + str(j)
    dir_exists = exists(path+cdir)

    try:
        dir_exists = exists(cdir)
        fname = path + cdir + '/'+'0.raw'
        out_array = np.fromfile(fname, dtype = np.float32)
        #indx = np.where(out_array == max(out_array))[0][0]
        indx = np.where(out_array == max(out_array))[0]
        if(len(indx) > 1):
            indx = indx[1]
        #print(j,len(out_array),indx)
        print("Original: {}".format(orig_num[j]), '  ',"Predicted: {}".format(np.int(indx)))
        if(np.int(indx) != orig_num[j]):
            kk = kk+1
            #print(colored("Original: {}".format(orig_num[j]),'green'))
            print(colored("Original: {}".format(orig_num[j]),'red'), '    ',colored("Predicted: {}".format(np.int(indx)),'red'))
            #print("Original: {}".format(orig_num[j]), '  ',"Predicted: {}".format(np.int(indx)))
    except OSError:
        continue

#Accuracy estimation
acc = 100 - kk/len(all_files)
totimgs = len(all_files)
print(colored("Total Number of images: {}".format(totimgs),'green'))
print(colored("Total Number of True predictions: {}".format(totimgs-kk),'green'))
print(colored("Total Number of False predictions: {}".format(kk),'red'))
print(colored("Model Accuracy: {:.2f}".format(acc) + '%', 'blue'))        


# In[5]:


# #reading output directories and files (snpe-net-run output)
# # path = "/local/mnt3/workspace3/Kishore/DLC_conversion/snpe-1.61.0.3358/output/"
# path = "/Users/kpangalu/Downloads/combined_mnist/output/"
# # all_files = os.listdir(path)
# all_files = glob.glob(os.path.join(path, 'Res*'))
# print('Total images: ',len(all_files))

# #True and false prediction from rawoutput file
# kk = 0
# for j, val in enumerate(all_files):
#     cdir = "Result_" + str(j)
#     print(cdir)
#     #fname = path + cdir + '/'+'StatefulPartitionedCall:0.raw'
#     fname = path + cdir + '/'+'0.raw'
#     #print(fname)
#     out_array = np.fromfile(fname, dtype = np.float32)
#     #print(res_array)
#     indx = np.where(out_array == max(out_array))[0]
#     #print(np.int(indx), orig_num[j])
#     print("Original: {}".format(orig_num[j]), '  ',"Predicted: {}".format(np.int(indx)))
#     if(np.int(indx) != orig_num[j]):
#         kk = kk+1
#         #print(colored("Original: {}".format(orig_num[j]),'green'))
#         print(colored("Original: {}".format(orig_num[j]),'red'), '    ',colored("Predicted: {}".format(np.int(indx)),'red'))
#         #print("Original: {}".format(orig_num[j]), '  ',"Predicted: {}".format(np.int(indx)))

# #Accuracy estimation
# acc = 100 - kk/len(all_files)
# totimgs = len(all_files)
# print(colored("Total Number of images: {}".format(totimgs),'green'))
# print(colored("Total Number of True predictions: {}".format(totimgs-kk),'green'))
# print(colored("Total Number of False predictions: {}".format(kk),'red'))
# print(colored("Model Accuracy: {:.2f}".format(acc) + '%', 'blue'))


# In[ ]:




