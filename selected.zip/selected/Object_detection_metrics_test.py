# -*- coding: utf-8 -*-
"""
Created on Wed Aug 17 15:49:59 2022

@author: kpangalu
"""

prgname = 'Object_detection_metrics_test.py'

import cv2
import os
import glob
import json 
import shutil
import operator
import argparse
import numpy as np
import argparse
import matplotlib.pyplot as plt

os.chdir('/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/')

MINOVERLAP = 0.5 # default value (defined in the PASCAL VOC2012 challenge)

parser = argparse.ArgumentParser()
parser.add_argument('-na', '--no-animation', help="no animation is shown.", action="store_true")
parser.add_argument('-np', '--no-plot', help="no plot is shown.", action="store_true")
parser.add_argument('-q', '--quiet', help="minimalistic console output.", action="store_true")
# argparse receiving list of classes to be ignored
parser.add_argument('-i', '--ignore', nargs='+', type=str, help="ignore a list of classes.")
# argparse receiving list of classes with specific IoU (e.g., python main.py --set-class-iou person 0.7)
parser.add_argument('--set-class-iou', nargs='+', type=str, help="set IoU for a specific class.")
args = parser.parse_args()

def pause():
    programPause = input("Press the <ENTER> key to continue...") #PY3.0

# make sure that the cwd() is the location of the python script (so that every path makes sense)
# os.chdir(os.path.dirname(os.path.abspath(__file__)))

# if there are no classes to ignore then replace None by empty list
if args.ignore is None:
    args.ignore = []

specific_iou_flagged = False
if args.set_class_iou is not None:
    specific_iou_flagged = True
    
IMG_PATH = os.path.join(os.getcwd(), 'input', 'images-optional')
# print(IMG_PATH)
# if os.path.exists(IMG_PATH): 
#     for dirpath, dirnames, files in os.walk(IMG_PATH):
#         print(files)
#         if not files:
#             # no image files found
#             args.no_animation = True
# else:
#     args.no_animation = True
GT_PATH = os.path.join(os.getcwd(), 'input', 'ground-truth')
DR_PATH = os.path.join(os.getcwd(), 'input', 'detection-results')

imgs = glob.glob(IMG_PATH + "\*.jpg") 
# print(imgs)
imgnames = []
sl = slice(0, -4)
for rimg in imgs:
    # print("Image files: ", rimg[sl])
    fname = rimg[sl]
    splt1 = rimg.split('\\')[-1]
    imgnames.append(splt1)
 
print(imgnames)
if len(imgnames) > 0:
    args.no_animation=True

#***import opne cv2    
show_animation = False
if not args.no_animation:
    import cv2
    show_animation = True

#****import Matplotlib
draw_plot = False
if not args.no_plot:
    import matplotlib.pyplot as plt
    draw_plot = True
    
####Create a temporary and results directories
TEMP_FILES_PATH = ".temp_files"
if not os.path.exists(TEMP_FILES_PATH):
    os.makedirs(TEMP_FILES_PATH)

results_files_path = "results_test"
if os.path.exists(results_files_path):
    shutil.rmtree(results_files_path)
if not os.path.exists(results_files_path):
    os.makedirs(results_files_path) 
    
# os.makedirs(results_files_path)
if draw_plot:
    os.makedirs(os.path.join(results_files_path, "classes"))
if show_animation:
    os.makedirs(os.path.join(results_files_path, "images", "detections_one_by_one"))
    
