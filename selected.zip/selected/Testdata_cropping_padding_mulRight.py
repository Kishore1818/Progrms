#!/usr/bin/env python
# coding: utf-8

# #### Cropping and padding the Right box of the Gun active or not active (gun firing time bullet numbers are smaller)
# 
# ###### This is for multiple Images Rightside one

# In[1]:


import cv2
import re
import os, glob
import numpy as np
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")


# ##### Image location 

# In[2]:


# path = '/home/jayanthikishore/Downloads/Qual_images/images/'

# path = "C:/Users/kpangalu/Downloads/activeempty_gun"
path = "/Users/kpangalu/Downloads/activeempty__gun__copy/activeempty__gunn/"
# path = "/Users/kpangalu/Downloads/test/model_test"
all_files = glob.glob(os.path.join(path, "gamehaptics_*.png"))
# all_filess = sorted(all_files)
print(len(all_files))


# ##### Creating Image indexes and picking range of index

# In[11]:


imgnum = np.zeros(len(all_files))
for i, fname in enumerate(all_files):
    #print ("{0}: {1}".format(i,fname))
    
    strsplt = re.split('[./_]',fname)
    numm = strsplt[-2]
    #print(strsplt[-2])
    indx = i
    imgnum[indx] = numm
    
# print(imgnum[100:110])
stindx = np.int(np.where(imgnum == 3573)[0])
enindx = np.int(np.where(imgnum == 3580)[0])
display("srating index and image num: {}, {}".format(stindx, imgnum[stindx]))
display("ending index and image num: {}, {}".format(enindx, imgnum[enindx]))
# print(stindx,imgnum[stindx], enindx, imgnum[enindx])   

all_files1 = all_files[stindx:np.int(enindx)]
# print(all_files1)


# ##### Cropping the bullet number and padding unwanted characters from the cropping Image

# In[10]:


ii = 0
for fimg in all_files1:
    img = cv2.imread(fimg)
    display(img.shape)
    #picking the image number
    txtsplt = fimg.split(".")
    txtsplt1 = txtsplt[0]
    txtsplt2 = txtsplt1.split("_")
    #print(txtsplt2[-1])
    
    plt.figure(figsize = (15,15))
    plt.imshow(img)
    plt.title("Orogonal Image")
    plt.show()
    
    #Image cropping at particular region (GUn region)
    imgcrop1 = img[443:492, 580:697]
    plt.imshow(imgcrop1)
    display(imgcrop1.shape)
    plt.show()
    
    #pick the bullte number from Right image box
    YTL = 467
    XTL = 586
    YBR = 481
    XBR = 610    #for 21x14=607
    
    imgcrop2 = img[YTL:YBR, XTL:XBR]
    display(imgcrop2.shape)
    plt.imshow(imgcrop2)
    plt.show()
    
    #padding applying some threshold value
    imgg = imgcrop2[:,:,0]
    display(imgg.shape)
    
    h = imgg.shape[0]
    w = imgg.shape[1]
    
    img_thres = np.zeros((h,w))
    n_pix = 0
    #counting how many color pixels LT91 
    lt91s = np.zeros(24)
    for x in range(12,w):
        pixs = imgg[:,x]
        lt91 = sum(map(lambda pixs: pixs<91, pixs))
        lt91s[x] = lt91
    spnt = np.where(lt91s == 14)[0][0]
    print("selected point: ", spnt)
    
    #padding from selected point 
    for x in range(0,w):
        pixels = imgg[:,x]
        #print(x,pixels)
        #cntt = sum(map(lambda pixels: pixels <110, pixels))
        #if((x >=spnt) and (cntt >= len(pixels)*0.6)) or ((x>17) and (cntt >= len(pixels)*0.1)):
        if(x >= spnt):
            pixels = pixels*0
        else:
            pixels = pixels            
        img_thres[:,x] = pixels
        
    plt.imshow(img_thres)
    plt.show()
     
    #save cropped Image
    num = input('Enter number: ')
    if(np.int(num) <10):
        numm = '00' + num
    elif (np.int(num) > 9 and np.int(num) < 99):
        numm = '0' + num
        
    if(np.int(num) >= 0):
        ii += 1
        path1 = "/Users/kpangalu/Downloads/test/digits_24x14"
        lfname = numm + "_gunactiveempty_" + txtsplt2[-1] + ".png"
        cv2.imwrite(os.path.join(path1,lfname), img_thres)
    
    


# In[ ]:




