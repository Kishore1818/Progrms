# -*- coding: utf-8 -*-
"""
Created on Fri Jan  6 14:58:06 2023

@author: kpangalu
"""

import os
import json

#mpath = "C:/Users/kpangalu/Downloads/Audiodata_collection/Dec2022_audio/analysis/"
mpath = "C:/Users/kpangalu/Downloads/Audiodata_collection/Dec2022_audio/matfle2json/explosion-test-run1/"
cnt = 0
for epath, subdirs, nfiles in os.walk(mpath):
    for file in nfiles:
        if file.endswith(".json"):
            selfile = os.path.join(epath,file)
            sfile = json.load(open(selfile,'r'))
            num_explsions= sfile["Num_ROIs"] 
            cnt += num_explsions
            
print('Total number of explosions: ',cnt)