#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Oct 13 00:28:52 2021

@author: eshahria
"""

import tensorflow as tf
import tensorflow_datasets as tfds
import keras
import matplotlib.pyplot as plt
import sys
import _pickle as cPickle
import gzip
import math
import numpy as np
import os
import cv2
import random

print(tf.__version__)

# Helper function to display digit images
def show_sample(images, labels, sample_count=25):
  # Create a square with can fit {sample_count} images
  grid_count = math.ceil(math.ceil(math.sqrt(sample_count)))
  grid_count = min(grid_count, len(images), len(labels))
  
  plt.figure(figsize=(2*grid_count, 2*grid_count))
  for i in range(sample_count):
    plt.subplot(grid_count, grid_count, i+1)
    plt.xticks([])
    plt.yticks([])
    plt.grid(False)
    plt.imshow(images[i], cmap=plt.cm.gray)
    plt.xlabel(labels[i])
  plt.show()
  
  
# I) load dataset 
# f = gzip.open('./data/mnist.pkl.gz', 'rb')
# if sys.version_info < (3,):
#     data = cPickle.load(f)
# else:
#     data = cPickle.load(f, encoding='bytes')
# f.close()
# (x_train, y_train), (x_test,y_test) = data


# # ----------------------------------------------------------------------------------------------------------------------------------------
# load pubgTest
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/HapticDetection/OCRDetection/data/TestRes1200_WholeImage/'
pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/Test_Combined/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/Test_All/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/testdata_24x141_kishore/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/Test_Muhua_Cleaned/'


# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/HapticDetection/OCRDetection/data/LR1200TestByMuhua/'

# pubgTrainroot_2 = '/local/mnt2/qtlvas/users/eshahria/workspace/HapticDetection/OCRDetection/data/GenDataColorRes1200_Ext/'
pubgTrainroot='/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/SyntheticData/'
pubgTrainroot_realDB='/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/Train_RealData/'

Testfilelist= os.listdir(pubgTestroot)

x_test_pubg= np.zeros([len(Testfilelist),14,24,1])
y_test_pubg= np.zeros([len(Testfilelist),1])
for imgindex in range(len(Testfilelist)):     
    print(imgindex)
    
    
      # x_test_pubg[imgindex,:,:,0]= cv2.imread(pubgTestroot+Testfilelist[imgindex],0)[255:269,787:811]
      # x_test_pubg[imgindex,:,:,0]= cv2.imread(pubgTestroot+Testfilelist[imgindex],0)[:-1,0:24]
    imgcrop  = cv2.imread(pubgTestroot+Testfilelist[imgindex],0)
    # imgcropscaled = cv2.resize(imgcrop, (24,14))
    x_test_pubg[imgindex,:,:,0]=imgcrop
    label = Testfilelist[imgindex][0:3]
    spindex= label.find('_')
    if spindex>0:
         label=label[:spindex]
    y_test_pubg[imgindex,0]= int(label)
      # x_test_pubg[imgindex,:,:,0]= cv2.imread(pubgTestroot+Testfilelist[imgindex],0)
      # y_test_pubg[imgindex,0]= int(Testfilelist[imgindex][0:3])
x_test_pubg=x_test_pubg/255.00


# Training Data prepration -------------------------------------------------

filelist= os.listdir(pubgTrainroot)
np.random.shuffle((filelist))
x_train_pubg= np.zeros([len(filelist),14,24,1])
y_train_pubg= np.zeros([len(filelist),1])
for imgindex in range(len(filelist)):
     
     x_train_pubg[imgindex,:,:,0]= cv2.imread(pubgTrainroot+filelist[imgindex],0)
     label = filelist[imgindex][0:3]
     spindex= label.find('_')
     if spindex>0:
         label=label[:spindex]
     y_train_pubg[imgindex,0]= int(label)
x_train_pubg=x_train_pubg/255.00

# load Real Data --------------
filelist_realDB= os.listdir(pubgTrainroot_realDB)
x_train_pubg_realDB= np.zeros([len(filelist_realDB),14,24,1])
y_train_pubg_realDB= np.zeros([len(filelist_realDB),1])
for imgindex in range(len(filelist_realDB)):
     
     x_train_pubg_realDB[imgindex,:,:,0]= cv2.imread(pubgTrainroot_realDB+filelist_realDB[imgindex],0)
     label = filelist_realDB[imgindex][0:3]
     spindex= label.find('_')
     if spindex>0:
         label=label[:spindex]
     y_train_pubg_realDB[imgindex,0]= int(label)
x_train_pubg_realDB=x_train_pubg_realDB/255.00





# -----------------------------------------------------------------------------
# x_train = x_train/255.0
# x_test = x_test/255.0

# show_sample(x_train, y_train)

num_orientation= 302
# Mnist model -------------------
# Define the model architecture
model = keras.Sequential([
    # keras.layers.Flatten(input_shape=(14, 20,1)),
    # keras.layers.Dense(128, activation=tf.nn.relu),

# Optional: You can replace the dense layer above with the convolution layers below to get higher accuracy.
    # keras.layers.Reshape(target_shape=( 14, 20, 1)),    
    keras.layers.Conv2D(filters=16, kernel_size=(3, 3), activation=tf.nn.relu, input_shape = (14, 24, 1), name='input'),
    keras.layers.Conv2D(filters=16, kernel_size=(3, 3), activation=tf.nn.relu),
    keras.layers.MaxPooling2D(pool_size=(2, 2)),
    keras.layers.Dropout(0.3),
    keras.layers.Flatten(input_shape=(14, 24)),
    keras.layers.Dense(64, activation=tf.nn.relu),
    keras.layers.Dropout(0.5),

    keras.layers.Dense(num_orientation, name='output')
])

model.compile(optimizer='adam',
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

# model training  -------------------------------------------------------------

# Train the digit classification model
#model.fit(x_train, y_train, epochs=5)
testaccset=[]
testaccset_top=[]
maxacc=0.9
for k in range(30000):
    
    
    num_random_sample = len(x_train_pubg_realDB)
    random_index= np.random.choice(np.arange(len(x_train_pubg)),num_random_sample )

    train_random_y = y_train_pubg[random_index,:]    
    train_random_x = x_train_pubg[random_index,:,:,:]    
    
    
    
    temp_data_x= np.concatenate((train_random_x, x_train_pubg_realDB) , axis=0 )
    temp_data_y= np.concatenate((train_random_y, y_train_pubg_realDB) , axis=0 )
    
    index_shuffle= np.arange(temp_data_y.shape[0])
    np.random.shuffle(index_shuffle[:])
    
    temp_data_x=temp_data_x[index_shuffle[:],:,:,:]
    temp_data_y=temp_data_y[index_shuffle[:],:]
    
    
    model.fit(temp_data_x, temp_data_y, batch_size=1024, epochs=10)
    test_loss, test_acc = model.evaluate(x_test_pubg, y_test_pubg)
    testaccset.append(test_acc)
       
    # if test_acc >0.99:        
    #     break
    if test_acc > maxacc:        
        model.save('./checkpoints/chkpnt_March22th_iter_{}_acc_{}'.format(str(k),str(test_acc)[0:6]))
        maxacc = test_acc

# model evaluation predict pubg images ---------

# model = keras.models.load_model('./checkpoints/CODSpeed_bullet_combinedchkpnt_March22th_iter_2997_acc_0.9934')
# model.summary()

test_loss, test_acc = model.evaluate(x_test_pubg, y_test_pubg)
predictions_pubg = model.predict(x_test_pubg)
show_sample(x_test_pubg,['Predicted: %d' % (np.argmax(result)) for result in predictions_pubg])

numtestimages= x_test_pubg.shape[0]
for index in range(numtestimages):
    if abs(np.argmax(predictions_pubg[index,:]) - y_test_pubg[index] ) > 0.1:
        print(index, np.argmax(predictions_pubg[index,:]), y_test_pubg[index])




test_loss, test_acc = model.evaluate(x_train_pubg, y_train_pubg)
predictions_pubg = model.predict(x_train_pubg)
show_sample(x_train_pubg,['Predicted: %d' % (np.argmax(result)) for result in predictions_pubg])


# -------------------------------------------------------------------------------------------------------------------------------------------------
########################################################################################################################################
# Save  TFLite model ----------------------------------------------------------




# model = keras.models.load_model('./CODSpeed_bullet_combinedchkpnt_March2nd')
# model.summary()
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

# Save the TF Lite model as file
f = open('CODSpeed_bullet_combinedchkpnt_March22.tflite', "wb")
f.write(tflite_model)
f.close()











# # Apply Quantization ---------------------------------------------------------

# import tensorflow_model_optimization as tfmot

# quantize_model = tfmot.quantization.keras.quantize_model
# # q_aware stands for for quantization aware.
# q_aware_model = quantize_model(model)

# q_aware_model.summary()
# # `quantize_model` requires a recompile.
# q_aware_model.compile(optimizer='adam',
#               loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
#               metrics=['accuracy'])

# q_aware_model.summary()


# q_aware_model.fit(x_train_pubg, y_train_pubg,
#                   batch_size=2048, epochs=500, validation_split=0.1)




# _, baseline_model_accuracy = model.evaluate( x_test_pubg, y_test_pubg)

# _, q_aware_model_accuracy = q_aware_model.evaluate(x_test_pubg, y_test_pubg, verbose=0)

# print('Baseline test accuracy:', baseline_model_accuracy)
# print('Quant test accuracy:', q_aware_model_accuracy)


# q_aware_model.save('./ChkPoint300_Res1200_Light_Nov29_Quantized')
# q_aware_model.summary()

# # convert to Tensorflow lites --------------------------------------

# converter = tf.lite.TFLiteConverter.from_keras_model(q_aware_model)
# converter.optimizations = [tf.lite.Optimize.DEFAULT]

# quantized_tflite_model = converter.convert()

# # Save the TF Lite model as file
# f = open('mnist_multidigit_Res1200_Light_Nov29_Quantized.tflite', "wb")
# f.write(quantized_tflite_model)
# f.close()








########################################################################################################################################







