

# Read mp4 files and convert them to images -----------------------------------
import numpy as np
import os
import cv2
# --------------
import matplotlib.pyplot as plt

# -----------------------------------------------------------------------------
def DigitCleaning(imgROI, template, threshold=0.5):

    mathingmethod= 'cv2.TM_CCOEFF_NORMED'   # template matching method
    result = cv2.matchTemplate(imgROI,template,eval(mathingmethod) )                              
    maxVal= np.max(result)                               
    # print('maxVal', maxVal)
    if maxVal > threshold:
        maxIndex = np.argmax(result)  
        imgROI[:,maxIndex:]= 35 ; 
        
    return imgROI, maxVal
# 
template_slash = cv2.imread('/local/mnt2/qtlvas/users/eshahria/workspace/COD/BattleModeDetection/TrainData_1170wx540h/templates/slash_digit_cleaning.png',0)

# load Mask Regions -----------------------------------------------------------
# Mask_left = cv2.imread('E:/workspace/COD/ActivegunDetection/Mask/left_mask.png',0)
# Mask_left_Crop = Mask_left[438:489 , 460:581]
Mask_left_Crop = cv2.imread('/local/mnt2/qtlvas/users/eshahria/workspace/COD/ActiveGunDetection/Updated_March24/Mask/left_mask_crop.png',0)
Mask_left_Crop_Binary = (Mask_left_Crop/255)>0.5


# Mask_right = cv2.imread('E:/workspace/COD/ActivegunDetection/Mask/right_mask.png',0)
# Mask_right_Crop = Mask_right[439:493 , 581:696]
Mask_right_Crop= cv2.imread('/local/mnt2/qtlvas/users/eshahria/workspace/COD/ActiveGunDetection/Updated_March24/Mask/right_mask_crop.png',0)
Mask_right_Crop_Binary = (Mask_right_Crop/255)>0.5

# Blue Diff  Evaluation  ------------------------------------------------------
root = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/BattleModeDetection/DataSet/images/540x1170/'
saveDigitroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/BattleModeDetection/TrainData_1170wx540h/TrainEvalSet/Digit_COD_corporate_challengeV2/'
folderset = os.listdir(root)

distLeft=[] 
distRight=[]

Active4left=[]
Active4right=[]
inactiveGuns=[]

ActiveThreshold = 25 
ActiveRegionDistThr = 10
numberset=[]

maxValSet=[]
folderset=['COD_cooperate_challange_1']
for folder in folderset:
    filelist= os.listdir(os.path.join(root,folder))
          
    for file in filelist     :        
        img_BGR= np.float32(cv2.imread(os.path.join(root, folder, file))  )
        # img_BGR = np.float32(cv2.imread(fname))  # loead image in BGR channel order
        img_yellow = (img_BGR[:,:,1]+ img_BGR[:,:,2] - 2*img_BGR[:,:,0] )/2 #  yellow =   (((red + green) - 2xblue)/2)
        img_yellow[img_yellow<0]=0
    
        h,w,cmod= img_BGR.shape

    # 
        img_yellow_left_ROI = img_yellow[446:497 , 467:588]      # Cropping ROI for left
        plt.imshow(img_yellow_left_ROI*Mask_left_Crop_Binary)
        left_number = np.mean(img_yellow_left_ROI[Mask_left_Crop_Binary])
    
        img_yellow_right_ROI = img_yellow[447:501 , 588:703]  # Cropping ROI for right
        plt.imshow(img_yellow_right_ROI*Mask_right_Crop_Binary)
        right_number = np.mean(img_yellow_right_ROI[Mask_right_Crop_Binary])
        
        
        selcrop=[]
        sellbl=''
        if left_number > ActiveThreshold  and (left_number - right_number) > ActiveRegionDistThr : 
            # left gun is active 
            # print('Left Gun is Active ' )
            Active4left.append(left_number)
            distLeft.append(left_number)
            crop_left  = img_BGR[476:490 ,476:500,: ]
            crop_left = np.uint8(cv2.cvtColor(crop_left,cv2.COLOR_BGR2GRAY))
            
            selcrop,maxval= DigitCleaning(crop_left, template_slash)
            maxValSet.append(maxval)
            
            sellbl='crop_left_'
            
        elif right_number > ActiveThreshold  and (right_number - left_number)> ActiveRegionDistThr : 
            # left gun is active 
            print('Right Gun is Active ' )
            Active4right.append(right_number)
            distRight.append(right_number)
            crop_right = img_BGR[477:491 ,588:612,: ]
            crop_right = np.uint8(cv2.cvtColor(crop_right,cv2.COLOR_BGR2GRAY))
            selcrop, maxval= DigitCleaning(crop_right, template_slash)
            maxValSet.append(maxval)
            
            # selcrop=crop_right
            sellbl='crop_right_'
        else :
            # crop_center = img_BGR[479:493 ,479:503,: ]
            # print(fname)
            print(' single Gun' )
            inactiveGuns.append([left_number,right_number])
            crop_center = img_BGR[478:494 ,477:503,: ]
            crop_center = cv2.cvtColor(crop_center,cv2.COLOR_BGR2GRAY)
            crop_center_resized= np.uint8(cv2.resize(crop_center, (24,14)))
            
            selcrop,maxval= DigitCleaning(crop_center_resized, template_slash)
            maxValSet.append(maxval)
            sellbl='crop_center_'
# save crop regions -----------------------------------------------------------
        fname4save = saveDigitroot+ sellbl+file
        cv2.imwrite(fname4save, np.uint8(selcrop))
        
        


maxValSet>0.5


    