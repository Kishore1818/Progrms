# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 16:01:15 2022

@author: kpangalu
"""
#***Reading prediction bounding box text file and plotting bounding box in two different ways
import cv2
import numpy as np
import torch
import torchvision
from torchvision.io import read_image
from torchvision.utils import draw_bounding_boxes
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import warnings
warnings.filterwarnings("ignore")

fimg = "/Users/kpangalu/Downloads/validation/785.jpg"
img = cv2.imread(fimg, cv2.COLOR_BGR2RGB)
print(img.shape)

hgt = img.shape[0]
wid = img.shape[1]

plt.figure(figsize = (25,10))
plt.imshow(img)
plt.show()

#*****************************************Reading the bounding box string text file
fledir = "/Users/kpangalu/Downloads/validation/785_bboxinfo.txt"
with open(fledir, 'r') as fle:
    data1 = fle.read().rstrip()
print(type(data1))
# print(data1)
data = data1[1:-1]
# print(data)

#***convert string to flt array
fltdata = [float(item) for item in data.split()]
# print(fltdata)
print(type(fltdata))

#*****fltdata = 400 to (4,100)
#*****4 = [x0,y0,x1,y1] and 100 sets
fdata = np.zeros((4,100))*np.nan
for i in range(100):
    fdata[:, i] = fltdata[i*4:(i*4)+4]
    ran1 = i*4
    ran2 = ran1+3
    #print(ran1,ran2)
    #print(fdata[:,i])
    
#***convert bbox coord to proportional to image coordinates
x1, y1, x2, y2 = fdata[:,0]
print(x1,y1,x2,y2)
xmin = np.int(x1 * wid)
ymin = np.int(y1 * hgt)
xmax = np.int(x2 * wid)
ymax = np.int(y2 * hgt)
bbox = [xmin, ymin, xmax, ymax]

bbox = [333, 117, 562,445]
bbox1 = [231, 333, 445, 102]
# bbox1 = [231, 333, 562,445]
#rectangle=(lowerleft(x,y), width, height)
# def create_corner_rect(bb, color='red'):
#     bb = np.array(bb, dtype=np.float32)
#     return plt.Rectangle((bb[1], bb[0]), bb[3]-bb[1], bb[2]-bb[0], color=color,fill=False, lw=3)

def create_corner_rect(bb, color):
    bb = np.array(bb, dtype=np.float32)
    return plt.Rectangle((bb[0], bb[1]), bb[2]-bb[0], bb[3]-bb[1], color=color,fill=False, lw=3)

def show_corner_bb(im, bb):
    plt.imshow(im)
    plt.gca().add_patch(create_corner_rect(bb))
    
print(bbox)
plt.imshow(img)
plt.gca().add_patch(create_corner_rect(bbox, color='red'))
plt.gca().add_patch(create_corner_rect(bbox1, color='green'))
plt.show()

#*********************2nd method
# #****only one image one bounding box
# # read input image
img = read_image('/Users/kpangalu/Downloads/validation/785.jpg')

# bounding box in (xmin, ymin, xmax, ymax) format
# top-left point=(xmin, ymin), bottom-right point = (xmax, ymax)
# bbox = [117, 231, 562, 333]
label = ['person']
bbox = torch.tensor(bbox, dtype=torch.int)
print(bbox)
print(bbox.size())
bbox = bbox.unsqueeze(0)
print(bbox.size())

# draw bounding box on the input image
img=draw_bounding_boxes(img, bbox, width=3, labels=label,colors=(255,255,0))

# transform it to PIL image and display
img = torchvision.transforms.ToPILImage()(img)
img.show()
