#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on March 8 2023

@author: sathaval
"""

###

import cv2 as cv
import numpy as np
import os
import matplotlib.pyplot as plt
from PIL import Image


template = cv.imread('./bluehint_templates/template2_knockdown.jpg')
rgb_template = cv.cvtColor(template,cv.COLOR_BGR2RGB)
for im in os.listdir('./test_all_hints_full_sort/knockdown/'):
    blue = 0
    if im[-3:] == 'jpg':
        img = cv.imread(os.path.join('./test_all_hints_full_sort/knockdown/', im))
        rgb_img = cv.cvtColor(img,cv.COLOR_BGR2RGB)
        img_crop = rgb_img[270:290, 50:200]
        rows,cols,_ = img_crop.shape
        for i in range(rows):
            for j in range(cols):
                pixel = img_crop[i,j]
                if pixel[0] >= 137 and pixel[0] <= 164 and pixel[1] >= 209 and pixel[1] <= 250 and pixel[2] >= 230 and pixel[2] <= 255:
                    blue += 1
        if blue > 20:
            print("blue")
            model_cnn = torch.load('./best_acc_hintcnn.pt')
            model_cnn.eval()
            img_cnn = rgb_img[270:290, 50:100]
            img_cnn = np.float32(img_cnn)
            img_cnn= img_cnn/ 255
            img_cnn = cv.cvtColor(img_cnn,cv.COLOR_RGB2GRAY)
            x_test_pubg_single = np.zeros([1,1,20,50])
            x_test_pubg_single[0,0,:,:]=img_cnn
            x_test_pubg_single = torch.from_numpy(x_test_pubg_single)
            pred = model_cnn(x_test_pubg_single.float())
            pred = torch.argmax(pred, dim=1)
            if pred == 1:
                print("hint")
                img_crop = rgb_img[265:292, 0:600]
                res = cv.matchTemplate(img_crop,rgb_template,5)
                min_val, max_val, min_loc, max_loc = cv.minMaxLoc(res)
                if max_val > 0.75:
                    print("knockdown")
                else:
                    print("kill detected")