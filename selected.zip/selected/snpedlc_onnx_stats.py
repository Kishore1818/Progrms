# -*- coding: utf-8 -*-
"""
Created on Fri Feb  3 13:14:08 2023

@author: kpangalu
"""

import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

import math
from sklearn.metrics import mean_squared_error, mean_absolute_error

def get_stats(dataarray):
    #calc mean of the data
    datamean = dataarray.mean()
    prearray = datamean * np.ones(len(dataarray))
    #calc. the Root Mean Squared Error (RMSE)
    rmse = np.sqrt(mean_squared_error(dataarray, prearray))
    #calc. mean absolute error
    mse = mean_absolute_error(dataarray,prearray)
    
    print(f"RMSE: {rmse}")
    print(f"MSE: {mse}")
    
#*********************************************************************************************
#snpe net run dlc output csv file (dataframe) reading
snpedlc_df = pd.read_csv("/Users/kpangalu/Downloads/snpedlc_onnx/m2.csv",header=None)
snpedlc_df.head()

#dataframe to numpy array
snpedata = snpedlc_df.to_numpy()
#print(snpedata)

#numpy array to data frame
# snpe_df = pd.DataFrame(snpedata)
# snpe-df.head()

snpedata_stats = snpedlc_df.describe(include = 'all')
print(snpedata_stats)

#statistics using numpy array
snpedata_stats1 = stats.describe(snpedata)
print(snpedata_stats1)

snpedata_stats2 = get_stats(snpedata)
print(snpedata_stats2)

#************************************************************************************
#reading the ONNX binary file
onnxfle = "/Users/kpangalu/Downloads/snpedlc_onnx/modified.onnx"
onnxdata1 = np.fromfile(onnxfle, dtype = np.float32)
#moving extreme less and large values to NaN
onnxdata1[onnxdata1 >= 10.0] = np.nan
onnxdata1[onnxdata1 <= -10.0] = np.nan

#eliminating nan values
onnxdata = onnxdata1[~np.isnan(onnxdata1)]

#ONNXdata array file to dataframe
onnx_df = pd.DataFrame(onnxdata)

ncnt = np.count_nonzero(np.isnan(onnxdata1))
ncnt1 = np.count_nonzero(np.isnan(onnxdata))
print(f"Number of ONNX data points including NaN: {ncnt}")
print(f"Number of ONNX data points without NaN and extremes: {len(onnxdata)}")

print(onnx_df.head())

onnx_stat = onnx_df.describe()
print(onnx_stat)

onnx_stats1 = stats.describe(onnxdata)
print(onnx_stats1)

onnx_stats2 = get_stats(onnxdata)