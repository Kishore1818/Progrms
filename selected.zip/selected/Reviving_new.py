# -*- coding: utf-8 -*-
"""
Created on Fri Jul  8 14:39:47 2022

@author: Kishore
"""

import numpy as np
import os
import cv2
import matplotlib.pyplot as plt

root = '/Users/kpangalu/Downloads/battle_icons/'

# fileset_p = os.listdir(root +'positive/')
# fileset_n1= os.listdir(root+ 'negative1/')
# fileset_n2=os.listdir(root+ 'negative2/')
# fileset_n2=os.listdir(root+ 'negative3/')

fileset_p = os.listdir(root +'COD_corporate_challenge_1170wx540h/')  #  1000
fileset_n1= os.listdir(root+ 'COD_battle_royale_1170wx540h/') # 1000
fileset_n2=os.listdir(root+ 'COD_training_camp_1170wx540h/') # 1000
fileset_n3=os.listdir(root+ 'COD_ranking_battle_1170wx540h/') # 1000


fileset= [fileset_p,fileset_n1,fileset_n2,fileset_n3]
folderset=['COD_corporate_challenge_1170wx540h', 'COD_battle_royale_1170wx540h', 'COD_training_camp_1170wx540h', 'COD_ranking_battle_1170wx540h']

template = cv2.imread( '/Users/kpangalu/Downloads/battle_icons/selected/template.png',0)
    
# -----------------------------------------------------------------------------    
mathingmethod= 'cv2.TM_CCOEFF_NORMED'   # template matching method
maxvecset=[[],[]]

jj = 0
channel_dist = []
injury_flag =0 
result_max=[] 
result_mean=[] 
for findex in range(len(fileset )):
    filelist = fileset[findex]
    
    for fname in filelist:
        
#    fname = 'gamehaptics_6170.png'

        filename = root + folderset[findex]+'/'+fname
        img_test= cv2.imread(filename,0)
    
        # GET roi -------------------------------------------------------------
        img_test_roi = img_test[34:53, 85:105]
        # jj += 1
        # if(jj < 1200):
        #     plt.figure(figsize = (20,20))
        #     plt.imshow(img_test_roi)
        #     plt.show()
            
        Threshold = 0.92  
        
        # ger TM result ------------
        result = cv2.matchTemplate(img_test_roi,template,eval(mathingmethod))
       
        # if np.max(result ) > Threshold:
        #    print('positive')
        # else:
        #    print('negative')
       
        
        result_max.append(np.max(result))
        result_mean.append(np.mean(result))
# -----------------------------------------------------------------------------        

print(result_max) 
# #Plotting
xval = list(range(0,len(result_max)))
titles = ['max_value','mean']
data = [result_max, result_mean]
count = 2

for i in range(count):
    plt.subplot(2,1, i+1)
    plt.title(titles[i])   
    #plt.imshow(data[i])
    plt.plot(xval,data[i])
plt.show()

print(result_mean)

#single plot
fig = plt.figure(figsize = (20,10))
ax = plt.axes()
xval = list(range(0,len(result_max)))
ax.plot(xval, result_max);

