# -*- coding: utf-8 -*-
"""
Created on Wed Jan 11 13:52:04 2023

@author: kpangalu
"""

import os
from moviepy.editor import *

path = "/Users/kpangalu/Downloads/Trainingcamp_videos/"
video_file = "Trainingcamp2.mp4"

def vidmp4toaudmp3(inpvideofle):
    vidfile = VideoFileClip(inpvideofle)
    splt1 = inpvideofle.split("/")[-1]
    outt = splt1[0:-4]
    outaudiofile = path + outt+'_audio.mp3'
    audfile = vidfile.audio
    audfile.write_audiofile(outaudiofile)
    audfile.close()
    vidfile.close()
    
inputvideofile = path + video_file

vidmp4toaudmp3(inputvideofile)