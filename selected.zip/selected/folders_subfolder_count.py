# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 17:27:29 2023

@author: kpangalu
"""
###counting the folders and files in the specified path
import os, getpass
from os.path import join, getsize

dir_name = "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/CCB_singlegun_combinations_4lbls/"


files = folders = 0

for _, dirnames, filenames in os.walk(dir_name):
  # ^ this idiom means "we won't be using this value"
    files += len(filenames)
    folders += len(dirnames)

print("{:,} files, {:,} folders".format(files, folders))
