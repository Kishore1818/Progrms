# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 12:11:57 2022

@author: kpangalu
"""

import numpy as np
import sklearn
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

import numpy

def pre_rec_elbl(y_true, pred_scores, thresholds):
    precisions = []
    recalls = []
    for threshold in thresholds:
        y_pred = y_pred = ["positive" if score >= threshold else "negative" for score in pred_scores]

        precision = sklearn.metrics.precision_score(y_true=y_true, y_pred=y_pred, pos_label="positive")
        recall = sklearn.metrics.recall_score(y_true=y_true, y_pred=y_pred, pos_label="positive")
        
        precisions.append(precision)
        recalls.append(recall)

    return precisions, recalls

y_true = ["positive", "negative", "negative", "positive", "positive", "positive", "negative", "positive", "negative", "positive"]
pred_scores = [0.7, 0.3, 0.5, 0.6, 0.55, 0.9, 0.4, 0.2, 0.4, 0.3]

threshold = 0.5
y_pred = ["positive" if score >= threshold else "negative" for score in pred_scores]
print(y_pred)

#***confusion matrix, precision, and recall
r = np.flip(sklearn.metrics.confusion_matrix(y_true,y_pred))
print(r)

#****Precision calc (Precision = TRUEpositive/ (TRUEpositive + FALSEpositive))
precision = sklearn.metrics.precision_score(y_true=y_true, y_pred=y_pred, pos_label="positive")
print(precision)

#***Recall calc (Recall = TRUEpositive / (TRUEpositive + FALSEnegative))
recall = sklearn.metrics.recall_score(y_true=y_true, y_pred=y_pred, pos_label="positive")
print(recall)

#***f1 score calc. (f1 = 2* (precision*recall)/(precision+recall))
f1 = 2* ((precision*recall)/ (precision + recall))
print(f1)

thresholds = np.arange(start=0.2, stop=0.7, step=0.05)
precisions, recalls = pre_rec_elbl(y_true=y_true, pred_scores=pred_scores, thresholds = thresholds)
precisions.append(1)
recalls.append(0)
print(precisions)

precisions = np.array(precisions)
recalls = np.array(recalls)
print(precisions)

Mean_Avg_precision = np.sum((recalls[:-1]-recalls[1:]) * precisions[:-1])
print(Mean_Avg_precision)
