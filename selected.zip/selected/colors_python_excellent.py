#!/usr/bin/env python
# coding: utf-8

# ##### Python colors usage

# In[1]:


import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(0, 2*np.pi)
y = np.sin(x)

plot_colors = ['hotpink','darkviolet','mediumblue']
A = 1.
for c in plot_colors:
    plt.plot(x,A*y, c=c)
    A *= 0.6


# In[2]:


import matplotlib.colors as mcolors

mcolors.BASE_COLORS #these colors can be called with a single character

mcolors.TABLEAU_COLORS #the default color cycle colors

mcolors.CSS4_COLORS #named colors also recognized in css

mcolors.XKCD_COLORS #named colors from the xkcd survey


# In[3]:


A = 1.
for color in mcolors.TABLEAU_COLORS:
    plt.plot(x, A * y, c=color, label=color)
    A *= 0.8
plt.legend()


# In[4]:


plt.plot(x, y, c= mcolors.XKCD_COLORS['xkcd:very dark purple'])


# In[5]:


#All colors map
from matplotlib.gridspec import GridSpec
import matplotlib.colors as mcolors


colors = mcolors._colors_full_map #dictionary of all colors

#sort them by hsv
by_hsv = sorted((tuple(mcolors.rgb_to_hsv(mcolors.to_rgba(color)[:3])), name)
                for name, color in colors.items())
sorted_names = [name for hsv, name in by_hsv]

def plot_all_colors():
    fig = plt.figure(figsize=(17,35),dpi=200)
    grid = GridSpec(195,6,hspace=1,wspace=2)
    counter = 0
    while counter < 1163:
        column = (counter//195)%6
        row = counter%195
        ax = fig.add_subplot(grid[row,column])
        ax.axis('off')
        ax.axhline(0,linewidth=15,c=sorted_names[counter])
        color_str = sorted_names[counter]
        #recall that xkcd colors must be prefaced with "xkdc:". To save space, I'll take that out
        #and replace with an asterisk so we can still identify them
        if 'xkcd' in color_str:
            color_str = color_str[5:]+'*'
        ax.text(-0.03,0.5,color_str,ha='right',va='center')
        counter+=1
    else:
        ax = fig.add_subplot(grid[-4,-1])
        ax.axis('off')
        ax.text(0,0,'* = xkcd')
#         fig.savefig('matplotlib named colors.png', bbox_inches='tight') #uncomment to save figure
            
plot_all_colors()


# In[6]:


plt.plot(x, y, c = (0.84, 0.16, 0))
plt.plot(x, -y, c = '#A50062')


# In[7]:


x = np.linspace(0,0.5*np.pi)
ys = np.ones((10,50)) * np.sin(x)
ys = np.array([ys[i,] * np.linspace(1,0.1,10)[i] for i in range(10)])

fig, ax = plt.subplots()
ax.set_prop_cycle(color=['red','orange','yellow','green','blue','purple'])
ax.plot(x, ys.T)


# In[8]:


import matplotlib.style as style
style.use('tableau-colorblind10')

plt.plot(x, ys.T)


# In[10]:


import matplotlib as mpl
def plot_all_colormaps():
    '''
    This function will only plot the 82 built in colormaps.
    '''
    fig = plt.figure(facecolor='white',figsize=(25,15),dpi=300)
    grid = GridSpec(17, 5,hspace=.5,wspace=0.9)
    strings = [s for s in plt.colormaps() if "_r" not in s]
    counter = 0
    while counter < 81:
        column = (counter//17)%5
        row = counter%17
        ax = fig.add_subplot(grid[row,column])
        ax.axis('off')
        cmap_str = strings[counter]
        color_map = plt.get_cmap(cmap_str)
        mpl.colorbar.ColorbarBase(ax, cmap=color_map, orientation = 'horizontal')
        ax.text(-0.02,0.5,cmap_str,ha='right',va='center',fontsize=15)
        counter += 1
    else:
#         fig.savefig('matplotlib colormaps.png',bbox_inches='tight') #uncomment this if you want to save the figure
        return
          
def plot_all_colormaps2():
    '''
    This function will plot the 82 colormaps and their reverse.
    '''
    fig = plt.figure(facecolor='white',figsize=(25,15),dpi=300)
    grid = GridSpec(41, 4,hspace=.5,wspace=0.9)
    counter = 0
    while counter < 164:
        column = (counter//41)%4
        row = counter%41
        ax = fig.add_subplot(grid[row,column])
        ax.axis('off')
        cmap_str = plt.colormaps()[counter]
        color_map = plt.get_cmap(cmap_str)
        mpl.colorbar.ColorbarBase(ax, cmap=color_map, orientation = 'horizontal')
        ax.text(-0.02,0.5,cmap_str,ha='right',va='center',fontsize=15)
        counter += 1
    else:
#         fig.savefig('matplotlib colormaps.png',bbox_inches='tight') #uncomment this if you want to save the figure
        return

plot_all_colormaps()


# In[11]:


latitudes, longitudes = np.meshgrid(np.linspace(-0.5*np.pi, 0.5*np.pi), np.linspace(-np.pi, np.pi))

fig = plt.figure()
ax = fig.add_subplot(projection='hammer')
ax.set_xticks([])
mesh = ax.pcolormesh(longitudes, latitudes, longitudes * 180/np.pi, cmap='twilight')
plt.colorbar(mesh, label='Longitude ($\degree$)',fraction=0.05)


# In[13]:


from matplotlib.colors import LinearSegmentedColormap
pride = LinearSegmentedColormap.from_list("pride",["#FF0018","#FFA52C","#FFFF41","#008018","#0000F9","#86007D"])

bi_pride = LinearSegmentedColormap.from_list("", ["#D60270", "#9B4F96", "#0038A8"])

trans_pride = LinearSegmentedColormap.from_list("",["#55CDFC","#FFFFFF","#F7A8B8"])

lesbian_pride = LinearSegmentedColormap.from_list("",["#D62900","#FF9B55","#FFFFFF","#D461A6","#A50062"])

nonbinary_pride = LinearSegmentedColormap.from_list("",["#FFF430","#FFFFFF","#9C59D1","#000000"])

pan_pride = LinearSegmentedColormap.from_list("",["#FF1B8D","#FFDA00","#1BB3FF"])

ace_pride = LinearSegmentedColormap.from_list("",["#000000","#A4A4A4","#FFFFFF","#810081"])

genderfluid_pride = LinearSegmentedColormap.from_list("",["#FF76A4","#FFFFFF","#C011D7","#000000","#2F3CBE"])

pride_cmaps = [pride, bi_pride, lesbian_pride, trans_pride, nonbinary_pride, pan_pride, ace_pride, genderfluid_pride]

def plot_pride_maps():
    fig = plt.figure(figsize=(15,5))
    grid = GridSpec(4,2)
    counter = 0
    while counter < 8:
        column = (counter//4)%2
        row = counter%4
        ax = fig.add_subplot(grid[row, column])
        ax.axis('off')
        mpl.colorbar.ColorbarBase(ax, cmap = pride_cmaps[counter], orientation='horizontal')
        counter += 1
    else:
        return

plot_pride_maps()


# In[ ]:




