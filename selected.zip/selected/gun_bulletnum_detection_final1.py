#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tensorflow as tf
import tensorflow_datasets as tfds
import keras
import matplotlib.pyplot as plt
import sys
import _pickle as cPickle
import gzip
import math
import numpy as np
import os
import cv2

import warnings
warnings.filterwarnings('ignore')


# In[2]:


display(tf.__version__)

# Helper function to display digit images
def show_sample(images, labels, sample_count=25):
  # Create a square with can fit {sample_count} images
    grid_count = math.ceil(math.ceil(math.sqrt(sample_count)))
    grid_count = min(grid_count, len(images), len(labels))
  
    plt.figure(figsize=(2*grid_count, 2*grid_count))
    for i in range(sample_count):
        plt.subplot(grid_count, grid_count, i+1)
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)
        plt.imshow(np.squeeze(images[i]), cmap=plt.cm.gray)
        if(labels[i] == 'Predicted: 300'):
            labels[i] = "Predicted: inf"
        if(labels[i] == 'Predicted: 301'):
            labels[i] = 'Predicted: No Gun'
        #display(labels[i])
        plt.xlabel(labels[i])
    plt.show()
  


# In[3]:


# # ----------------------------------------------------------------------------------------------------------------------------------------
# load pubgTest
pubgTestroot = '/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/activeempty_gun/gun_data_preparation/testdata_24x141/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/SpeedDetection/data/TestDigit/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/HapticDetection/OCRDetection/data/LR1200TestByMuhua/'

pubgTrainroot = '/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/activeempty_gun/gun_data_preparation/Syntheticdata/'
# pubgTrainroot='/local/mnt2/qtlvas/users/eshahria/workspace/COD/SpeedDetection/data/SyntheticData/'

Testfilelist= os.listdir(pubgTestroot)

x_test_pubg= np.zeros([len(Testfilelist),14,24,1])
y_test_pubg= np.zeros([len(Testfilelist),1])

display(x_test_pubg.shape,y_test_pubg.shape)

for imgindex in range(len(Testfilelist)):
    imgcrop  = cv2.imread(pubgTestroot+Testfilelist[imgindex],0)
    #display(imgindex,imgcrop.shape)
    
    # imgcropscaled = cv2.resize(imgcrop, (24,14))
    x_test_pubg[imgindex,:,:,0]=imgcrop
    label = Testfilelist[imgindex][0:3]
    #display(label)
    spindex= label.find('_')
    if spindex>0:
         label=label[:spindex]
    y_test_pubg[imgindex,0]= int(label)
    #display(y_test_pubg)
    # x_test_pubg[imgindex,:,:,0]= cv2.imread(pubgTestroot+Testfilelist[imgindex],0)
    # y_test_pubg[imgindex,0]= int(Testfilelist[imgindex][0:3])
    
x_test_pubg=x_test_pubg/255.00
# y_test_pubg = y_test_pubg
filelist= os.listdir(pubgTrainroot)
np.random.shuffle((filelist))
x_train_pubg= np.zeros([len(filelist),14,24,1])
y_train_pubg= np.zeros([len(filelist),1])
for imgindex in range(len(filelist)):
    x_train_pubg[imgindex,:,:,0]= cv2.imread(pubgTrainroot+filelist[imgindex],0)
    label = filelist[imgindex][0:3]
    spindex= label.find('_')
    if spindex>0:
        label=label[:spindex]
    y_train_pubg[imgindex,0]= int(label)
x_train_pubg=x_train_pubg/255.00


# In[4]:


print("X_train original shape", x_train_pubg.shape)
print("y_train original shape", y_train_pubg.shape)
print("X_test original shape", x_test_pubg.shape)
print("y_test original shape", y_test_pubg.shape)


# In[5]:


# -----------------------------------------------------------------------------
# x_train = x_train/255.0
# x_test = x_test/255.0

# show_sample(x_train, y_train)

num_orientation= 501
# Mnist model -------------------
# Define the model architecture
model = keras.Sequential([
    # keras.layers.Flatten(input_shape=(14, 20,1)),
    # keras.layers.Dense(128, activation=tf.nn.relu),

# Optional: You can replace the dense layer above with the convolution layers below to get higher accuracy.
    # keras.layers.Reshape(target_shape=( 14, 20, 1)),    
    keras.layers.Conv2D(filters=16, kernel_size=(3, 3), activation=tf.nn.relu, input_shape = (14, 24, 1), name='input'),
    keras.layers.Conv2D(filters=16, kernel_size=(3, 3), activation=tf.nn.relu),
    keras.layers.MaxPooling2D(pool_size=(2, 2)),
    keras.layers.Dropout(0.25),
    keras.layers.Flatten(input_shape=(14, 24)),
    keras.layers.Dense(64, activation=tf.nn.relu),
    keras.layers.Dropout(0.5),

    keras.layers.Dense(num_orientation, name='output')
])

model.compile(optimizer='adam',
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

model.summary()


# In[6]:


print(x_train_pubg.shape,y_train_pubg.shape)
# print(y_train_pubg)


# In[7]:


# model training  -------------------------------------------------------------

# Train the digit classification model
#model.fit(x_train, y_train, epochs=5)
testaccset=[]
stp = 0
slos = 0
all_acc = np.zeros(600)*np.nan
all_los = np.zeros(600)*np.nan
for k in range(20):
    training_history = model.fit(x_train_pubg, y_train_pubg, batch_size=1024, epochs=30)
    #training_history = model.fit(x_train_pubg, y_train_pubg, batch_size=1024, epochs=30,validation_split=0.2)
    test_loss, test_acc = model.evaluate(x_test_pubg, y_test_pubg)
    testaccset.append(test_acc)

    etp = stp + 30
    all_acc[stp:etp] = training_history.history['accuracy']
    
    elos = slos +30
    all_los[slos:elos] = training_history.history['loss']
    
    stp = etp
    slos = elos
    
model.save('./CODSpeedChkpnt_Feb18')


# In[8]:


# # model evaluation predict pubg images ---------

test_loss, test_acc = model.evaluate(x_test_pubg, y_test_pubg)
predictions_pubg = model.predict(x_test_pubg)
show_sample(x_test_pubg,['Predicted: %d' % (np.argmax(result)) for result in predictions_pubg])

# test_loss, test_acc = model.evaluate(x_train_pubg, y_train_pubg)
# predictions_pubg = model.predict(x_train_pubg)
# show_sample(x_train_pubg,['Predicted: %d' % (np.argmax(result)) for result in predictions_pubg])


# In[9]:


# Draw Model Accuracy
plt.figure(2,figsize=(6,4))
plt.plot(all_acc)
# plt.plot(range(epoch),training_history.history['val_accuracy'])
plt.xlabel('# Epochs')
plt.ylabel('Accuracy')
plt.title('Model Accuracy')
plt.grid(True)
plt.legend(['train','validation'],loc=4)
plt.style.use(['classic'])

# Draw Model Loss
plt.figure(1,figsize=(6,4))
plt.plot(all_los)
# plt.plot(range(epoch),training_history.history['loss'])
# plt.plot(range(epoch),training_history.history['val_loss'])
plt.xlabel('# Epochs')
plt.ylabel('Loss')
plt.title('Model Loss')
plt.grid(True)
plt.legend(['train','validation'])


# #### Review the prediction results

# In[10]:


predictions_pubg = model.predict(x_test_pubg)
print(len(predictions_pubg))
pred_label = [np.argmax(i) for i in predictions_pubg]
# print(pred_label,y_test_pubg)

# identify correctly and incorrectly classified clothing items

correctly_classified = []
incorrectly_classified = []
index = 0
for actual, predict in zip(y_test_pubg, pred_label):
    if actual == predict:
        correctly_classified.append(index)
    else:
        incorrectly_classified.append(index)
    index += 1

ccc = len(correctly_classified)
icc = len(incorrectly_classified)
print('Correctly classified bullet number  : {:5d} ({:=5.2f} %)'.format(ccc, ccc * 100 / (ccc + icc)))    
print('Incorrectly classified bullet number: {:5d} ({:=5.2f} %)'.format(icc, icc * 100 / (ccc + icc)))    


# In[11]:


# load model 
model = keras.models.load_model('./CODSpeedChkpnt_Feb18')
model.summary()

# model Evaluation ------------------------------------------------------------
# test_loss, test_acc = model.evaluate(x_test, y_test)

# print('Test accuracy:', test_acc)



# Predict the MNIST digits 
# predictions = model.predict(x_test)

# # Then plot the first 25 test images and their predicted labels.
# show_sample(x_test,  ['Predicted: %d' % np.argmax(result) for result in predictions])



# In[12]:


# Save  TFLite model ----------------------------------------------------------
model = keras.models.load_model('./CODSpeedChkpnt_Feb18')
model.summary()
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

# Save the TF Lite model as file
f = open('COD_speed_Feb18.tflite', "wb")
f.write(tflite_model)
f.close()


# In[ ]:




