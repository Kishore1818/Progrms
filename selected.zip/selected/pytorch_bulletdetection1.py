#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  1 00:02:06 2022

@author: eshahria
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
import torchvision
import os
import cv2
import matplotlib.pyplot as plt
from torchsummary import summary
from datetime import date
  
#******************day and month 
cur_date = date.today()
curMonthName = cur_date.strftime("%B")
chkpntdate = '_'+str(cur_date.day) + str(curMonthName)
# print(chkpntdate)

# I) load dataset =============================================================
# # ---------------------------------------------------------------------------

# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/Test_Muhua_folder15/'
# pubgTestroot = '/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/CleanData_June22/Test_All/'
pubgTestroot = '/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/Normalized_NoPreprocessing/Dataset/Test_All/'

#Load Synthetic data
pubgTrainroot='/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/Normalized_NoPreprocessing/Dataset/SyntheticData/'
# pubgTrainroot='/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/CleanData_June22/SyntheticData/'

#Load real dataset
pubgTrainroot_realDB='/local/mnt3/workspace3/Kishore/ML_project_dir/ML_project_env/Normalized_NoPreprocessing/Dataset/Train_realrename_18May/'
# pubgTrainroot_realDB='/local/mnt2/qtlvas/users/eshahria/workspace/COD/speed_bullet_combined/data/CleanData_June22/Train_realrename_18May/'

# load Test data---------------------------------------------------------------

Testfilelist= os.listdir(pubgTestroot)

x_test_pubg= np.zeros([len(Testfilelist),1,14,24])
y_test_pubg= np.zeros([len(Testfilelist),1])
for imgindex in range(len(Testfilelist)):     
    #print(imgindex)
    imgcrop  = cv2.imread(pubgTestroot+Testfilelist[imgindex],0)
    # imgcropscaled = cv2.resize(imgcrop, (24,14))
    imgcrop = np.float32(imgcrop)
    imgcrop= imgcrop/ np.max(imgcrop)
    x_test_pubg[imgindex,0,:,:]=imgcrop
    label = Testfilelist[imgindex][0:3]
    spindex= label.find('_')
    if spindex>0:
         label=label[:spindex]
    y_test_pubg[imgindex,0]= int(label)

x_test_pubg = torch.from_numpy(x_test_pubg) # get torch tensor from numpy array
y_test_pubg = torch.from_numpy(y_test_pubg)

# Load Synthetic and real trainig data ----------------------------------------
filelist= os.listdir(pubgTrainroot)
np.random.shuffle((filelist))
x_train_pubg= np.zeros([len(filelist),1,14,24])
y_train_pubg= np.zeros([len(filelist),1])
for imgindex in range(len(filelist)):
     
     imgcrop= cv2.imread(pubgTrainroot+filelist[imgindex],0)
     imgcrop = np.float32(imgcrop)
     imgcrop= imgcrop/ np.max(imgcrop)
     x_train_pubg[imgindex,0,:,:]= imgcrop
     label = filelist[imgindex][0:3]
     spindex= label.find('_')
     if spindex>0:
         label=label[:spindex]
     y_train_pubg[imgindex,0]= int(label)
# x_train_pubg=x_train_pubg/np.max(x_train_pubg)

# load Real Data --------------
filelist_realDB= os.listdir(pubgTrainroot_realDB)
x_train_pubg_realDB= np.zeros([len(filelist_realDB),1,14,24])
y_train_pubg_realDB= np.zeros([len(filelist_realDB),1])
for imgindex in range(len(filelist_realDB)):
     
     imgcrop= cv2.imread(pubgTrainroot_realDB+filelist_realDB[imgindex],0)
     imgcrop = np.float32(imgcrop)
     imgcrop= imgcrop/ np.max(imgcrop)
     x_train_pubg_realDB[imgindex,0,:,:]= imgcrop
     label = filelist_realDB[imgindex][0:3]
     spindex= label.find('_')
     if spindex>0:
         label=label[:spindex]
     y_train_pubg_realDB[imgindex,0]= int(label)
# x_train_pubg_realDB=x_train_pubg_realDB/np.max(x_train_pubg_realDB)

# =============================================================================
# Define MNIST MODEL ----------------------------------------------------------
class Net(nn.Module):
    #This defines the structure of NN
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv1.weight)
        self.conv2 = nn.Conv2d(16, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv2.weight)
        self.drop1 = nn.Dropout2d(0.3)
        self.drop2 = nn.Dropout(0.5)
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(800, 64)
        # nn.init.xavier_normal_(self.fc1.weight)
        self.fc2 = nn.Linear(64, 302)
        # nn.init.xavier_normal_(self.fc2.weight)

    def forward(self, x):
        #Convolutional Layer/pooling Layer/Dropout/Activation
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(F.relu(self.conv2(x)) , 2)
        x= self.drop1(x)
        x= self.flatten(x)
        #Fully Connected Layer/Activation
        x= self.fc1(x)
        x= self.drop2(x)
        x= self.fc2(x)
        #Softmax gets probablities
        # return F.log_softmax(x, dim=1)
        return x
        
#*****model summary
device = torch.device("cuda" if torch.cuda.is_available() else "cpu") # PyTorch v0.4.0
model = Net().to(device)
summary(model,(1,14,24))        
# -----------------------------------------------------------------------------
# define loss function and run training ---------------------------------------

# n_epochs = 3
batch_size_train = 8
# batch_size_test = 1000
learning_rate = 0.01
momentum = 0.5
# log_interval = 10

random_seed = 1


torch.backends.cudnn.enabled = False
torch.manual_seed(random_seed)

network = Net()
network = network.float() 
optimizer = optim.SGD(network.parameters(), lr=learning_rate, momentum=momentum)
# optimizer = optim.ADM(network.parameters(), lr=learning_rate) 
# optimizer =optim.Adam(network.parameters(),lr=learning_rate) 

criterion = nn.CrossEntropyLoss()
# Training --------------------------------------------------------------------

testaccset=[]
testaccset_top=[]
losses = []
maxacc=0.99
EPOCHS = 500
for epoch_index in range(EPOCHS):
    
    if epoch_index>0 and epoch_index% 500 ==0:
        learning_rate=learning_rate*.1
        print('learning_rate',learning_rate)
        optimizer = optim.SGD(network.parameters(), lr=learning_rate, momentum=momentum)

        
    num_random_sample = len(x_train_pubg_realDB)
    random_index= np.random.choice(np.arange(len(x_train_pubg)),num_random_sample )

    train_random_y = y_train_pubg[random_index,:]    
    train_random_x = x_train_pubg[random_index,:,:,:]    
    
    temp_data_x= np.concatenate((train_random_x, x_train_pubg_realDB) , axis=0 )
    temp_data_y= np.concatenate((train_random_y, y_train_pubg_realDB) , axis=0 )
    
    index_shuffle= np.arange(temp_data_y.shape[0])
    np.random.shuffle(index_shuffle[:])
    
    temp_data_x=temp_data_x[index_shuffle[:],:,:,:]
    temp_data_y=temp_data_y[index_shuffle[:],:]

    temp_data_x_torch = torch.from_numpy(temp_data_x)
    temp_data_y_torch = torch.from_numpy(temp_data_y)

    numbatch = temp_data_x_torch.shape[0]//batch_size_train
    
    network.train()
    for batch_ind in range(numbatch):

        temp_data_x_torch_batch = temp_data_x_torch[batch_ind * batch_size_train : (batch_ind+1) * batch_size_train,:]
        temp_data_y_torch_batch = temp_data_y_torch[batch_ind * batch_size_train : (batch_ind+1) * batch_size_train]
    # reset optimizer grad --------------------------
        optimizer.zero_grad()
        output = network(temp_data_x_torch_batch.float())
        # loss = F.nll_loss(output, temp_data_y_torch_batch[:,0].long())
        loss= criterion(output ,temp_data_y_torch_batch[:,0].long() ) 
        loss.backward()
        optimizer.step()
        
        # accuracy = (torch.argmax(output, dim=1) == temp_data_y_torch_batch[:,0]).sum().item() / batch_size_train
        # print( f'Train_batch { batch_ind} , Train accuracy {accuracy} ')
    with torch.no_grad():
        network.eval()
        output_test = network(x_test_pubg.float())
        accuracy4Test =(torch.argmax(output_test, dim=1) == y_test_pubg[:,0]).to(torch.float).mean()
        
        #***repeat
        output_test = network(x_test_pubg.float())
        accuracy4Test =(torch.argmax(output_test, dim=1) == y_test_pubg[:,0]).to(torch.float).mean()
        
        #loss=tensor(2.9459, grad_fn=<NllLossBackward0>) to 2.9459
        loss1 = loss.item()
        losses.append(loss.item())
        #print( f'epoch_index { epoch_index} , accuracy4Test {accuracy4Test} ')
        print('\r Train Epoch: {}/{}\t Loss: {:.6f}\t Test Accuracy: {:.4f}%'.format(epoch_index+1,EPOCHS, loss, accuracy4Test*100 ))

        #****saving the model and optimizer .pth files 
        if accuracy4Test >=maxacc:
          torch.save(network.state_dict(), f'./chkpoint1/acc_{accuracy4Test:.4f}_iter_{epoch_index}_model'+chkpntdate+'.pth')
          torch.save(optimizer.state_dict(), f'./chkpoint1/acc_{accuracy4Test:.4f}_iter_{epoch_index}_optimizer'+chkpntdate+'.pth')
          maxacc=accuracy4Test.item()

#***Plotting
plt.plot(np.array(losses),'r')


