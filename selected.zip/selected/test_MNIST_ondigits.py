# -*- coding: utf-8 -*-
"""
Created on Tue Dec 27 14:52:05 2022

@author: kpangalu
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import torch.optim as optim
import numpy as np
import torchvision
import os
import cv2
import imageio
from termcolor import colored


# Define MNIST MODEL ----------------------------------------------------------
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv1.weight)
        self.conv2 = nn.Conv2d(16, 16, kernel_size=3)
        # nn.init.xavier_normal_(self.conv2.weight)
        self.drop1 = nn.Dropout2d(0.3)
        self.drop2 = nn.Dropout(0.5)
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(800, 64)
        # nn.init.xavier_normal_(self.fc1.weight)
        self.fc2 = nn.Linear(64, 302)
        # nn.init.xavier_normal_(self.fc2.weight)

    def forward(self, x):
        x = torch.div(x,255)
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(F.relu(self.conv2(x)) , 2)
        x= self.drop1(x)
        x= self.flatten(x)
        x= self.fc1(x)
        x= self.drop2(x)
        x= self.fc2(x)
        # return F.log_softmax(x, dim=1)
        #return torch.argmax(x)
        return x
    
network = Net() # model initialization 
# load saved model 
# network.load_state_dict(torch.load('/local/mnt/workspace/Kishore/data/Speed_bullet_Pytorch/chkpoint_NoScaling/Aug23_accTrainSynthetic_0.9982_accTrain_0.9989_accTest_0.9981_iter_782_model_argmax.pt'))
network.load_state_dict(torch.load("/Users/kpangalu/Downloads/testing/COD_DATA/resize2halfoforiginal/chkpoints/Dec22_accTrainSynthetic_0.9982_accTrain_0.9982_accTest_0.9943_iter_480_model_withargmax.pt"))
network.eval() # use for evaluation to remove dropout layers , ................

TestRoot = "/Users/kpangalu/Downloads/testing/COD_DATA/resize2halfoforiginal/test_datalabel_14dec/"
SaveRoot = '/Users/kpangalu/Downloads/testing/COD_DATA/resize2halfoforiginal/test_datalabel_14dec_predictions/'
Testfilelist= os.listdir(TestRoot)

kk = 0
for imgindex in range(len(Testfilelist)):         
    target = Testfilelist[imgindex][0:3]
    imgcrop_org  = cv2.imread(TestRoot+Testfilelist[imgindex]) 
    
    imgcrop = np.float32(cv2.imread(TestRoot+Testfilelist[imgindex],0))
    #plt.figure(figsize=(3,3))
    #plt.imshow(imgcrop_org)
    #plt.show()
    # imgcrop= imgcrop/ np.max(imgcrop)
    imgcrop= imgcrop.reshape([1,1,14,24])
     
    # inference ------
    input_torch = torch.from_numpy(imgcrop)
    test_pred = network(input_torch)
    test_pred_class_label= torch.argmax(test_pred, dim=1).item()
    #test_pred_class_label =test_pred.item()
    # prefix_zero='000'
    # prefix = prefix_zero[0:3-len(str(test_pred_class_label))] + str(test_pred_class_label) +'_'
    # savename =SaveRoot+prefix+ Testfilelist[imgindex]
    # cv2.imwrite(savename, imgcrop_org)
    print( f'target :   { target} , prediction {test_pred_class_label} ')
    if(int(target) != int(test_pred_class_label)): 
        kk += 1
  
acc = ((len(Testfilelist)-kk)/len(Testfilelist))*100.
totimgs = len(Testfilelist)
print(colored("Total Number of images: {}".format(totimgs),'green'))
print(colored("Total Number of True predictions: {}".format(totimgs-kk),'green'))
print(colored("Total Number of False predictions: {}".format(kk),'red'))
print(colored("Model Accuracy: {:.2f}".format(acc) + '%', 'white'))      
        

