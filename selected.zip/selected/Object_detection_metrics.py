# -*- coding: utf-8 -*-
"""
Created on Mon Aug 15 10:57:43 2022

@author: kpangalu
"""
prgname = 'Object_detection_metrics.py'

import cv2
import os
import glob
import json 
import shutil
import operator
import argparse
import numpy as np
import argparse
import matplotlib.pyplot as plt

os.chdir('/Users/kpangalu/OneDrive - Qualcomm\Desktop/Progms/')
GT_PATH = os.path.join(os.getcwd(), 'input', 'ground-truth')
print(GT_PATH) 

MINOVERLAP = 0.5 # default value (defined in the PASCAL VOC2012 challenge)

parser = argparse.ArgumentParser()
parser.add_argument('-na', '--no-animation', help="no animation is shown.", action="store_true")
parser.add_argument('-np', '--no-plot', help="no plot is shown.", action="store_true")
parser.add_argument('-q', '--quiet', help="minimalistic console output.", action="store_true")
# argparse receiving list of classes to be ignored
parser.add_argument('-i', '--ignore', nargs='+', type=str, help="ignore a list of classes.")
# argparse receiving list of classes with specific IoU (e.g., python main.py --set-class-iou person 0.7)
parser.add_argument('--set-class-iou', nargs='+', type=str, help="set IoU for a specific class.")
args = parser.parse_args()

def pause():
    programPause = input("Press the <ENTER> key to continue...") #PY3.0

# if there are no classes to ignore then replace None by empty list
if args.ignore is None:
    args.ignore = []

specific_iou_flagged = False
if args.set_class_iou is not None:
    specific_iou_flagged = True
    
# # os.makedirs(results_files_path)
# results_files_path = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/results_test/"
# # if draw_plot:
# #     os.makedirs(os.path.join(results_files_path, "classes"))
# # if show_animation:
# os.makedirs(os.path.join(results_files_path, "images", "detections_one_by_one"))
        
main_dir = "/Users/kpangalu/OneDrive - Qualcomm\Desktop/Progms/Object_metrics/"
#*****Loading images
# IMG_PATH = os.path.join(os.getcwd(), 'input', 'images_optional')
# print(IMG_PATH)
# imgs_dir = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/input/images-optional/"
IMG_PATH = os.path.join(os.getcwd(), 'input', 'images-optional')
print(IMG_PATH)

imgs = glob.glob(IMG_PATH + "*.jpg") 
print(imgs)
imgnames = []
sl = slice(0, -4)
for rimg in imgs:
    print("Image files: ", rimg[sl])
    fname = rimg[sl]
    splt1 = rimg.split('\\')[1]
    imgnames.append(splt1)
 
print(imgnames)

####Create a temporary and results directories
TEMP_FILES_PATH = main_dir + ".temp_files"
if not os.path.exists(TEMP_FILES_PATH):
    os.makedirs(TEMP_FILES_PATH)

results_files_path = "results_test"
if os.path.exists(results_files_path):
    shutil.rmtree(results_files_path)
if not os.path.exists(results_files_path):
    os.makedirs(results_files_path)
# if draw_plot:
#     os.makedirs(os.path.join(results_files_path, "classes"))
# if show_animation:
#     os.makedirs(os.path.join(results_files_path, "images", "detections_one_by_one"))

print(results_files_path)

"""
 Convert the lines of a file to a list
"""
def file_lines_to_list(path):
    # open txt file lines to a list
    with open(path) as f:
        content = f.readlines()
    # remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]
    return content

#***Loading groundtruth txt files
GT_PATH = '/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/input/ground-truth/'
ground_truth_files_list = glob.glob(GT_PATH + '*.txt')

DR_PATH = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/input/detection-results/"
dr_files_list = glob.glob(DR_PATH + "*.txt")
dr_files_list.sort()

gt_counter_per_class = {}
counter_images_per_class = {}

for txt_file in ground_truth_files_list:
    file_id = txt_file.split(".txt", 1)[0]
    file_id = os.path.basename(os.path.normpath(file_id))
    #picking the corresponding detection-results file
    temp_path = os.path.join(DR_PATH, (file_id + ".txt"))
    
    lines_list = file_lines_to_list(txt_file)
    #create ground-truth dictionary
    bounding_boxes = []
    is_difficult = False
    already_seen_classes = []
    for line in lines_list:
        try:
            if "difficult" in line:
                class_name, left, top, right, bottom, _difficult = line.split()
                is_difficult = True
                
            else:
                class_name, left, top, right, bottom = line.split()
                
        except ValueError:
            error_msg = "Error: File " + txt_file + " in the wrong format.\n"
            error_msg += " Expected: <class_name> <left> <top> <right> <bottom> ['difficult']\n"
            error_msg += " Received: " + line
            error_msg += "\n\nIf you have a <class_name> with spaces between words you should remove them\n"
            error_msg += "by running the script \"remove_space.py\" or \"rename_class.py\" in the \"extra/\" folder." 
            error(error_msg)
        # check if class is in the ignore list, if yes skip
        # if class_name in ignore:
        #     continue
        bbox = left + " " + top + " " + right + " " + bottom
        if is_difficult:
            bounding_boxes.append({"class_name":class_name, "bbox":bbox, "used":False, "difficult":True})
            is_difficult = False
        else:
            bounding_boxes.append({"class_name":class_name, "bbox":bbox, "used":False})
            #count that object
            if class_name in gt_counter_per_class:
                gt_counter_per_class[class_name] += 1
            else:
                #if class didn't exist yet
                gt_counter_per_class[class_name] = 1
                
            if class_name not in already_seen_classes:
                if class_name in counter_images_per_class:
                    counter_images_per_class[class_name] += 1
                else:
                    #if class didn't exist yet
                    counter_images_per_class[class_name] = 1
                already_seen_classes.append(class_name)
                
            
    #dump bounding_boxes into a ".json" file
    with open(TEMP_FILES_PATH + "/" + file_id + "_ground_truth.json", "w") as outfile:
        json.dump(bounding_boxes, outfile)
        
gt_classes = list(gt_counter_per_class.keys())
#let's sort the classes alphabetically
gt_classes = sorted(gt_classes)
n_classes = len(gt_classes)
# print(gt_classes)
# print(gt_counter_per_class)      
    
#count total detection-results

det_counter_per_calss = {}
for txt_file in dr_files_list:
    #get lines to list
    lines_list = file_lines_to_list(txt_file)
    for line in lines_list:
        class_name = line.split()[0]
        #check if calss is in the ignore list, if yes skip
        # if class_name in ignore:
        #     continue
        #count that object
        if class_name in det_counter_per_calss:
            det_counter_per_calss[class_name] += 1
        else:
            #if class didn't exist yet
            det_counter_per_calss[class_name] = 1
print(det_counter_per_calss)
dr_classes = list(det_counter_per_calss.keys())
 
##Write number of ground-truth objects per class to results.txt
results_files_path = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/results_test/"
# if show_animation:
#     os.makedirs(os.path.join(results_files_path, "images", "detections_one_by_one"))
    
with open(results_files_path + "/results_test.txt", 'a') as results_file:
    results_file.write("\n# Number of ground-truth objects per class\n")
    for class_name in sorted(gt_counter_per_class):
        results_file.write(class_name + ": " + str(gt_counter_per_class[class_name]) + "\n")   


"""
 Check format of the flag --set-class-iou (if used)
    e.g. check if class exists
"""
if specific_iou_flagged:
    n_args = len(args.set_class_iou)
    error_msg = \
        '\n --set-class-iou [class_1] [IoU_1] [class_2] [IoU_2] [...]'
    if n_args % 2 != 0:
        print('Error, missing arguments. Flag usage:' + error_msg)
    # [class_1] [IoU_1] [class_2] [IoU_2]
    # specific_iou_classes = ['class_1', 'class_2']
    specific_iou_classes = args.set_class_iou[::2] # even
    # iou_list = ['IoU_1', 'IoU_2']
    iou_list = args.set_class_iou[1::2] # odd
    if len(specific_iou_classes) != len(iou_list):
        print('Error, missing arguments. Flag usage:' + error_msg)
    for tmp_class in specific_iou_classes:
        if tmp_class not in gt_classes: 
            print('Error, unknown class \"' + tmp_class + '\". Flag usage:' + error_msg)
    for num in iou_list:
        if not is_float_between_0_and_1(num): 
            print('Error, IoU must be between 0.0 and 1.0. Flag usage:' + error_msg)
            
#***Read the detection results and save into temporary ".json" file
dr_files_list = glob.glob(DR_PATH + '/*.txt')
dr_files_list.sort()

for class_index, class_name in enumerate(gt_classes):
    bounding_boxes = []
    for txt_file in dr_files_list:
        #check the corresponding ground truth file exists or not
        file_id = txt_file.split(".txt",1)[0]
        file_id = os.path.basename(os.path.normpath(file_id))
        temp_path = os.path.join(GT_PATH, (file_id + ".txt"))
        
        if class_index == 0:
            if not os.path.exists(temp_path):
                print("Error. File not found: {}\n".format(temp_path))
        lines = file_lines_to_list(txt_file)
        for line in lines:
            try:
                tmp_class_name, confidence, left, top, right, bottom = line.split()
            except ValueError:
                print("text file wrong format")
                
            if tmp_class_name == class_name:
                #print(tmp_class_name)
                bbox = left + " " + top + " " + right + " " + bottom
                bounding_boxes.append({"confidence":confidence, "file_id":file_id, "bbox":bbox})
                #print(bounding_boxes)
    #sort detection results by confidence levels
    bounding_boxes.sort(key = lambda x:float(x['confidence']), reverse = True)
    with open(TEMP_FILES_PATH + "/" + class_name + "_dr.json", "w") as outfile:
        json.dump(bounding_boxes, outfile)
        


                        
                        
# cv2.destroyAllWindows()                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                
                
                
                
            
        