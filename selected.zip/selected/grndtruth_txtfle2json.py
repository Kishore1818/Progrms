# -*- coding: utf-8 -*-
"""
Created on Wed Sep  7 08:36:31 2022

@author: kpangalu
"""

import os
import numpy as np
import json
import glob 
import math 


def file_lines_to_list(path):
    # open txt file lines to a list
    with open(path) as f:
        content = f.readlines()
    # remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]
    return content

#****txt file loacation
main_path = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/input_test/ground-truth/"
files_list = glob.glob(main_path + '*.txt')
print(files_list)

#***Reading the each txt file and convert into json format {dictionary}
# jdata = []
# for txtfle in files_list:
#     fileid = txtfle.split(".txt", 1)[0]
#     file_id = fileid.split("\\")[-1]
#     print(file_id)
#     bboxes = []
#     #reading the each line in txt file
#     lneslst = file_lines_to_list(txtfle)
    
#     for line in lneslst:
#         #print(line.split())
#         classname, xmin, ymin, xmax, ymax = line.split()
#         # bbox = [xmin + "," + ymin + "," + xmax + "," +ymax]
#         bbox = xmin + "," + ymin + "," + xmax + "," +ymax
#         # bbox = bbox.replace('')
#         sel = np.where(classname == "book")[0]
#         if(len(sel)):
#             bboxes.append(bbox)
#     if(len(bboxes) > 0):
#         jdata.append({file_id: bboxes})
# print(jdata)  

# #***Reading the each txt file and convert into json format {dictionary}    
jdata = []  
for txtfle in files_list:
    fileid = txtfle.split(".txt", 1)[0]
    file_id = fileid.split("\\")[-1]
    print(file_id)
    bboxes = []
    with open(txtfle, "r") as infile:
        for line in infile:
            classname, xmin, ymin, xmax, ymax = line.split()
            bbox = [xmin + ", " + ymin + ", " + xmax + ", " +ymax]
   
            sel = np.where(classname == "book")[0]
            if(len(sel) > 0):
                bboxes.append(bbox)
                
        if(len(bboxes) > 0):
            jdata.append({'id': file_id, 'bbox': bboxes})
                
print(jdata)
print(type(jdata))
# jdata1 = dict(enumerate(jdata))
# print(type(jdata1))
# print(jdata1)
#Write into a json file
# with open('/Users/kpangalu/Downloads/groundtruth_book.json', 'w') as ofle:
#     json.dump(jdata, ofle)



