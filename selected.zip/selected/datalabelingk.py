#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan 12 21:53:25 2023

@author: eshahria
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun 28 09:43:53 2021

@author: eshahria
"""

# process XML files ---------------------------------------------------------------------------------------------------------------------
import xml.etree.ElementTree as ET
import cv2
import os
import random 
import numpy as np

# C:\Users\kpangalu\Downloads\scale_transparencies_battlemodes\RYB_lgun_rgun\S100_T100\S100_T100_frames\Left_gunactive
parent_root = "/Users/kpangalu/Downloads/scale_transparencies_battlemodes/RYB_lgun_rgun/S100_T100/S100_T100_frames/"
PathSet = ['Right_gunactive']

data_type = 'train'  #'test'      (change here only: train or test)
for path_index in range(0,13):
    path_name = PathSet[path_index]
    parent_path = parent_root + path_name + '/'
    print(parent_path)
    
    save_folder =  'GeneratedData4{}'.format(data_type)
    validation_folder= 'Validation4{}'.format(data_type)
    
    if not os.path.exists(parent_path+save_folder):
        os.makedirs(parent_path+save_folder)
    if not os.path.exists(parent_path+validation_folder):
        os.makedirs(parent_path+validation_folder)
        
        
    # -------------------------------------------------------------------------
    folderset=['images' ]
    xml_files=['RYB_S100_T100_6lblsgen.xml' ]
    
    if data_type== 'train':
        AugProb = 0.4  # train  .2  , test =1
        NumGenData= 1400  # training : 1000 , Test =10 
        CropMax_Top_Ratio= 0.02
        CropMax_Bottom_Ratio= 0.02
        CropMax_Left_Ratio=  0.02
        CropMax_Right_Ratio = 0.02
    elif data_type== 'test':
        AugProb = 1   # train  .2  , test =1
        NumGenData= 100  # training : 1000 , Test =10   
        CropMax_Top_Ratio= 0.02
        CropMax_Bottom_Ratio= 0.02
        CropMax_Left_Ratio=  0.02
        CropMax_Right_Ratio = 0.02
    else :
        print('error : data_type should be train or test' )
        break 
#    AugProb = 1   # train  .2  , test =1
#    NumGenData= 10  # training : 1000 , Test =10
    #
    #CropMax_Top= 200
    #CropMax_Bottom= 100
    #CropMax_Left=  30
    #CropMax_Right = 150
    
#    CropMax_Top_Ratio= 0.35
#    CropMax_Bottom_Ratio= 0.25
#    CropMax_Left_Ratio=  0.03
#    CropMax_Right_Ratio = 0.1
    
    for folder_index in range(1):
        print(folder_index)
            
        foldername= folderset[folder_index]
        image_folder = os.path.join(parent_path, foldername)
        xml_filename= xml_files[folder_index]
        
        image_list = os.listdir(image_folder)
        
        xml_base_path = parent_path + xml_filename
        
        data_index = np.random.choice(range(0, len(image_list)), NumGenData)
        
        for image_index in data_index:
            
            image_name= image_list[image_index]
            print(image_name)
        #for image_name in image_list:
        #    print(image_name)
            # apply crop augmentation 
            # get augmentationcode+ filename and save it. 
            tree = ET.parse(xml_base_path)
            root = tree.getroot()
     
            image= cv2.imread(os.path.join(image_folder,image_name))
            image.shape
            img_height, img_width, img_channels = image.shape
    
            # compute augmentation cropping numbers -------------------------------
            CropMax_Top= int(img_height * CropMax_Top_Ratio)
            CropMax_Bottom= int(img_height * CropMax_Bottom_Ratio)
            CropMax_Left=  int(img_width * CropMax_Left_Ratio)
            CropMax_Right = int(img_width * CropMax_Right_Ratio)
        
            # Augmentation ------------------------------------------------------------
            image_name_aug = image_name        
            img_h,img_w,img_channels= image.shape
            if random.random() >= AugProb  : # apply Augmentation ---------------------
                
                top_crop_size = np.random.choice(range(0, CropMax_Top))
                bottom_crop_size = np.random.choice(range(0, CropMax_Bottom))
                left_crop_size = np.random.choice(range(0, CropMax_Left))
                right_crop_size = np.random.choice(range(0, CropMax_Right)) 
                img_aug = image[top_crop_size : img_h-bottom_crop_size , left_crop_size:img_w-right_crop_size, :]        
                image_name_new = foldername[5:]+'_'+path_name+'_'+image_name[:-4] + '_Crop_T_{}_B_{}_L_{}_R_{}.jpg'.format(str(top_crop_size),str(bottom_crop_size),str(left_crop_size),str(right_crop_size))
        
    
            else : # No Augmentation
                top_crop_size = 0
                bottom_crop_size = 0
                left_crop_size = 0
                right_crop_size = 0
                img_aug = image
                image_name_new = foldername[5:]+'_'+path_name+'_'+image_name[:-4] + '_Crop_T_{}_B_{}_L_{}_R_{}.jpg'.format(str(top_crop_size),str(bottom_crop_size),str(left_crop_size),str(right_crop_size))
                
            # parse XML file and edit it 
            # edit sections -----------------------------------------------------------    
            xml_tag_folder ='images_by_ehsan'
            tag= root.find('folder')
            tag.text = xml_tag_folder
            
            xml_tag_filename= image_name_new
            tag= root.find('filename')
            tag.text = xml_tag_filename
            
            xml_tag_path= 'images/{}'.format(image_name_new)
            tag= root.find('path')
            tag.text = xml_tag_path
            
            xml_tag_height, xml_tag_width, xml_tag_channel = img_aug.shape   
            tag= root.find('size')
            tag_sub = tag.find('width')
            tag_sub.text = str(xml_tag_width)
            tag_sub = tag.find('height')
            tag_sub.text = str(xml_tag_height)
            tag_sub = tag.find('depth')
            tag_sub.text = str(xml_tag_channel)
        
            obj_coordinateSet=[]
            for object in root.findall('object'):
                print(object)
                tag_bndbox = object.find('bndbox')
                tag_xmin = tag_bndbox.find('xmin')
                tag_xmin.text = str(int(tag_xmin.text) - left_crop_size)
                tag_xmax = tag_bndbox.find('xmax')
                tag_xmax.text = str(int(tag_xmax.text) - left_crop_size    )
        
                tag_ymin = tag_bndbox.find('ymin')
                tag_ymin.text = str(int(tag_ymin.text) - top_crop_size)
                tag_ymax = tag_bndbox.find('ymax')
                tag_ymax.text = str(int(tag_ymax.text) - top_crop_size    )
                obj_coordinateSet.append([(int(tag_xmin.text),int(tag_ymin.text)),(int(tag_xmax.text),int(tag_ymax.text))])  
                
            
            # write xml and corresponding image  ------------------------------------------    
            xml_path = os.path.join(parent_path ,save_folder ,  '{}.xml'.format(image_name_new[:-4]))
            tree.write(open(xml_path, 'wb'))        
        
            image_aug_path = os.path.join(parent_path ,save_folder ,  image_name_new)
            cv2.imwrite(image_aug_path,img_aug)
                        
            # draw bounding Box -------------------------------------------------------

            cv2.rectangle(img_aug, obj_coordinateSet[0][0], obj_coordinateSet[0][1], (255,0,0), 2)
            cv2.rectangle(img_aug, obj_coordinateSet[1][0], obj_coordinateSet[1][1], (0,255,0), 2)
            cv2.rectangle(img_aug, obj_coordinateSet[2][0], obj_coordinateSet[2][1], (0,255,0), 2)
            cv2.rectangle(img_aug, obj_coordinateSet[3][0], obj_coordinateSet[3][1], (0,255,0), 2)
            cv2.rectangle(img_aug, obj_coordinateSet[4][0], obj_coordinateSet[4][1], (0,255,0), 2)
            cv2.rectangle(img_aug, obj_coordinateSet[5][0], obj_coordinateSet[5][1], (0,255,0), 2)
            image_validation_path = os.path.join(parent_path ,validation_folder ,  image_name_new)
            cv2.imwrite(image_validation_path,img_aug)
            
    # -------------------------------------------------------------------------



























#  -----------------------------------------------------------------------------------------------------------------------------------