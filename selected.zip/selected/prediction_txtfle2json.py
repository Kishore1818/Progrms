# -*- coding: utf-8 -*-
"""
Created on Wed Sep  7 10:48:33 2022

@author: kpangalu
"""

import os
import re
import numpy as np
import json
import glob 
import math 

#****txt file location
main_path = "/Users/kpangalu/OneDrive - Qualcomm/Desktop/Progms/Object_metrics/input_test/detection-results/"
files_list = glob.glob(main_path + '*.txt')

#***Reading the each txt file and convert into json format {dictionary}    
jdata = []  
for txtfle in files_list:
    fileid = txtfle.split(".txt", 1)[0]
    file_id = fileid.split("\\")[-1]
    
    bboxes = []
    scres = []
    with open(txtfle, "r") as fle:
        for line in fle:
            classname, acc, xmin, ymin, xmax, ymax = line.split() 
            bbox = [xmin + "," + ymin + "," + xmax + "," +ymax]
            sel = np.where(classname == "book")[0]
            if(len(sel)):
                bboxes.append(bbox)
                scres.append(acc)
        if(len(bboxes) > 0):
            jdata.append({'id': file_id, "bbox": bboxes, "scores": scres})
            
            bboxes.append(bbox)
        
            # acc1 = re.sub('"','',acc)
            scres.append(acc)
print(jdata)          

#Write into a json file
with open('/Users/kpangalu/Downloads/prediction_book.json', 'w') as ofle:
    json.dump(jdata, ofle)
    