# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 15:51:55 2022

@author: kpangalu
"""

import numpy as np
import pandas as pd
import imageio
import matplotlib.pyplot as plt
import matplotlib.patches

#This is for Intersection Over Union (IOU)

#********************************* IOU calculations [xtop_left_corner, ytop_left_corner, width, height]
# groundtruth_box = [320, 220, 680, 900] = [xtop_left_corner, ytop_left_corner, width, height]

def iou_xtopytopwidht(grnd_bbox, pred_bbox):
    inter_box_top_left = [max(grnd_bbox[0], pred_bbox[0]), max(grnd_bbox[1], pred_bbox[1])]
    inter_box_bottom_right = [min(grnd_bbox[0]+grnd_bbox[2], pred_bbox[0]+pred_bbox[2]), min(grnd_bbox[1]+grnd_bbox[3], pred_bbox[1]+pred_bbox[3])]

    inter_box_w = inter_box_bottom_right[0] - inter_box_top_left[0]
    inter_box_h = inter_box_bottom_right[1] - inter_box_top_left[1]
    
    intersection = inter_box_w * inter_box_h
    
    union = grnd_bbox[2] * grnd_bbox[3] + pred_bbox[2] * pred_bbox[3] - intersection 
    
    iou = intersection / union 
    
    return iou, intersection, union 


gt_box = [256, 411, 60, 23]    #[xtop_left_corner, ytop_left_corner, width, height]
pred_box = [261, 411, 59, 25]

iou, intersect, union = iou_xtopytopwidht(gt_box, pred_box)
print("IOU results: [xtop_left_corner, ytop_left_corner, width, height]")
print(iou,intersect, union)

#********************IOU calculations [xmin, ymin, xmax, ymax]
#Calculate IoU using predicted and ground truth box
def iou_xminyminxmaxymax(pred_box, gt_box):
    
    x1_t, y1_t, x2_t, y2_t = gt_box
    x1_p, y1_p, x2_p, y2_p = pred_box
    
    if(x1_p > x2_p) or (y1_p > y2_p):
        print("prediction box is not correct: {}".format(pred_box))
        
    if(x1_t > x2_t) or (y1_t > y2_t):
        print("ground truth box is not correct: {}".format(gt_box))
        
    if(x2_t < x1_p or x2_p < x1_t or y2_t < y1_p or y2_p < y1_t):
        return 0.0
    
    far_x = np.min([x2_t, x2_p])
    near_x = np.max([x1_t, x1_p])
    far_y = np.min([y2_t, y2_p])
    near_y = np.max([y1_t, y1_p])
    
    truebox_area = (x2_t - x1_t +1) * (y2_t - y1_t +1)
    predbox_area = (x2_p - x1_p +1) * (y2_p - y1_p +1)
    interior_area = (far_x - near_x +1) * (far_y - near_y +1)
    intersection = interior_area
    union = (truebox_area + predbox_area - interior_area)
    iou = intersection / union 
    
    return iou, intersection, union

gt_box = [256, 411, 316, 434]     #[xmin,ymin, xmax,ymax]
pred_box = [261, 411, 320, 436]

iou, intersection, union = iou_xminyminxmaxymax(gt_box, pred_box)
print("Intersection Over Union (IoU) results: [xmin, ymin, xmax, ymax]")
print(iou, intersection, union)